# -*- coding: utf-8 -*-
"""Que LEMD se actualice sola aunque se instalara con un zip.

Kodi solo actualiza un add-on desde el repositorio del que se instalo. Si se instalo desde un
zip, Kodi lo guarda sin origen y solo busca actualizaciones en el repositorio oficial de Kodi
(donde LEMD no esta): nunca se actualiza. Aqui:

  arreglar_origen()  marca LEMD (y sus sonidos) como del repositorio LEMD en la base de datos
                     de add-ons de Kodi; Kodi lo usa desde el siguiente arranque.
  comprobar(manual)  mira la version publicada en GitHub (un fichero de texto pequeno) y, si
                     es mas nueva, descarga el zip, lo pone en su sitio y recarga la skin.
Se ejecuta una vez por sesion al abrir Inicio (y con «Buscar actualizaciones ahora»).
"""
import glob
import os
import re
import shutil
import sqlite3
import time
import urllib.request
import zipfile
from contextlib import closing

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ID = 'skin.lemd'
REPO = 'repository.lemd'
BASE = 'https://raw.githubusercontent.com/InfraP3Home/LEMD/main/%s/'
UA = {'User-Agent': 'Kodi-skin-LEMD'}


def _version(v):
    return tuple(int(x) for x in re.findall(r'\d+', v or '0')[:3])


def _rama():
    try:
        mayor = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except ValueError:
        mayor = 21
    return 'omega' if mayor >= 21 else 'nexus'


def arreglar_origen():
    """True si ha cambiado algo (vale desde el siguiente arranque de Kodi)."""
    dbs = glob.glob(os.path.join(xbmcvfs.translatePath('special://database/'), 'Addons*.db'))
    if not dbs:
        return False
    db = max(dbs, key=lambda f: int(re.sub(r'\D', '', os.path.basename(f)) or 0))
    try:
        with closing(sqlite3.connect(db, timeout=5)) as c:
            if not c.execute("SELECT 1 FROM installed WHERE addonID=?", (REPO,)).fetchone():
                return False  # sin el repositorio LEMD no hay de donde actualizar
            n = c.execute("UPDATE installed SET origin=? WHERE addonID IN (?, ?) AND (origin IS NULL OR origin='')",
                          (REPO, ID, 'resource.uisounds.lemd')).rowcount
            c.commit()
            if n:
                xbmc.log('[LEMD] origen de %d add-on(s) puesto en %s' % (n, REPO), xbmc.LOGINFO)
            return n > 0
    except Exception as e:
        xbmc.log('[LEMD] arreglar_origen: %s' % e, xbmc.LOGWARNING)
        return False


def publicada(addon=ID):
    """Version de LEMD en el repositorio (o None si no hay conexion)."""
    try:
        req = urllib.request.Request((BASE % _rama()) + 'addons.xml', headers=UA)
        with urllib.request.urlopen(req, timeout=10) as r:
            xml = r.read().decode('utf-8', 'replace')
        m = re.search(r'<addon\s+id="%s"[^>]*\sversion="([^"]+)"' % re.escape(addon), xml)
        return m.group(1) if m else None
    except Exception as e:
        xbmc.log('[LEMD] comprobar version: %s' % e, xbmc.LOGWARNING)
        return None


def instalar(version, aviso=None, addon=ID):
    """Descarga el zip de esa version y lo pone en lugar de la skin actual."""
    def paso(pct, texto):
        if aviso:
            aviso.update(pct, 'LEMD', texto)
    url = (BASE % _rama()) + '%s/%s-%s.zip' % (addon, addon, version)
    tmp = xbmcvfs.translatePath('special://temp/')
    zp = os.path.join(tmp, 'lemd-%s.zip' % version)
    req = urllib.request.Request(url, headers=UA)
    paso(10, 'Actualizando a la versión %s: descargando…' % version)
    with urllib.request.urlopen(req, timeout=60) as r, open(zp, 'wb') as f:
        total = int(r.headers.get('Content-Length') or 0)
        hecho = 0
        while True:
            trozo = r.read(131072)
            if not trozo:
                break
            f.write(trozo)
            hecho += len(trozo)
            if total:
                paso(10 + int(60 * hecho / total), 'Actualizando a la versión %s: descargando…' % version)
    paso(75, 'Actualizando a la versión %s: instalando…' % version)
    addons = xbmcvfs.translatePath('special://home/addons/')
    actual = os.path.join(addons, addon)
    nuevo, viejo = actual + '.lemd-nuevo', actual + '.lemd-viejo'
    for d in (nuevo, viejo):
        shutil.rmtree(d, ignore_errors=True)
    with zipfile.ZipFile(zp) as z:
        if z.testzip() is not None or '%s/addon.xml' % addon not in z.namelist():
            raise ValueError('zip incompleto')
        if ('version="%s"' % version) not in z.read('%s/addon.xml' % addon).decode('utf-8', 'replace'):
            raise ValueError('el zip no es la version %s' % version)
        os.makedirs(nuevo)
        for n in z.namelist():
            if not n.startswith(addon + '/') or '..' in n:
                continue
            destino = os.path.join(nuevo, n[len(addon) + 1:])
            if n.endswith('/'):
                os.makedirs(destino, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(destino), exist_ok=True)
            with z.open(n) as a, open(destino, 'wb') as b:
                shutil.copyfileobj(a, b)
    os.rename(actual, viejo)
    os.rename(nuevo, actual)
    shutil.rmtree(viejo, ignore_errors=True)
    try:
        os.remove(zp)
    except OSError:
        pass
    paso(95, 'Actualizando a la versión %s: recargando la pantalla…' % version)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.sleep(1500)
    if addon != ID:
        return  # el paquete de sonidos no necesita recargar la pantalla (ver actualizar_sonidos)
    if aviso:
        aviso.close()  # antes de recargar: la barra es de la skin vieja
    xbmc.executebuiltin('ReloadSkin()')


def comprobar(manual=False):
    origen = arreglar_origen()
    local = xbmcaddon.Addon(ID).getAddonInfo('version')
    remota = publicada()
    if remota is None:
        if manual:
            xbmcgui.Dialog().ok('Actualizaciones de LEMD', 'No se pudo consultar el repositorio (¿sin Internet?).')
        return
    if _version(remota) <= _version(local):
        if manual:
            xbmcgui.Dialog().ok('Actualizaciones de LEMD', 'Tienes la última versión: %s.%s' % (
                local, '[CR][CR]Actualizaciones automáticas activadas: cuenta desde el próximo arranque de Kodi.'
                if origen else ''))
        return
    if manual:
        texto = ('Hay una versión nueva: [B]%s[/B] (tienes %s).[CR]¿Instalarla ahora? La pantalla se recarga un momento.'
                 % (remota, local))
        try:
            si = xbmcgui.Dialog().yesno('Actualizaciones de LEMD', texto, defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
        except (TypeError, AttributeError):  # Kodi 19
            si = xbmcgui.Dialog().yesno('Actualizaciones de LEMD', texto)
        if not si:
            return
    elif xbmc.getCondVisibility('Player.HasMedia | System.HasActiveModalDialog'):
        return  # sin molestar: se hara la proxima vez
    # aviso: barra discreta abajo mientras se descarga e instala (no bloquea el mando)
    aviso = xbmcgui.DialogProgressBG()
    aviso.create('LEMD', 'Actualizando a la versión %s…' % remota)
    try:
        instalar(remota, aviso)
        aviso.close()
        time.sleep(3)  # que termine de recargar la pantalla
        xbmcgui.Dialog().notification('LEMD actualizada', 'Versión %s instalada' % remota, xbmcgui.NOTIFICATION_INFO, 6000)
    except Exception as e:
        aviso.close()
        xbmc.log('[LEMD] instalar %s: %s' % (remota, e), xbmc.LOGWARNING)
        if manual:
            xbmcgui.Dialog().ok('Actualizaciones de LEMD', 'No se pudo instalar la versión %s.[CR]%s' % (remota, e))
        else:
            xbmcgui.Dialog().notification('LEMD', 'No se pudo actualizar (se intentará mañana)', xbmcgui.NOTIFICATION_WARNING, 5000)


# ---------------------------------------------------------------- sonidos de cabina
SONIDOS = 'resource.uisounds.lemd'


def _rpc(metodo, **p):
    import json
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': metodo,
                                                          'params': p}))).get('result') or {}
    except Exception:
        return {}


def actualizar_sonidos():
    """Pone al dia el paquete de sonidos de cabina (si esta instalado) y vuelve a cargarlo."""
    if not xbmc.getCondVisibility('System.HasAddon(%s)' % SONIDOS):
        return
    local = xbmcaddon.Addon(SONIDOS).getAddonInfo('version')
    remota = publicada(SONIDOS)
    if not remota or _version(remota) <= _version(local):
        return
    try:
        instalar(remota, None, SONIDOS)
        if _rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value') == SONIDOS:
            # Kodi carga los sonidos al elegirlos: se quitan y se vuelven a poner
            _rpc('Settings.SetSettingValue', setting='lookandfeel.soundskin', value='')
            xbmc.sleep(500)
            _rpc('Settings.SetSettingValue', setting='lookandfeel.soundskin', value=SONIDOS)
        xbmc.log('[LEMD] sonidos de cabina actualizados a %s' % remota, xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[LEMD] sonidos %s: %s' % (remota, e), xbmc.LOGWARNING)
