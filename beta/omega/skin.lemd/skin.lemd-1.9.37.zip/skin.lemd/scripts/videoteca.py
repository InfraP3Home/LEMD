# -*- coding: utf-8 -*-
"""Videoteca de LEMD: tu biblioteca de Kodi (peliculas y series que hayas anadido), con el
castellano primero y aviso antes de reproducir algo que no viene en espanol.

Es una entrada aparte del menu lateral (solo aparece si Kodi tiene peliculas o series en la
biblioteca); no sustituye a Peliculas/Series de Umbrella. Solo consulta la base de datos de
Kodi (JSON-RPC), por paginas y con los campos justos: ligero en el Fire TV.

  plugin://skin.lemd/?accion=videoteca                      raiz
  ...&tipo=peliculas[&idioma=es][&pagina=N]                 peliculas (las de audio en espanol aparte)
  ...&tipo=series[&pagina=N]  ->  &tipo=temporadas&serie=ID  ->  &tipo=episodios&serie=ID&temporada=N
  plugin://skin.lemd/?accion=vtver&tipo=movie|episode&id=N  reproducir (pregunta si no hay espanol)
"""
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin

BASE = 'plugin://skin.lemd/?'
PAGINA = 60
ES = ('spa', 'es', 'esp', 'cas', 'spanish', 'castellano', 'castilian', 'es-es')
FILTRO_ES = {'field': 'audiolanguage', 'operator': 'is', 'value': 'spa'}
NOMBRES = {'spa': 'Español', 'eng': 'Inglés', 'fre': 'Francés', 'fra': 'Francés', 'ger': 'Alemán', 'deu': 'Alemán',
           'ita': 'Italiano', 'por': 'Portugués', 'jpn': 'Japonés', 'kor': 'Coreano', 'chi': 'Chino', 'zho': 'Chino',
           'rus': 'Ruso', 'cat': 'Catalán', 'baq': 'Euskera', 'eus': 'Euskera', 'glg': 'Gallego'}


def ruta(**p):
    return BASE + urlencode(dict({'accion': 'videoteca'}, **p))


def _idiomas(detalles):
    return [str(a.get('language') or '').lower() for a in (detalles or {}).get('audio') or []]


def es_espanol(langs):
    return any(l in ES or l.startswith('es-') for l in langs)


def nombre_idiomas(langs):
    vistos = []
    for l in langs:
        n = NOMBRES.get(l, l.upper() if l else '')
        if n and n not in vistos:
            vistos.append(n)
    return ', '.join(vistos)


def _arte(li, art):
    if art:
        li.setArt(art)


def _carpeta(h, etiqueta, path, art=None, plot=''):
    li = xbmcgui.ListItem(etiqueta, offscreen=True)
    _arte(li, art)
    if plot:
        li.getVideoInfoTag().setPlot(plot)
    xbmcplugin.addDirectoryItem(h, path, li, isFolder=True)


def _siguiente(h, **p):
    li = xbmcgui.ListItem('Página siguiente', offscreen=True)
    li.setProperty('SpecialSort', 'bottom')
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(h, ruta(**p), li, isFolder=True)


def _item_video(h, fila, tipo, ident):
    """Pelicula o episodio. Al pulsar: accion vtver (comprueba el idioma y lo pone por la
    biblioteca de Kodi, con su punto de reanudacion y el visto)."""
    titulo = fila.get('title') or fila.get('label') or ''
    langs = _idiomas(fila.get('streamdetails'))
    li = xbmcgui.ListItem(titulo, offscreen=True)
    if langs:
        li.setLabel2(nombre_idiomas(langs))
    _arte(li, fila.get('art'))
    tag = li.getVideoInfoTag()
    tag.setMediaType(tipo)
    tag.setTitle(titulo)
    if fila.get('plot'):
        tag.setPlot(fila['plot'])
    if fila.get('year'):
        tag.setYear(int(fila['year']))
    if fila.get('playcount'):
        tag.setPlaycount(int(fila['playcount']))
    try:
        tag.setRating(float(fila.get('rating') or 0))
    except (TypeError, ValueError):
        pass
    if fila.get('runtime'):
        tag.setDuration(int(fila['runtime']))
    if fila.get('genre'):
        tag.setGenres(fila['genre'])
    if tipo == 'episode':
        tag.setTvShowTitle(fila.get('showtitle') or '')
        tag.setSeason(int(fila.get('season') or 0))
        tag.setEpisode(int(fila.get('episode') or 0))
        if fila.get('firstaired'):
            tag.setFirstAired(fila['firstaired'])
    r = fila.get('resume') or {}
    if r.get('position'):
        tag.setResumePoint(float(r['position']), float(r.get('total') or 0))
    url = BASE + urlencode({'accion': 'vtver', 'tipo': tipo, 'id': ident})
    xbmcplugin.addDirectoryItem(h, url, li, isFolder=False)


def _total(rpc, metodo, clave, **p):
    res = rpc(metodo, limits={'start': 0, 'end': 1}, properties=[], **p)
    return int((res.get('limits') or {}).get('total') or 0)


def raiz(h, rpc):
    xbmcplugin.setContent(h, 'files')
    pelis = _total(rpc, 'VideoLibrary.GetMovies', 'movies')
    es = _total(rpc, 'VideoLibrary.GetMovies', 'movies', filter=FILTRO_ES) if pelis else 0
    series = _total(rpc, 'VideoLibrary.GetTVShows', 'tvshows')
    if es:
        _carpeta(h, 'Películas en español  ·  %d' % es, ruta(tipo='peliculas', idioma='es'),
                 {'icon': 'DefaultMovies.png'}, 'Las películas de tu videoteca con audio en español (lo que Kodi '
                 'sabe del archivo: si no lo ha analizado aún, sale en «Todas»).')
    if pelis:
        _carpeta(h, 'Todas las películas  ·  %d' % pelis, ruta(tipo='peliculas'), {'icon': 'DefaultMovies.png'})
    if series:
        _carpeta(h, 'Series  ·  %d' % series, ruta(tipo='series'), {'icon': 'DefaultTVShows.png'})
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def peliculas(h, rpc, pagina, idioma):
    xbmcplugin.setContent(h, 'movies')
    p = {'properties': ['title', 'year', 'art', 'plot', 'rating', 'genre', 'runtime', 'playcount', 'resume',
                        'streamdetails'],
         'limits': {'start': pagina * PAGINA, 'end': (pagina + 1) * PAGINA},
         'sort': {'method': 'title', 'order': 'ascending', 'ignorearticle': True}}
    if idioma == 'es':
        p['filter'] = FILTRO_ES
    res = rpc('VideoLibrary.GetMovies', **p)
    filas = res.get('movies') or []
    if idioma != 'es':
        # castellano primero dentro de la pagina (sin pedir toda la videoteca: rapido en el Fire TV)
        filas.sort(key=lambda f: 0 if es_espanol(_idiomas(f.get('streamdetails'))) else 1)
    for f in filas:
        _item_video(h, f, 'movie', f['movieid'])
    lim = res.get('limits') or {}
    if lim.get('end', 0) < lim.get('total', 0):
        _siguiente(h, tipo='peliculas', pagina=pagina + 1, **({'idioma': 'es'} if idioma == 'es' else {}))
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def series(h, rpc, pagina):
    xbmcplugin.setContent(h, 'tvshows')
    res = rpc('VideoLibrary.GetTVShows', properties=['title', 'year', 'art', 'plot', 'rating', 'genre', 'episode',
                                                     'watchedepisodes', 'season'],
              limits={'start': pagina * PAGINA, 'end': (pagina + 1) * PAGINA},
              sort={'method': 'title', 'order': 'ascending', 'ignorearticle': True})
    for f in res.get('tvshows') or []:
        li = xbmcgui.ListItem(f.get('title') or f.get('label') or '', offscreen=True)
        _arte(li, f.get('art'))
        tag = li.getVideoInfoTag()
        tag.setMediaType('tvshow')
        tag.setTitle(f.get('title') or '')
        if f.get('plot'):
            tag.setPlot(f['plot'])
        if f.get('year'):
            tag.setYear(int(f['year']))
        li.setLabel2('%d/%d vistos' % (f.get('watchedepisodes') or 0, f.get('episode') or 0))
        # una sola temporada: directa a los episodios
        destino = ruta(tipo='episodios', serie=f['tvshowid']) if f.get('season') == 1 \
            else ruta(tipo='temporadas', serie=f['tvshowid'])
        xbmcplugin.addDirectoryItem(h, destino, li, isFolder=True)
    lim = res.get('limits') or {}
    if lim.get('end', 0) < lim.get('total', 0):
        _siguiente(h, tipo='series', pagina=pagina + 1)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def temporadas(h, rpc, serie):
    xbmcplugin.setContent(h, 'seasons')
    res = rpc('VideoLibrary.GetSeasons', tvshowid=serie,
              properties=['season', 'art', 'episode', 'watchedepisodes', 'showtitle'],
              sort={'method': 'season', 'order': 'ascending'})
    for f in res.get('seasons') or []:
        n = int(f.get('season') or 0)
        li = xbmcgui.ListItem(f.get('label') or ('Especiales' if n == 0 else 'Temporada %d' % n), offscreen=True)
        _arte(li, f.get('art'))
        tag = li.getVideoInfoTag()
        tag.setMediaType('season')
        tag.setSeason(n)
        tag.setTvShowTitle(f.get('showtitle') or '')
        li.setLabel2('%d/%d vistos' % (f.get('watchedepisodes') or 0, f.get('episode') or 0))
        xbmcplugin.addDirectoryItem(h, ruta(tipo='episodios', serie=serie, temporada=n), li, isFolder=True)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def episodios(h, rpc, serie, temporada=None):
    xbmcplugin.setContent(h, 'episodes')
    extra = {'season': temporada} if temporada is not None else {}  # sin temporada: todos (serie de una)
    res = rpc('VideoLibrary.GetEpisodes', tvshowid=serie, **extra,
              properties=['title', 'art', 'plot', 'rating', 'runtime', 'playcount', 'resume', 'season', 'episode',
                          'showtitle', 'firstaired', 'streamdetails'],
              sort={'method': 'episode', 'order': 'ascending'})
    filas = res.get('episodes') or []
    filas.sort(key=lambda f: (int(f.get('season') or 0), int(f.get('episode') or 0)))
    for f in filas:
        _item_video(h, f, 'episode', f['episodeid'])
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def render(h, params, rpc):
    tipo = params.get('tipo', '')
    try:
        pagina = max(0, int(params.get('pagina', 0)))
        if tipo == 'peliculas':
            peliculas(h, rpc, pagina, params.get('idioma'))
        elif tipo == 'series':
            series(h, rpc, pagina)
        elif tipo == 'temporadas':
            temporadas(h, rpc, int(params['serie']))
        elif tipo == 'episodios':
            temp = params.get('temporada')
            episodios(h, rpc, int(params['serie']), int(temp) if temp not in (None, '') else None)
        else:
            raiz(h, rpc)
    except (KeyError, ValueError, TypeError) as e:
        # sin avisos (tambien se usa en filas de Inicio): lista vacia
        xbmc.log('[LEMD] videoteca: %s' % e, xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(h, succeeded=False)


def _hhmmss(seg):
    seg = int(seg or 0)
    return '%d:%02d:%02d' % (seg // 3600, seg % 3600 // 60, seg % 60) if seg >= 3600 else '%d:%02d' % (seg // 60, seg % 60)


def reproducir(params, rpc):
    """Comprueba el idioma (si no hay audio en espanol, pregunta), ofrece reanudar y lo pone
    por la biblioteca de Kodi (asi se guardan el visto y el punto donde lo dejas)."""
    tipo = params.get('tipo')
    try:
        ident = int(params.get('id'))
    except (TypeError, ValueError):
        return
    if tipo == 'movie':
        d = rpc('VideoLibrary.GetMovieDetails', movieid=ident,
                properties=['title', 'streamdetails', 'resume', 'file']).get('moviedetails') or {}
        item = {'movieid': ident}
    elif tipo == 'episode':
        d = rpc('VideoLibrary.GetEpisodeDetails', episodeid=ident,
                properties=['title', 'streamdetails', 'resume', 'file']).get('episodedetails') or {}
        item = {'episodeid': ident}
    else:
        return
    if not d:
        return
    langs = [l for l in _idiomas(d.get('streamdetails')) if l and l not in ('und', 'unknown')]
    if langs and not es_espanol(langs):
        if not xbmcgui.Dialog().yesno('No está en castellano',
                                      '«%s» no trae audio en español (%s).[CR][CR]¿Reproducirla igualmente?'
                                      % (d.get('title') or '', nombre_idiomas(langs)),
                                      nolabel='No', yeslabel='Reproducir'):
            return
    reanudar = False
    pos = (d.get('resume') or {}).get('position') or 0
    if pos > 30:
        i = xbmcgui.Dialog().contextmenu(['Reanudar desde %s' % _hhmmss(pos), 'Desde el principio'])
        if i < 0:
            return
        reanudar = i == 0
    if d.get('file'):
        # ya se ha decidido el idioma: el aviso de idioma al empezar no vuelve a preguntar
        xbmcgui.Window(10000).setProperty('lemd.idioma.visto', d['file'])
    rpc('Player.Open', item=item, options={'resume': reanudar})
