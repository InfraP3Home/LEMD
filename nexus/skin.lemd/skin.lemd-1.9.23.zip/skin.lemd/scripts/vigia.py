# -*- coding: utf-8 -*-
"""Avisos cuando un canal de TV no se ve. Lo usan lemd.py y fuente.py.

- ver_canal(ruta, nombre): pone el canal y vigila ~25 s que el video arranque. Si no:
  1.er fallo -> probar otra opcion del canal; si sigue -> como reiniciar el Fire TV.
"""
import json
import time

import xbmc
import xbmcgui

HOME = 10000
ESPERA = 25  # segundos maximos para que arranque el video


def _reproduciendo():
    if not xbmc.getCondVisibility('Player.HasVideo'):
        return False
    try:
        return xbmc.Player().getTime() >= 2
    except Exception:
        return False


def _avisar(nombre):
    home = xbmcgui.Window(HOME)
    ahora = time.time()
    try:
        n, cuando = home.getProperty('lemd.fallos').split('|')
        n = int(n) if ahora - float(cuando) < 30 * 60 else 0
    except ValueError:
        n = 0
    n += 1
    home.setProperty('lemd.fallos', '%d|%d' % (n, ahora))
    canal = ('«%s» ' % nombre) if nombre else 'El canal '
    if n == 1:
        xbmcgui.Dialog().ok('No se puede ver el canal',
                            canal + 'no ha arrancado.[CR][CR]'
                            'Prueba [B]otra opción del mismo canal[/B] (FHD, HD, SD, «backup» o en otro grupo): '
                            'si una falla, otra suele ir bien. Si no va ninguna y tampoco otros canales, '
                            'reinicia el Fire TV.')
    else:
        xbmcgui.Dialog().ok('Sigue sin funcionar',
                            canal + 'tampoco ha arrancado.[CR][CR]'
                            'Reinicia el Fire TV: sal al [B]menú principal del Fire TV[/B] › '
                            '[B]Configuración[/B] › [B]Mi Fire TV[/B] › [B]Reiniciar[/B], '
                            'y vuelve a entrar en Kodi.')
        home.setProperty('lemd.fallos', '0|%d' % ahora)


def vigilar(nombre=''):
    """Espera a que el video arranque; si no lo hace, avisa."""
    mon = xbmc.Monitor()
    fin = time.time() + ESPERA
    while time.time() < fin:
        if mon.waitForAbort(0.5):
            return
        if _reproduciendo():
            xbmcgui.Window(HOME).setProperty('lemd.fallos', '')
            return
        if xbmc.getCondVisibility('Window.IsActive(okdialog)') and not xbmc.getCondVisibility('Player.HasVideo'):
            # Kodi ya ha dicho que no se puede reproducir: cambiamos su aviso por el nuestro
            xbmc.executebuiltin('Dialog.Close(okdialog,true)')
            xbmc.sleep(300)
            break
        if xbmc.getCondVisibility('Player.Caching') and fin - time.time() < 5:
            fin += 5  # sigue cargando: un poco mas de margen (como mucho una vez cada 5 s)
    if xbmc.getCondVisibility('Player.HasMedia') and xbmc.getCondVisibility('Player.Paused'):
        return  # lo ha pausado el usuario
    _avisar(nombre)


def ver_canal(ruta='', nombre='', canal_id=None):
    if canal_id:
        xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
                                        'params': {'item': {'channelid': int(canal_id)}}}))
    else:  # igual que al pulsar el canal en Kodi (sin lista de reproduccion)
        xbmc.executebuiltin('PlayMedia("%s")' % ruta.replace('"', '\\"'))
    vigilar(nombre)
