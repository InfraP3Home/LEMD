# -*- coding: utf-8 -*-
"""Reparar guia y logos de IPTV Simple (solo cuando se pide, o una vez al dia si se activa).

Muchos proveedores ponen bien el tvg-id (identificador de la guia) solo en parte de los
canales; los demas salen sin programacion y sin logo. Esto:
  1. lee la lista M3U del proveedor (la URL guardada en IPTV Simple, que no se cambia);
  2. lee de la guia XMLTV SOLO la lista de canales (para en cuanto empieza la programacion);
  3. empareja los canales sin guia por su nombre «limpio» (sin |ES|, FHD, HEVC, 4K...);
  4. escribe una lista corregida (tvg-id y, si falta, el logo de la guia) en
     addon_data/skin.lemd/lista_lemd.m3u y, si se acepta, pone IPTV Simple a usarla.
«restaurar» vuelve a la lista original del proveedor.
"""
import glob
import gzip
import os
import re
import time
import unicodedata
import urllib.request
import zlib
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs

IPTV = 'pvr.iptvsimple'
DATOS = xbmcvfs.translatePath('special://profile/addon_data/')
SALIDA = os.path.join(DATOS, 'skin.lemd', 'lista_lemd.m3u')
UA = 'Mozilla/5.0 (Linux; Android) Kodi'
CALIDAD = {'fhd', 'hd', 'sd', 'uhd', '4k', '8k', 'hevc', 'h265', 'h264', '1080p', '1080', '720p', '720',
           '2160p', '50fps', '60fps', '25fps', 'raw', 'backup', 'vip', 'low', 'high', 'hq', 'lq', 'fullhd',
           'multi', 'multiaudio', 'audio', 'dual', 'es', 'esp', 'spa', 'spain', 'espana'}
PREFIJO = re.compile(r'^\s*[\|\[\(]?\s*[a-z]{2,3}\s*[\|\]\):]\s*|^\s*[a-z]{2}\s+-\s+')


def normal(t):
    t = unicodedata.normalize('NFD', (t or '').lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    t = PREFIJO.sub('', t)
    t = t.replace('+', ' plus ')
    t = re.sub(r'\.(es|esp|spa|tv|hd)$', '', t)  # ids tipo «La1.es»
    palabras = [p for p in re.split(r'[^a-z0-9]+', t) if p and p not in CALIDAD]
    out = []
    for p in palabras:  # «plus plus» de «Movistar Plus+»
        if not (out and out[-1] == p == 'plus'):
            out.append(p)
    return ' '.join(out)


def compacto(t):
    return t.replace(' ', '')


# ---------------------------------------------------------------- ajustes de IPTV Simple
def fichero_ajustes():
    base = os.path.join(DATOS, IPTV)
    for f in sorted(glob.glob(os.path.join(base, 'instance-settings-*.xml'))) + [os.path.join(base, 'settings.xml')]:
        if os.path.exists(f) and re.search(r'id="m3u(Url|Path)"', open(f, encoding='utf-8').read()):
            return f
    return None


def leer_ajustes(f):
    t = open(f, encoding='utf-8').read()
    return {m.group(1): m.group(2) for m in re.finditer(r'<setting id="([^"]+)"[^>]*>([^<]*)</setting>', t)}


def escribir_ajustes(f, cambios):
    t = open(f, encoding='utf-8').read()
    for k, v in cambios.items():
        v = v.replace('&', '&amp;').replace('<', '&lt;')
        if re.search(r'<setting id="%s"[^>]*>[^<]*</setting>' % k, t):
            t = re.sub(r'<setting id="%s"[^>]*>[^<]*</setting>' % k, '<setting id="%s">%s</setting>' % (k, v), t)
        elif re.search(r'<setting id="%s"[^>]*/>' % k, t):
            t = re.sub(r'<setting id="%s"[^>]*/>' % k, '<setting id="%s">%s</setting>' % (k, v), t)
        else:
            t = t.replace('</settings>', '    <setting id="%s">%s</setting>\n</settings>' % (k, v))
    with open(f, 'w', encoding='utf-8') as fh:
        fh.write(t)


def _rpc(metodo, **p):
    import json
    return xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': metodo, 'params': p}))


def aplicar_ajustes(f, cambios):
    """IPTV Simple apagado -> se escriben los ajustes -> encendido (asi Kodi no los pisa)."""
    _rpc('Addons.SetAddonEnabled', addonid=IPTV, enabled=False)
    xbmc.sleep(2500)
    if not os.path.exists(f + '.lemd.bak'):
        with open(f, encoding='utf-8') as a, open(f + '.lemd.bak', 'w', encoding='utf-8') as b:
            b.write(a.read())
    escribir_ajustes(f, cambios)
    xbmc.sleep(500)
    _rpc('Addons.SetAddonEnabled', addonid=IPTV, enabled=True)


# ---------------------------------------------------------------- lectura de fuentes
def abrir(ruta, tipo):
    if str(tipo) == '0' or not ruta.startswith(('http://', 'https://')):
        return open(xbmcvfs.translatePath(ruta), 'rb')
    req = urllib.request.Request(ruta, headers={'User-Agent': UA, 'Accept-Encoding': 'gzip'})
    return urllib.request.urlopen(req, timeout=30)


def canales_guia(ruta, tipo):
    """{clave normalizada: (id, icono)} solo con los <channel> de la guia."""
    r = abrir(ruta, tipo)
    dec = None
    parser = ET.XMLPullParser(events=('end', 'start'))
    canales, primero = {}, True
    try:
        while True:
            trozo = r.read(65536)
            if not trozo:
                break
            if primero:
                primero = False
                if trozo[:2] == b'\x1f\x8b':
                    dec = zlib.decompressobj(16 + zlib.MAX_WBITS)
            if dec:
                trozo = dec.decompress(trozo)
            parser.feed(trozo)
            fin = False
            for ev, el in parser.read_events():
                if ev == 'start' and el.tag == 'programme':
                    fin = True
                    break
                if ev == 'end' and el.tag == 'channel':
                    cid = el.get('id') or ''
                    icono = el.find('icon')
                    icono = icono.get('src', '') if icono is not None else ''
                    nombres = [d.text for d in el.findall('display-name') if d.text] + [cid]
                    for n in nombres:
                        k = normal(n)
                        if k:
                            canales.setdefault(k, set()).add((cid, icono))
                            canales.setdefault('#' + compacto(k), set()).add((cid, icono))
                    el.clear()
            if fin:
                break
    finally:
        r.close()
    return canales


def atributo(linea, nombre):
    m = re.search(r'%s="([^"]*)"' % nombre, linea)
    return m.group(1) if m else ''


def poner(linea, nombre, valor):
    if re.search(r'%s="[^"]*"' % nombre, linea):
        return re.sub(r'%s="[^"]*"' % nombre, '%s="%s"' % (nombre, valor.replace('"', '')), linea)
    return linea.replace('#EXTINF:-1', '#EXTINF:-1 %s="%s"' % (nombre, valor.replace('"', '')), 1) \
        if linea.startswith('#EXTINF:-1') else re.sub(r'^(#EXTINF:\S+)', r'\1 %s="%s"' % (nombre, valor), linea)


def buscar(canales, nombre):
    k = normal(nombre)
    for clave in (k, '#' + compacto(k)):
        c = canales.get(clave)
        if c and len({i for i, _ in c}) == 1:  # solo si no hay dudas
            return next(iter(c))
    return None


def reparar_lista(ajustes, guia, progreso=None):
    """Escribe SALIDA y devuelve el resumen."""
    ids = {i.lower() for v in guia.values() for i, _ in v}
    r = abrir(ajustes.get('m3uUrl') or ajustes.get('m3uPath', ''), 1 if ajustes.get('m3uUrl') else 0)
    os.makedirs(os.path.dirname(SALIDA), exist_ok=True)
    tmp = SALIDA + '.tmp'
    res = {'canales': 0, 'bien': 0, 'reparados': 0, 'logos': 0, 'sin': []}
    with open(tmp, 'w', encoding='utf-8') as out:
        pendiente = None
        dec = None
        resto = b''
        primero = True
        while True:
            trozo = r.read(262144)
            if primero and trozo[:2] == b'\x1f\x8b':
                dec = zlib.decompressobj(16 + zlib.MAX_WBITS)
            primero = False
            if dec and trozo:
                trozo = dec.decompress(trozo)
            if not trozo:
                lineas, resto = ([resto] if resto else []), b''
            else:
                datos = resto + trozo
                lineas = datos.split(b'\n')
                resto = lineas.pop()
            for b in lineas:
                linea = b.decode('utf-8', 'replace').rstrip('\r')
                if linea.startswith('#EXTINF'):
                    pendiente = linea
                    continue
                if pendiente is not None and linea and not linea.startswith('#'):
                    ext = pendiente
                    pendiente = None
                    if not any(s in linea for s in ('/movie/', '/series/')):  # solo TV en directo
                        res['canales'] += 1
                        nombre = ext.rsplit(',', 1)[-1].strip()
                        tid = atributo(ext, 'tvg-id')
                        if tid and tid.lower() in ids:
                            res['bien'] += 1
                        else:
                            hit = buscar(guia, atributo(ext, 'tvg-name') or nombre) or buscar(guia, nombre)
                            if hit:
                                ext = poner(ext, 'tvg-id', hit[0])
                                res['reparados'] += 1
                                if hit[1] and not atributo(ext, 'tvg-logo'):
                                    ext = poner(ext, 'tvg-logo', hit[1])
                                    res['logos'] += 1
                            else:
                                res['sin'].append(nombre)
                    out.write(ext + '\n')
                out.write(linea + '\n')
            if not trozo:
                break
            if progreso:
                progreso(res)
    r.close()
    os.replace(tmp, SALIDA)
    return res


# ---------------------------------------------------------------- acciones
def reparar(auto=False):
    f = fichero_ajustes()
    if not f:
        if not auto:
            xbmcgui.Dialog().ok('Reparar guía y logos', 'No encuentro la configuración de IPTV Simple Client.')
        return
    aj = leer_ajustes(f)
    orig = leer_ajustes(f + '.lemd.bak') if os.path.exists(f + '.lemd.bak') else aj  # antes de LEMD
    if auto and os.path.exists(SALIDA) and time.time() - os.path.getmtime(SALIDA) < 20 * 3600:
        return
    if not (aj.get('m3uUrl') or aj.get('m3uPath')) or not (aj.get('epgUrl') or aj.get('epgPath')):
        if not auto:
            xbmcgui.Dialog().ok('Reparar guía y logos', 'IPTV Simple no tiene configuradas la lista M3U y la guía (XMLTV).')
        return
    ruta_lista = orig.get('m3uUrl') if orig.get('m3uPathType', '1') == '1' else orig.get('m3uPath')
    if not ruta_lista or os.path.abspath(xbmcvfs.translatePath(ruta_lista)) == os.path.abspath(SALIDA):
        if not auto:
            xbmcgui.Dialog().ok('Reparar guía y logos', 'No encuentro la dirección original de la lista M3U.')
        return
    dp = None if auto else xbmcgui.DialogProgress()
    if dp:
        dp.create('Reparar guía y logos', 'Leyendo los canales de la guía…')
    try:
        guia = canales_guia(aj.get('epgUrl') if aj.get('epgPathType', '1') == '1' else aj.get('epgPath'),
                            aj.get('epgPathType', '1'))
        if dp:
            dp.update(40, 'Guía: %d nombres de canal. Revisando tu lista…' % len(guia))

        def prog(r):
            if dp:
                dp.update(60, 'Revisando tu lista… %d canales' % r['canales'])
        res = reparar_lista({'m3uUrl': ruta_lista} if ruta_lista.startswith('http') else {'m3uPath': ruta_lista},
                            guia, prog)
    except Exception as e:
        if dp:
            dp.close()
        xbmc.log('[LEMD] reparar: %s' % e, xbmc.LOGWARNING)
        if not auto:
            xbmcgui.Dialog().ok('Reparar guía y logos', 'No se pudo leer la lista o la guía.[CR]%s' % e)
        return
    if dp:
        dp.close()
    usando = aj.get('m3uPathType') == '0' and aj.get('m3uPath') == SALIDA
    if auto:
        if usando:  # solo refrescar
            aplicar_ajustes(f, {})
        return
    sin = res['sin']
    texto = ['[B]Canales de TV en tu lista:[/B] %d' % res['canales'],
             '[B]Ya tenían guía:[/B] %d' % res['bien'],
             '[B]Se pueden reparar:[/B] %d  (logos añadidos: %d)' % (res['reparados'], res['logos']),
             '[B]Sin guía en tu proveedor:[/B] %d' % len(sin)]
    if sin:
        texto += ['', 'Algunos sin guía:', ', '.join(sin[:25]) + ('…' if len(sin) > 25 else '')]
    xbmcgui.Dialog().textviewer('Reparar guía y logos', '[CR]'.join(texto))
    if not res['reparados']:
        xbmcgui.Dialog().ok('Reparar guía y logos', 'No hay canales que se puedan reparar automáticamente.')
        return
    if usando or xbmcgui.Dialog().yesno('Reparar guía y logos',
                                        'Se pueden reparar %d canales.[CR]¿Usar la lista corregida en IPTV Simple?[CR]'
                                        '(Tu dirección original no se toca; puedes volver a ella cuando quieras.)'
                                        % res['reparados']):
        aplicar_ajustes(f, {'m3uPathType': '0', 'm3uPath': SALIDA, 'epgIgnoreCaseForChannelIds': 'true'})
        xbmc.executebuiltin('Skin.SetBool(lemd.reparada)')
        # Kodi no vuelve a pedir la guia de los canales hasta su siguiente actualizacion (unas 2 h)
        if xbmcgui.Dialog().yesno('Reparar guía y logos',
                                  'Hecho: los logos salen ya. La programación de los canales reparados aparece sola '
                                  'en unas 2 horas.[CR][CR]Para verla ya: [B]Guía › Borrar datos de la guía[/B] en los '
                                  'ajustes de TV en directo. ¿Abrirlos ahora?', nolabel='Más tarde', yeslabel='Abrir'):
            xbmc.executebuiltin('ActivateWindow(PVRSettings)')


def restaurar():
    f = fichero_ajustes()
    if not f:
        return
    orig = leer_ajustes(f + '.lemd.bak') if os.path.exists(f + '.lemd.bak') else {}
    aplicar_ajustes(f, {'m3uPathType': orig.get('m3uPathType', '1'), 'm3uPath': orig.get('m3uPath', '')})
    xbmc.executebuiltin('Skin.Reset(lemd.reparada)')
    xbmcgui.Dialog().notification('LEMD', 'IPTV Simple vuelve a usar la lista original', xbmcgui.NOTIFICATION_INFO, 4000)
