# -*- coding: utf-8 -*-
"""Ayudante de la skin LEMD.

Se ejecuta SOLO cuando el usuario lo pide (RunScript desde la skin). No hay
servicio en segundo plano ni bucles: hace su trabajo y termina.

Acciones (RunScript(special://skin/scripts/lemd.py,<accion>[,N])):
  defaults      Rellena las filas de Inicio por defecto (TV en directo y Umbrella).
  detect        Muestra que hay instalado (Umbrella, Trakt, TV, tiempo).
  widget,N      Elegir el contenido de la fila N (preajustes o explorar Umbrella).
  label,N       Renombrar la fila N.
  style,N       Alternar cartel / panoramica en la fila N.
  up,N / down,N Mover la fila N.
  clear,N       Vaciar la fila N.
  row,N         Menu de la fila N (todo lo anterior).
  jerga         Pone o quita los nombres de aeropuerto en las filas automaticas.
  metar         Descarga y traduce el METAR/TAF (LEMD por defecto) y estima las pistas en uso.
  resetall      Volver a las filas por defecto.
"""
import json
import sys

import xbmc
import xbmcaddon
import xbmcgui

FILAS = 10
UMB = 'plugin.video.umbrella'
U = 'plugin://plugin.video.umbrella/?action='
CAMPOS = ('path', 'label', 'style')


# ---------------------------------------------------------------- utilidades
def rpc(method, **params):
    q = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    r = json.loads(xbmc.executeJSONRPC(json.dumps(q)))
    return r.get('result') or {}


def skin_get(n, campo):
    return xbmc.getInfoLabel('Skin.String(lemd.w%d.%s)' % (n, campo))


def skin_set(n, campo, valor):
    clave = 'lemd.w%d.%s' % (n, campo)
    if valor:
        xbmc.executebuiltin('Skin.SetString(%s,%s)' % (clave, escapar(valor)))
    else:
        xbmc.executebuiltin('Skin.Reset(%s)' % clave)


def escapar(valor):
    # Kodi separa los parametros de los builtins por comas: hay que entrecomillar
    return '"%s"' % valor.replace('\\', '\\\\').replace('"', '\\"')


def fila(n, path='', label='', style=''):
    skin_set(n, 'path', path)
    skin_set(n, 'label', label)
    skin_set(n, 'style', 'wide' if style == 'wide' else '')


def tiene(addon_id):
    return xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % addon_id)


def trakt_en_umbrella():
    if not tiene(UMB):
        return False
    try:
        a = xbmcaddon.Addon(UMB)
        return a.getSetting('trakt.isauthed') == 'true' or bool(a.getSetting('trakt.user.token'))
    except Exception:
        return False


def aviso(msg):
    xbmcgui.Dialog().notification('LEMD', msg, xbmcgui.NOTIFICATION_INFO, 3000)


# ---------------------------------------------------------------- tema Barajas: nombres
YT = 'plugin.video.youtube'
SPOTTING = 'plugin://plugin.video.youtube/kodion/search/query/?q=Madrid%20Barajas%20planespotting%20live'
# ruta -> (nombre normal, nombre con jerga de aeropuerto)
NOMBRES = {
    'pvr://channels/tv/*?view=lastplayed': ('Vistos recientemente', 'Últimas puertas'),
    'pvr://channels/tv/*': ('Canales', 'En pista'),
    'pvr://recordings/tv/active?view=flat': ('Grabaciones recientes', 'Caja negra'),
    U + 'episodesUnfinished&url=traktunfinished': ('Continuar viendo', 'Embarcando ahora'),
    U + 'moviesUnfinished&url=traktunfinished': ('Películas sin terminar', 'Escala pendiente'),
    U + 'calendar&url=progress': ('Próximos episodios', 'Próximas salidas'),
    U + 'movies&url=trakttrending': ('Películas en tendencia', 'Películas despegando'),
    U + 'tvshows&url=trakttrending': ('Series en tendencia', 'Series despegando'),
    U + 'tmdbmovies&url=tmdb_popular': ('Películas populares', 'Primera clase: películas'),
    U + 'tmdbTvshows&url=tmdb_popular': ('Series populares', 'Primera clase: series'),
    U + 'movies&url=traktwatchlist': ('Mi lista', 'Mi tarjeta de embarque'),
    U + 'tvshows&url=traktwatchlist': ('Mi lista: series', 'Tarjeta de embarque: series'),
    U + 'tmdbmovies&url=tmdb_nowplaying': ('En cines ahora', 'Recién aterrizadas'),
    SPOTTING: ('Spotting en Barajas (directo)', 'Spotting en Barajas (directo)'),
}


def jerga_activa():
    return not xbmc.getCondVisibility('Skin.HasSetting(lemd.nojerga)')


def nombre(path, por_defecto):
    n = NOMBRES.get(path)
    if not n:
        return por_defecto
    return n[1] if jerga_activa() else n[0]


def renombrar_jerga():
    """Aplica (o quita) la jerga a las filas que conservan su nombre automatico."""
    for n in range(1, FILAS + 1):
        path, label = skin_get(n, 'path'), skin_get(n, 'label')
        par = NOMBRES.get(path)
        if par and label in par:
            skin_set(n, 'label', par[1] if jerga_activa() else par[0])


# ---------------------------------------------------------------- preajustes
def preajustes():
    """Lista de (grupo, etiqueta, ruta, estilo). Solo Umbrella y TV en directo."""
    p = []
    if tiene(UMB):
        g = 'Umbrella · Trakt' if trakt_en_umbrella() else 'Umbrella · Trakt (sin vincular)'
        p += [
            (g, 'Continuar viendo: episodios', U + 'episodesUnfinished&url=traktunfinished', 'wide'),
            (g, 'Continuar viendo: películas', U + 'moviesUnfinished&url=traktunfinished', 'wide'),
            (g, 'Próximos episodios', U + 'calendar&url=progress', 'wide'),
            (g, 'Mi lista: películas', U + 'movies&url=traktwatchlist', 'poster'),
            (g, 'Mi lista: series', U + 'tvshows&url=traktwatchlist', 'poster'),
            ('Umbrella', 'Películas en tendencia', U + 'movies&url=trakttrending', 'poster'),
            ('Umbrella', 'Series en tendencia', U + 'tvshows&url=trakttrending', 'poster'),
            ('Umbrella', 'Películas populares', U + 'tmdbmovies&url=tmdb_popular', 'poster'),
            ('Umbrella', 'Series populares', U + 'tmdbTvshows&url=tmdb_popular', 'poster'),
            ('Umbrella', 'Películas populares (Trakt)', U + 'movies&url=traktpopular', 'poster'),
            ('Umbrella', 'Series populares (Trakt)', U + 'tvshows&url=traktpopular', 'poster'),
            ('Umbrella', 'En cines ahora', U + 'tmdbmovies&url=tmdb_nowplaying', 'poster'),
        ]
    if tiene(YT):
        p.append(('Aviación', 'Spotting en Barajas (directo, YouTube)', SPOTTING, 'wide'))
    if xbmc.getCondVisibility('System.HasPVRAddon'):
        p += [
            ('TV', 'Todos los canales', 'pvr://channels/tv/*', 'wide'),
            ('TV', 'Canales vistos recientemente', 'pvr://channels/tv/*?view=lastplayed', 'wide'),
            ('TV', 'Grabaciones recientes', 'pvr://recordings/tv/active?view=flat', 'wide'),
        ]
    return p


def defaults():
    for n in range(1, FILAS + 1):
        fila(n)
    filas = []
    pvr = xbmc.getCondVisibility('System.HasPVRAddon')
    if pvr:
        filas.append(('Vistos recientemente', 'pvr://channels/tv/*?view=lastplayed', 'wide'))
        filas.append(('Canales', 'pvr://channels/tv/*', 'wide'))
    if tiene(UMB):
        if trakt_en_umbrella():
            filas += [
                ('Continuar viendo', U + 'episodesUnfinished&url=traktunfinished', 'wide'),
                ('Películas sin terminar', U + 'moviesUnfinished&url=traktunfinished', 'wide'),
                ('Próximos episodios', U + 'calendar&url=progress', 'wide'),
            ]
        filas += [
            ('Películas en tendencia', U + 'movies&url=trakttrending', 'poster'),
            ('Series en tendencia', U + 'tvshows&url=trakttrending', 'poster'),
            ('Películas populares', U + 'tmdbmovies&url=tmdb_popular', 'poster'),
            ('Series populares', U + 'tmdbTvshows&url=tmdb_popular', 'poster'),
        ]
        if trakt_en_umbrella():
            filas.append(('Mi lista', U + 'movies&url=traktwatchlist', 'poster'))
    if tiene(YT):
        filas.append(('Spotting en Barajas (directo)', SPOTTING, 'wide'))
    for n, (label, path, style) in enumerate(filas[:FILAS], 1):
        fila(n, path, nombre(path, label), style)
    xbmc.executebuiltin('Skin.SetBool(lemd.init12)')


def detect():
    """Resumen de lo que hay instalado (Umbrella, Trakt, TV y tiempo)."""
    partes = ['Umbrella: %s' % ('sí' if tiene(UMB) else 'no instalado'),
              'Trakt en Umbrella: %s' % ('vinculado' if trakt_en_umbrella() else 'no vinculado'),
              'TV en directo: %s' % ('sí' if xbmc.getCondVisibility('System.HasPVRAddon') else 'sin cliente PVR (instala IPTV Simple Client)'),
              'Meteorología: %s' % (xbmc.getInfoLabel('Weather.Plugin') or 'sin proveedor')]
    xbmcgui.Dialog().ok('LEMD · estado', '[CR]'.join(partes))


# ---------------------------------------------------------------- explorador
def explorar():
    """Navega por los menus de Umbrella y devuelve (ruta, nombre) de la carpeta elegida."""
    if not tiene(UMB):
        aviso('Umbrella no está instalado')
        return None
    pila = [('plugin://%s/' % UMB, 'Umbrella')]
    while pila:
        ruta, nombre = pila[-1]
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        try:
            res = rpc('Files.GetDirectory', directory=ruta, media='video', properties=['title', 'thumbnail'])
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        carpetas = [f for f in res.get('files', []) if f.get('filetype') == 'directory']
        etiquetas = ['[B]» Usar «%s» como fila[/B]' % nombre] + [f.get('label', '') for f in carpetas]
        j = xbmcgui.Dialog().select(nombre, etiquetas)
        if j < 0:
            pila.pop()
            continue
        if j == 0:
            return ruta, nombre
        f = carpetas[j - 1]
        pila.append((f['file'], f.get('label', '')))
    return None


# ---------------------------------------------------------------- tema Barajas: METAR / TAF
FUENTES_METAR = [
    'https://aviationweather.gov/api/data/metar?ids={icao}&format=raw',
    'https://tgftp.nws.noaa.gov/data/observations/metar/stations/{icao}.TXT',
]
FUENTES_TAF = [
    'https://aviationweather.gov/api/data/taf?ids={icao}&format=raw',
    'https://tgftp.nws.noaa.gov/data/forecasts/taf/stations/{icao}.TXT',
]
FENOMENOS = {
    'DZ': 'llovizna', 'RA': 'lluvia', 'SN': 'nieve', 'SG': 'cinarra', 'PL': 'hielo granulado', 'GR': 'granizo',
    'GS': 'granizo pequeño', 'UP': 'precipitación desconocida', 'BR': 'neblina', 'FG': 'niebla', 'FU': 'humo',
    'VA': 'ceniza volcánica', 'DU': 'polvo', 'SA': 'arena', 'HZ': 'calima', 'PO': 'remolinos de polvo',
    'SQ': 'turbonada', 'FC': 'nube embudo', 'SS': 'tempestad de arena', 'DS': 'tempestad de polvo',
}
DESCRIPTORES = {'MI': 'baja', 'BC': 'en bancos', 'PR': 'parcial', 'DR': 'ventisca baja', 'BL': 'ventisca alta',
                'SH': 'chubascos de', 'TS': 'tormenta con', 'FZ': 'engelante'}
NUBES = {'FEW': 'pocas nubes', 'SCT': 'nubes dispersas', 'BKN': 'muy nuboso', 'OVC': 'cubierto', 'VV': 'visibilidad vertical'}
PUNTOS = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSO', 'SO', 'OSO', 'O', 'ONO', 'NO', 'NNO']


def descargar(urls, icao):
    import urllib.request
    for u in urls:
        try:
            req = urllib.request.Request(u.format(icao=icao), headers={'User-Agent': 'Kodi-skin-LEMD'})
            txt = urllib.request.urlopen(req, timeout=10).read().decode('utf-8', 'replace').strip()
        except Exception:
            continue
        if not txt:
            continue
        import re
        # NOAA pone una primera linea con la fecha (2026/11/25 10:30): fuera
        lineas = [l.strip() for l in txt.splitlines() if l.strip() and not re.match(r'^\d{4}/\d{2}/\d{2}', l.strip())]
        if lineas:
            return ' '.join(lineas) if 'taf' in u.lower() else lineas[0]
    return ''


def decodificar_metar(m):
    """Devuelve (lista de lineas en espanol, viento (dir|None, kt, racha))."""
    import re
    out, viento = [], (None, 0, 0)
    tokens = m.replace('=', '').split()
    for t in tokens:
        if t in ('METAR', 'SPECI', 'AUTO', 'COR') or re.fullmatch(r'[A-Z]{4}', t) and not out and t not in ('CAVOK', 'NSC', 'NCD', 'SKC', 'CLR'):
            continue
        if t in ('NOSIG',):
            out.append('Tendencia: sin cambios significativos')
            break
        if t in ('BECMG', 'TEMPO'):
            out.append('Tendencia: cambios previstos (%s)' % ('temporales' if t == 'TEMPO' else 'graduales'))
            break
        mt = re.fullmatch(r'(\d{2})(\d{2})(\d{2})Z', t)
        if mt:
            out.append('Observación del día %s a las %s:%s UTC' % mt.groups())
            continue
        mw = re.fullmatch(r'(\d{3}|VRB)(\d{2,3})(?:G(\d{2,3}))?(KT|MPS)', t)
        if mw:
            d, v, g, u = mw.groups()
            f = 1.944 if u == 'MPS' else 1.0
            kt, gk = round(int(v) * f), round(int(g) * f) if g else 0
            if d == 'VRB':
                txt = 'Viento variable de %d kt' % kt
                viento = (None, kt, gk)
            elif kt == 0:
                txt = 'Viento en calma'
                viento = (None, 0, 0)
            else:
                txt = 'Viento del %s (%s°) a %d kt (%d km/h)' % (PUNTOS[int((int(d) % 360) / 22.5 + 0.5) % 16], d, kt, round(kt * 1.852))
                viento = (int(d), kt, gk)
            if gk:
                txt += ', rachas de %d kt' % gk
            out.append(txt)
            continue
        mv = re.fullmatch(r'(\d{3})V(\d{3})', t)
        if mv:
            out.append('Dirección variable entre %s° y %s°' % mv.groups())
            continue
        if t == 'CAVOK':
            out.append('CAVOK: visibilidad de 10 km o más y sin nubes significativas')
            continue
        if re.fullmatch(r'\d{4}', t):
            vis = int(t)
            out.append('Visibilidad: %s' % ('10 km o más' if vis >= 9999 else ('%d m' % vis if vis < 5000 else '%.0f km' % (vis / 1000.0))))
            continue
        if t.startswith('R') and '/' in t:
            continue  # alcance visual en pista: se omite
        mn = re.fullmatch(r'(FEW|SCT|BKN|OVC|VV)(\d{3}|///)(CB|TCU)?', t)
        if mn:
            tipo, alt, conv = mn.groups()
            txt = NUBES[tipo]
            if alt != '///':
                txt += ' a %d ft' % (int(alt) * 100)
            if conv:
                txt += ' (%s)' % ('cumulonimbos' if conv == 'CB' else 'cúmulos de gran desarrollo')
            out.append(txt[0].upper() + txt[1:])
            continue
        if t in ('NSC', 'NCD', 'SKC', 'CLR'):
            out.append('Sin nubes significativas')
            continue
        mtd = re.fullmatch(r'(M?\d{2})/(M?\d{2})', t)
        if mtd:
            tt, dd = (int(x.replace('M', '-')) for x in mtd.groups())
            out.append('Temperatura %d °C · punto de rocío %d °C' % (tt, dd))
            continue
        mq = re.fullmatch(r'Q(\d{4})', t)
        if mq:
            out.append('QNH %s hPa' % int(mq.group(1)))
            continue
        ma = re.fullmatch(r'A(\d{4})', t)
        if ma:
            out.append('Altímetro %.2f inHg' % (int(ma.group(1)) / 100.0))
            continue
        mf = re.fullmatch(r'(\+|-|VC)?(MI|BC|PR|DR|BL|SH|TS|FZ)?((?:DZ|RA|SN|SG|PL|GR|GS|UP|BR|FG|FU|VA|DU|SA|HZ|PO|SQ|FC|SS|DS)*)', t)
        if mf and (mf.group(3) or mf.group(2) == 'TS'):
            inten, desc, fen = mf.groups()
            partes = [FENOMENOS[fen[i:i + 2]] for i in range(0, len(fen), 2)]
            txt = ' y '.join(partes)
            if desc == 'TS' and not partes:
                txt, desc = 'tormenta', None
            if desc:
                txt = '%s %s' % (DESCRIPTORES[desc], txt)
            if inten == '-':
                txt += ' débil'
            elif inten == '+':
                txt += ' fuerte'
            elif inten == 'VC':
                txt += ' en las proximidades'
            out.append('Fenómeno: ' + txt)
            continue
    return out, viento


def pistas_lemd(viento):
    """Configuracion de pistas de Barajas estimada a partir del viento.
    Norte (preferente): aterrizajes 32L/32R, despegues 36L/36R.
    Sur: aterrizajes 18L/18R, despegues 14L/14R. Se cambia a Sur con viento en cola en las 32."""
    import math
    d, kt, gk = viento
    norte = 'Configuración NORTE · aterrizajes 32L/32R · despegues 36L/36R'
    sur = 'Configuración SUR · aterrizajes 18L/18R · despegues 14L/14R'
    if d is None or kt <= 5:
        return norte
    cola = -max(kt, gk or 0) * math.cos(math.radians(d - 323))
    return sur if cola > 5 else norte


def metar():
    icao = (xbmc.getInfoLabel('Skin.String(lemd.icao)') or 'LEMD').strip().upper()
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        raw = descargar(FUENTES_METAR, icao)
        taf = descargar(FUENTES_TAF, icao)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if not raw:
        xbmcgui.Dialog().ok('METAR %s' % icao, 'No se pudo descargar el METAR. Comprueba la conexión a Internet.')
        return
    lineas, viento = decodificar_metar(raw)
    pistas = pistas_lemd(viento) if icao == 'LEMD' else ''
    home = xbmcgui.Window(10000)
    home.setProperty('lemd.metar.raw', raw)
    home.setProperty('lemd.metar.resumen', ' · '.join(lineas[1:4]))
    home.setProperty('lemd.metar.pistas', pistas)
    texto = ['[B]METAR[/B]', raw, ''] + lineas
    if pistas:
        texto += ['', '[B]Pistas en uso (estimación)[/B]', pistas,
                  'Deducida del viento del METAR; la configuración real la decide el control aéreo.']
    if taf:
        texto += ['', '[B]TAF (previsión)[/B]', taf]
    xbmcgui.Dialog().textviewer('METAR / TAF · %s' % icao, '[CR]'.join(texto))


# ---------------------------------------------------------------- acciones de fila
def elegir(n):
    p = preajustes()
    etiquetas = ['%s  ·  %s' % (g, l) for g, l, _, _ in p]
    extra = ['Explorar menús de Umbrella…', 'Escribir la ruta a mano…', 'Quitar esta fila']
    i = xbmcgui.Dialog().select('Fila %d: contenido' % n, extra[:1] + etiquetas + extra[1:])
    if i < 0:
        return
    if i == 0:
        r = explorar()
        if r:
            ruta, nombre = r
            estilo = 'wide' if any(k in ruta.lower() for k in ('episode', 'unfinished', 'progress', 'calendar', 'channel')) else 'poster'
            fila(n, ruta, nombre, estilo)
        return
    i -= 1
    if i < len(p):
        g, l, ruta, estilo = p[i]
        fila(n, ruta, nombre(ruta, l), estilo)
        return
    i -= len(p)
    if i == 0:
        ruta = xbmcgui.Dialog().input('Ruta (plugin://… o pvr://…)', skin_get(n, 'path'))
        if ruta:
            fila(n, ruta, skin_get(n, 'label') or 'Fila %d' % n, skin_get(n, 'style'))
    else:
        fila(n)


def renombrar(n):
    t = xbmcgui.Dialog().input('Nombre de la fila %d' % n, skin_get(n, 'label'))
    if t:
        skin_set(n, 'label', t)


def estilo(n):
    skin_set(n, 'style', '' if skin_get(n, 'style') == 'wide' else 'wide')


def mover(n, d):
    m = n + d
    if not 1 <= m <= FILAS:
        return
    a = {c: skin_get(n, c) for c in CAMPOS}
    b = {c: skin_get(m, c) for c in CAMPOS}
    for c in CAMPOS:
        skin_set(n, c, b[c])
        skin_set(m, c, a[c])


def menu_fila(n):
    nombre = skin_get(n, 'label') or 'vacía'
    vacia = not skin_get(n, 'path')
    ops = [('Cambiar contenido…', elegir)]
    if not vacia:
        es_wide = skin_get(n, 'style') == 'wide'
        ops += [('Renombrar…', renombrar),
                ('Estilo: %s (cambiar a %s)' % (('Panorámica', 'Carteles') if es_wide else ('Carteles', 'Panorámica')), estilo)]
        if n > 1:
            ops.append(('Subir', lambda k: mover(k, -1)))
        if n < FILAS:
            ops.append(('Bajar', lambda k: mover(k, 1)))
        ops.append(('Quitar fila', lambda k: fila(k)))
    i = xbmcgui.Dialog().select('Fila %d · %s' % (n, nombre), [o[0] for o in ops])
    if i >= 0:
        ops[i][1](n)


def main():
    args = sys.argv[1:]
    if not args:
        return
    accion = args[0]
    n = int(args[1]) if len(args) > 1 and args[1].isdigit() else 0
    if accion == 'defaults':
        defaults()
    elif accion == 'resetall':
        if xbmcgui.Dialog().yesno('LEMD', '¿Volver a las filas de Inicio por defecto?'):
            defaults()
    elif accion == 'detect':
        detect()
    elif accion == 'widget' and n:
        elegir(n)
    elif accion == 'label' and n:
        renombrar(n)
    elif accion == 'style' and n:
        estilo(n)
    elif accion == 'up' and n:
        mover(n, -1)
    elif accion == 'down' and n:
        mover(n, 1)
    elif accion == 'clear' and n:
        fila(n)
    elif accion == 'row' and n:
        menu_fila(n)
    elif accion == 'jerga':
        renombrar_jerga()
    elif accion == 'metar':
        metar()


if __name__ == '__main__':
    main()
