# -*- coding: utf-8 -*-
"""Ayudante de la skin LEMD.

Se ejecuta SOLO cuando el usuario lo pide (RunScript desde la skin). No hay
servicio en segundo plano ni bucles: hace su trabajo y termina.

Acciones (RunScript(special://skin/scripts/lemd.py,<accion>[,N])):
  defaults      Rellena las filas de Inicio por defecto (TV en directo y Umbrella).
  detect        Muestra que hay instalado (Umbrella, Trakt, TV, tiempo).
  widget,N      Elegir el contenido de la fila N (preajustes o explorar Umbrella).
  label,N       Renombrar la fila N.
  style,N       Alternar cartel / panoramica en la fila N.
  up,N / down,N Mover la fila N.
  clear,N       Vaciar la fila N.
  row,N         Menu de la fila N (todo lo anterior).
  jerga         Pone o quita los nombres de aeropuerto en las filas automaticas.
  claves        Palabras clave de «Vuelos destacados» (eventos de la guía).
  ciudad        Ciudad del tiempo (proveedor LEMD, Open-Meteo).
  tiempodefecto Pone LEMD como proveedor del tiempo si no hay ninguno.
  tono          Tono del fondo: grafito, negro o gris claro.
  canal,RUTA,NOMBRE  Pone un canal y avisa si no arranca (otra opción / reiniciar el Fire TV).
  reparar[,auto] Repara guía y logos de IPTV Simple (tvg-id por nombre); restaurar lo deshace.
  metar         Descarga y traduce el METAR/TAF (LEMD por defecto) y estima las pistas en uso.
  resetall      Volver a las filas por defecto.
"""
import json
import os
import re
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

FILAS = 20
UMB = 'plugin.video.umbrella'
U = 'plugin://plugin.video.umbrella/?action='
CAMPOS = ('path', 'label', 'style')


# ---------------------------------------------------------------- utilidades
def rpc(method, **params):
    q = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    r = json.loads(xbmc.executeJSONRPC(json.dumps(q)))
    return r.get('result') or {}


def skin_get(n, campo):
    return xbmc.getInfoLabel('Skin.String(lemd.w%d.%s)' % (n, campo))


def skin_set(n, campo, valor):
    clave = 'lemd.w%d.%s' % (n, campo)
    if valor:
        xbmc.executebuiltin('Skin.SetString(%s,%s)' % (clave, escapar(valor)))
    else:
        xbmc.executebuiltin('Skin.Reset(%s)' % clave)


def escapar(valor):
    # Kodi separa los parametros de los builtins por comas: hay que entrecomillar
    return '"%s"' % valor.replace('\\', '\\\\').replace('"', '\\"')


def fila(n, path='', label='', style=''):
    skin_set(n, 'path', path)
    skin_set(n, 'label', label)
    skin_set(n, 'style', 'wide' if style == 'wide' else '')


def tiene(addon_id):
    return xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % addon_id)


def trakt_en_umbrella():
    if not tiene(UMB):
        return False
    try:
        a = xbmcaddon.Addon(UMB)
        return a.getSetting('trakt.isauthed') == 'true' or bool(a.getSetting('trakt.user.token'))
    except Exception:
        return False


def aviso(msg):
    xbmcgui.Dialog().notification('LEMD', msg, xbmcgui.NOTIFICATION_INFO, 3000)


# ---------------------------------------------------------------- tema Barajas: nombres
YT = 'plugin.video.youtube'
# fila de spotting de YouTube (quitada en 1.9.23; se usa para borrarla de Inicio)
SPOTTING = 'plugin://plugin.video.youtube/kodion/search/query/?q=Madrid%20Barajas%20planespotting%20live'
EVENTOS = 'plugin://skin.lemd/?accion=eventos'
RECIENTES = 'plugin://skin.lemd/?accion=recientes'  # como lastplayed de Kodi, pero se pueden quitar canales
RETOMAR = 'plugin://skin.lemd/?accion=retomar'  # peliculas a medias (Trakt, desde la copia de Umbrella)
RETOMAR_UMB = U + 'moviesUnfinished&url=traktunfinished'
SERIES = 'plugin://skin.lemd/?accion=series'  # series a medias + siguiente episodio (junta dos filas de Umbrella)
SERIES_UMB = (U + 'episodesUnfinished&url=traktunfinished', U + 'calendar&url=progress')
# listas de Trakt leidas por LEMD (todas, sin las paginas de Umbrella)
LISTA = 'plugin://skin.lemd/?accion=lista&tabla='
LISTAS_UMB = {U + 'movies&url=traktwatchlist': LISTA + 'movies_watchlist',
              U + 'tvshows&url=traktwatchlist': LISTA + 'shows_watchlist',
              U + 'movies&url=traktcollection': LISTA + 'movies_collection',
              U + 'tvshows&url=traktcollection': LISTA + 'shows_collection'}
LASTPLAYED = 'pvr://channels/tv/*?view=lastplayed'
# documentales: populares de Trakt por genero (no hace falta vincular Trakt)
# «Ver todo» de las recomendaciones de Trakt: 100 (lo maximo de Trakt) en vez de las 40 de Umbrella
MAS_TRAKT = {U + 'movies&url=traktrecommendations': U + 'movies&url=https%3A%2F%2Fapi.trakt.tv%2Frecommendations%2Fmovies%3Flimit%3D100',
             U + 'tvshows&url=traktrecommendations': U + 'tvshows&url=https%3A%2F%2Fapi.trakt.tv%2Frecommendations%2Fshows%3Flimit%3D100'}
DOC_PELIS = U + 'trakt_genre&listtype=popular&mediatype=Movies&genre=Documentary&url=documentary'
DOC_SERIES = U + 'trakt_genre&listtype=popular&mediatype=TVShows&genre=Documentary&url=documentary'
# «Ver todo» de las listas de Umbrella con paginas que lleva LEMD: se abre la direccion de Trakt
# o TMDb de la lista con «page=1» y LEMD pasa a la 2, 3... (Umbrella a veces no pone su «pagina
# siguiente»). {T} Trakt, {M} TMDb (la que use Umbrella), {L} por pagina, {P} pagina.
PAGINAS_UMB = {
    U + 'movies&url=trakttrending': ('moviePage', '{T}/movies/trending?limit={L}&page={P}'),
    U + 'movies&url=traktpopular': ('moviePage', '{T}/movies/popular?limit={L}&page={P}'),
    U + 'movies&url=traktanticipated': ('moviePage', '{T}/movies/anticipated?limit={L}&page={P}'),
    U + 'tvshows&url=trakttrending': ('tvshowPage', '{T}/shows/trending?limit={L}&page={P}'),
    U + 'tvshows&url=traktpopular': ('tvshowPage', '{T}/shows/popular?limit={L}&page={P}'),
    DOC_PELIS: ('moviePage', '{T}/movies/popular?limit={L}&page={P}&genres=documentary&language={LANG}'),
    DOC_SERIES: ('tvshowPage', '{T}/shows/popular?limit={L}&page={P}&genres=documentary&language={LANG}'),
    U + 'tmdbmovies&url=tmdb_popular': ('tmdbmoviePage', '{M}/3/movie/popular?api_key=%s&language=en-US&region=US&page={P}'),
    U + 'tmdbmovies&url=tmdb_toprated': ('tmdbmoviePage', '{M}/3/movie/top_rated?api_key=%s&page={P}'),
    U + 'tmdbmovies&url=tmdb_nowplaying': ('tmdbmoviePage', '{M}/3/movie/now_playing?api_key=%s&language=en-US&region=US&page={P}'),
    U + 'tmdbmovies&url=tmdb_boxoffice': ('tmdbmoviePage', '{M}/3/discover/movie?api_key=%s&language=en-US&region=US&sort_by=revenue.desc&page={P}'),
    U + 'tmdbTvshows&url=tmdb_popular': ('tmdbTvshowPage', '{M}/3/tv/popular?api_key=%s&language=en-US&region=US&page={P}'),
    U + 'tmdbTvshows&url=tmdb_toprated': ('tmdbTvshowPage', '{M}/3/tv/top_rated?api_key=%s&language=en-US&region=US&page={P}'),
    U + 'tmdbTvshows&url=tmdb_ontheair': ('tmdbTvshowPage', '{M}/3/tv/on_the_air?api_key=%s&language=en-US&region=US&page={P}'),
    U + 'tmdbTvshows&url=tmdb_airingtoday': ('tmdbTvshowPage', '{M}/3/tv/airing_today?api_key=%s&language=en-US&region=US&page={P}'),
    U + 'tvshows&url=tmdb_newshows': ('tmdbTvshowPage', '{M}/3/discover/tv?api_key=%s&with_original_language=en&language=en-US&region=US'
                                      '&sort_by=popularity.desc&first_air_date.gte={D31}&first_air_date.lte={HOY}&page={P}'),
}
# ruta -> (nombre normal, nombre con jerga de aeropuerto)
NOMBRES = {
    LASTPLAYED: ('Vistos recientemente', 'Últimas puertas'),
    RECIENTES: ('Vistos recientemente', 'Últimas puertas'),
    'pvr://channels/tv/*': ('Canales', 'En pista'),
    'pvr://recordings/tv/active?view=flat': ('Grabaciones recientes', 'Caja negra'),
    U + 'episodesUnfinished&url=traktunfinished': ('Continuar viendo: series', 'Retomar vuelo: series'),
    U + 'moviesUnfinished&url=traktunfinished': ('Continuar viendo: películas', 'Retomar vuelo: películas'),
    RETOMAR: ('Continuar viendo: películas', 'Retomar vuelo: películas'),
    SERIES: ('Continuar viendo: series', 'Retomar vuelo: series'),
    U + 'calendar&url=progress': ('Próximos episodios', 'Próximas salidas'),
    U + 'movies&url=trakttrending': ('Películas en tendencia', 'Películas despegando'),
    U + 'tvshows&url=trakttrending': ('Series en tendencia', 'Series despegando'),
    U + 'tmdbmovies&url=tmdb_popular': ('Películas populares', 'Primera clase: películas'),
    U + 'tmdbTvshows&url=tmdb_popular': ('Series populares', 'Primera clase: series'),
    U + 'movies&url=traktwatchlist': ('Mi lista: películas', 'Mi tarjeta de embarque: películas'),
    LISTA + 'movies_watchlist': ('Mi lista: películas', 'Mi tarjeta de embarque: películas'),
    LISTA + 'shows_watchlist': ('Mi lista: series', 'Mi tarjeta de embarque: series'),
    LISTA + 'movies_collection': ('Mi colección: películas', 'Mi hangar: películas'),
    LISTA + 'shows_collection': ('Mi colección: series', 'Mi hangar: series'),
    U + 'tvshows&url=traktwatchlist': ('Mi lista: series', 'Mi tarjeta de embarque: series'),
    U + 'tmdbmovies&url=tmdb_nowplaying': ('En cines ahora', 'Recién aterrizadas'),
    SPOTTING: ('Spotting en Barajas (directo)', 'Spotting en Barajas (directo)'),
    EVENTOS: ('Eventos destacados en TV', 'Vuelos destacados'),
    DOC_PELIS: ('Documentales', 'Vuelo de reconocimiento'),
    DOC_SERIES: ('Series documentales', 'Vuelo de reconocimiento: series'),
    # Trakt (cuenta)
    U + 'movies&url=traktcollection': ('Mi colección: películas', 'Mi hangar: películas'),
    U + 'tvshows&url=traktcollection': ('Mi colección: series', 'Mi hangar: series'),
    U + 'movies&url=trakthistory': ('Películas vistas', 'Cuaderno de bitácora'),
    U + 'calendar&url=trakthistory': ('Episodios vistos', 'Bitácora de episodios'),
    U + 'movies&url=traktrecommendations': ('Recomendadas para ti', 'La torre recomienda'),
    U + 'tvshows&url=traktrecommendations': ('Series recomendadas', 'La torre recomienda: series'),
    U + 'movies&url=traktbasedonrecent': ('Porque viste...', 'Rutas parecidas'),
    U + 'tvshows&url=traktbasedonrecent': ('Series porque viste...', 'Rutas parecidas: series'),
    # Descubrir
    U + 'movies&url=traktanticipated': ('Las más esperadas', 'Próximas llegadas'),
    U + 'movies&url=traktboxoffice': ('Taquilla', 'Récord de pasajeros'),
    U + 'tmdbmovies&url=tmdb_toprated': ('Mejor valoradas', 'Clase business'),
    U + 'tmdbTvshows&url=tmdb_toprated': ('Series mejor valoradas', 'Clase business: series'),
    U + 'tmdbmovies&url=tmdb_upcoming': ('Próximos estrenos', 'En aproximación final'),
    U + 'tmdbTvshows&url=tmdb_airingtoday': ('Se emiten hoy', 'En vuelo hoy'),
    U + 'tmdbTvshows&url=tmdb_ontheair': ('Series en emisión', 'En ruta'),
    U + 'tvshows&url=tmdb_newshows': ('Series nuevas', 'Vuelo inaugural'),
    U + 'movies&url=oscars': ('Premios Óscar', 'Pasajeros de honor'),
    U + 'tmdbmovies&url=tmdb_boxoffice': ('Taquilla (TMDb)', 'Récord de pasajeros (TMDb)'),
    U + 'movies&url=traktpopular': ('Películas populares (Trakt)', 'Puente aéreo: películas'),
    U + 'tvshows&url=traktpopular': ('Series populares (Trakt)', 'Puente aéreo: series'),
}


def jerga_activa():
    return not xbmc.getCondVisibility('Skin.HasSetting(lemd.nojerga)')


def nombre(path, por_defecto):
    n = NOMBRES.get(path)
    if not n:
        return por_defecto
    return n[1] if jerga_activa() else n[0]


def renombrar_jerga():
    """Aplica (o quita) la jerga a las filas que conservan su nombre automatico."""
    for n in range(1, FILAS + 1):
        path, label = skin_get(n, 'path'), skin_get(n, 'label')
        par = NOMBRES.get(path)
        if par and label in par:
            skin_set(n, 'label', par[1] if jerga_activa() else par[0])


# ---------------------------------------------------------------- preajustes
def preajustes():
    """Lista de (grupo, etiqueta, ruta, estilo). Solo Umbrella y TV en directo."""
    p = []
    pvr = xbmc.getCondVisibility('System.HasPVRAddon')
    if pvr:
        p.append(('TV', 'Eventos destacados (fútbol, F1...) de la guía', EVENTOS, 'wide'))
    if tiene(UMB):
        g = 'Trakt' if trakt_en_umbrella() else 'Trakt (sin vincular en Umbrella)'
        p += [
            (g, 'Continuar viendo: películas', RETOMAR, 'wide'),
            (g, 'Continuar viendo: series (a medias y siguiente episodio)', SERIES, 'wide'),
            (g, 'Solo episodios a medias', U + 'episodesUnfinished&url=traktunfinished', 'wide'),
            (g, 'Solo próximos episodios', U + 'calendar&url=progress', 'wide'),
            (g, 'Mi lista: películas', LISTA + 'movies_watchlist', 'poster'),
            (g, 'Mi lista: series', LISTA + 'shows_watchlist', 'poster'),
            (g, 'Mi colección: películas', LISTA + 'movies_collection', 'poster'),
            (g, 'Mi colección: series', LISTA + 'shows_collection', 'poster'),
            (g, 'Recomendadas para mí: películas', U + 'movies&url=traktrecommendations', 'poster'),
            (g, 'Recomendadas para mí: series', U + 'tvshows&url=traktrecommendations', 'poster'),
            (g, 'Parecidas a lo último que vi: películas', U + 'movies&url=traktbasedonrecent', 'poster'),
            (g, 'Parecidas a lo último que vi: series', U + 'tvshows&url=traktbasedonrecent', 'poster'),
            (g, 'Películas que he visto', U + 'movies&url=trakthistory', 'poster'),
            (g, 'Episodios que he visto', U + 'calendar&url=trakthistory', 'wide'),
            ('Películas', 'En tendencia', U + 'movies&url=trakttrending', 'poster'),
            ('Películas', 'Populares', U + 'tmdbmovies&url=tmdb_popular', 'poster'),
            ('Películas', 'Populares (Trakt)', U + 'movies&url=traktpopular', 'poster'),
            ('Películas', 'Las más esperadas (aún sin estrenar: Umbrella no las encuentra)', U + 'movies&url=traktanticipated', 'poster'),
            ('Películas', 'Taquilla', U + 'movies&url=traktboxoffice', 'poster'),
            ('Películas', 'En cines ahora (casi ninguna está aún para ver)', U + 'tmdbmovies&url=tmdb_nowplaying', 'poster'),
            ('Películas', 'Próximos estrenos (aún sin estrenar)', U + 'tmdbmovies&url=tmdb_upcoming', 'poster'),
            ('Películas', 'Mejor valoradas', U + 'tmdbmovies&url=tmdb_toprated', 'poster'),
            ('Películas', 'Premios Óscar', U + 'movies&url=oscars', 'poster'),
            ('Películas', 'Documentales', DOC_PELIS, 'poster'),
            ('Series', 'En tendencia', U + 'tvshows&url=trakttrending', 'poster'),
            ('Series', 'Populares', U + 'tmdbTvshows&url=tmdb_popular', 'poster'),
            ('Series', 'Populares (Trakt)', U + 'tvshows&url=traktpopular', 'poster'),
            ('Series', 'Se emiten hoy', U + 'tmdbTvshows&url=tmdb_airingtoday', 'poster'),
            ('Series', 'En emisión', U + 'tmdbTvshows&url=tmdb_ontheair', 'poster'),
            ('Series', 'Series nuevas', U + 'tvshows&url=tmdb_newshows', 'poster'),
            ('Series', 'Mejor valoradas', U + 'tmdbTvshows&url=tmdb_toprated', 'poster'),
            ('Series', 'Series documentales', DOC_SERIES, 'poster'),
        ]
    if pvr:
        p += [
            ('TV', 'Todos los canales', 'pvr://channels/tv/*', 'wide'),
            ('TV', 'Canales vistos recientemente', RECIENTES, 'wide'),
            ('TV', 'Grabaciones recientes', 'pvr://recordings/tv/active?view=flat', 'wide'),
        ]
    return p


def defaults():
    for n in range(1, FILAS + 1):
        fila(n)
    filas = []
    pvr = xbmc.getCondVisibility('System.HasPVRAddon')
    trakt = trakt_en_umbrella()
    if pvr:
        filas.append(('Eventos destacados en TV', EVENTOS, 'wide'))
        filas.append(('Vistos recientemente', RECIENTES, 'wide'))
    if tiene(UMB):
        if trakt:
            filas += [
                ('Continuar viendo: películas', RETOMAR, 'wide'),
                ('Continuar viendo: series', SERIES, 'wide'),
                ('Mi lista: películas', LISTA + 'movies_watchlist', 'poster'),
                ('Mi lista: series', LISTA + 'shows_watchlist', 'poster'),
                ('Recomendadas para ti', U + 'movies&url=traktrecommendations', 'poster'),
                ('Mi colección: películas', LISTA + 'movies_collection', 'poster'),
            ]
        filas += [
            ('Películas en tendencia', U + 'movies&url=trakttrending', 'poster'),
            ('Series en tendencia', U + 'tvshows&url=trakttrending', 'poster'),
            ('Películas populares', U + 'tmdbmovies&url=tmdb_popular', 'poster'),
            ('Mejor valoradas', U + 'tmdbmovies&url=tmdb_toprated', 'poster'),
            ('Series populares', U + 'tmdbTvshows&url=tmdb_popular', 'poster'),
        ]
        if not trakt:
            filas += [
                ('Películas populares (Trakt)', U + 'movies&url=traktpopular', 'poster'),
                ('Se emiten hoy', U + 'tmdbTvshows&url=tmdb_airingtoday', 'poster'),
            ]
        filas.append(('Documentales', DOC_PELIS, 'poster'))  # siempre la última
    for n, (label, path, style) in enumerate(filas[:FILAS], 1):
        fila(n, path, nombre(path, label), style)
    xbmc.executebuiltin('Skin.SetBool(lemd.init18)')


def detect():
    """Resumen de lo que hay instalado (Umbrella, Trakt, TV y tiempo)."""
    partes = ['Umbrella: %s' % ('sí' if tiene(UMB) else 'no instalado'),
              'Trakt en Umbrella: %s' % ('vinculado' if trakt_en_umbrella() else 'no vinculado'),
              'TV en directo: %s' % ('sí' if xbmc.getCondVisibility('System.HasPVRAddon') else 'sin cliente PVR (instala IPTV Simple Client)'),
              'Meteorología: %s' % (xbmc.getInfoLabel('Weather.Plugin') or 'sin proveedor')]
    xbmcgui.Dialog().ok('LEMD · estado', '[CR]'.join(partes))


# ---------------------------------------------------------------- explorador
def explorar():
    """Navega por los menus de Umbrella y devuelve (ruta, nombre) de la carpeta elegida."""
    if not tiene(UMB):
        aviso('Umbrella no está instalado')
        return None
    pila = [('plugin://%s/' % UMB, 'Umbrella')]
    while pila:
        ruta, nombre = pila[-1]
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        try:
            res = rpc('Files.GetDirectory', directory=ruta, media='video', properties=['title', 'thumbnail'])
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        carpetas = [f for f in res.get('files', []) if f.get('filetype') == 'directory']
        etiquetas = ['[B]» Usar «%s» como fila[/B]' % nombre] + [f.get('label', '') for f in carpetas]
        j = xbmcgui.Dialog().select(nombre, etiquetas)
        if j < 0:
            pila.pop()
            continue
        if j == 0:
            return ruta, nombre
        f = carpetas[j - 1]
        pila.append((f['file'], f.get('label', '')))
    return None


# ---------------------------------------------------------------- tema Barajas: METAR / TAF
FUENTES_METAR = [
    'https://aviationweather.gov/api/data/metar?ids={icao}&format=raw',
    'https://tgftp.nws.noaa.gov/data/observations/metar/stations/{icao}.TXT',
]
FUENTES_TAF = [
    'https://aviationweather.gov/api/data/taf?ids={icao}&format=raw',
    'https://tgftp.nws.noaa.gov/data/forecasts/taf/stations/{icao}.TXT',
]
FENOMENOS = {
    'DZ': 'llovizna', 'RA': 'lluvia', 'SN': 'nieve', 'SG': 'cinarra', 'PL': 'hielo granulado', 'GR': 'granizo',
    'GS': 'granizo pequeño', 'UP': 'precipitación desconocida', 'BR': 'neblina', 'FG': 'niebla', 'FU': 'humo',
    'VA': 'ceniza volcánica', 'DU': 'polvo', 'SA': 'arena', 'HZ': 'calima', 'PO': 'remolinos de polvo',
    'SQ': 'turbonada', 'FC': 'nube embudo', 'SS': 'tempestad de arena', 'DS': 'tempestad de polvo',
}
DESCRIPTORES = {'MI': 'baja', 'BC': 'en bancos', 'PR': 'parcial', 'DR': 'ventisca baja', 'BL': 'ventisca alta',
                'SH': 'chubascos de', 'TS': 'tormenta con', 'FZ': 'engelante'}
NUBES = {'FEW': 'pocas nubes', 'SCT': 'nubes dispersas', 'BKN': 'muy nuboso', 'OVC': 'cubierto', 'VV': 'visibilidad vertical'}
PUNTOS = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSO', 'SO', 'OSO', 'O', 'ONO', 'NO', 'NNO']


def descargar(urls, icao):
    import urllib.request
    for u in urls:
        try:
            req = urllib.request.Request(u.format(icao=icao), headers={'User-Agent': 'Kodi-skin-LEMD'})
            txt = urllib.request.urlopen(req, timeout=10).read().decode('utf-8', 'replace').strip()
        except Exception:
            continue
        if not txt:
            continue
        # NOAA pone una primera linea con la fecha (2026/11/25 10:30): fuera
        lineas = [l.strip() for l in txt.splitlines() if l.strip() and not re.match(r'^\d{4}/\d{2}/\d{2}', l.strip())]
        if lineas:
            return ' '.join(lineas) if 'taf' in u.lower() else lineas[0]
    return ''


def decodificar_metar(m):
    """Devuelve (lista de lineas en espanol, viento (dir|None, kt, racha))."""
    import re
    out, viento = [], (None, 0, 0)
    tokens = m.replace('=', '').split()
    for t in tokens:
        if t in ('METAR', 'SPECI', 'AUTO', 'COR') or re.fullmatch(r'[A-Z]{4}', t) and not out and t not in ('CAVOK', 'NSC', 'NCD', 'SKC', 'CLR'):
            continue
        if t in ('NOSIG',):
            out.append('Tendencia: sin cambios significativos')
            break
        if t in ('BECMG', 'TEMPO'):
            out.append('Tendencia: cambios previstos (%s)' % ('temporales' if t == 'TEMPO' else 'graduales'))
            break
        mt = re.fullmatch(r'(\d{2})(\d{2})(\d{2})Z', t)
        if mt:
            out.append('Observación del día %s a las %s:%s UTC' % mt.groups())
            continue
        mw = re.fullmatch(r'(\d{3}|VRB)(\d{2,3})(?:G(\d{2,3}))?(KT|MPS)', t)
        if mw:
            d, v, g, u = mw.groups()
            f = 1.944 if u == 'MPS' else 1.0
            kt, gk = round(int(v) * f), round(int(g) * f) if g else 0
            if d == 'VRB':
                txt = 'Viento variable de %d kt' % kt
                viento = (None, kt, gk)
            elif kt == 0:
                txt = 'Viento en calma'
                viento = (None, 0, 0)
            else:
                txt = 'Viento del %s (%s°) a %d kt (%d km/h)' % (PUNTOS[int((int(d) % 360) / 22.5 + 0.5) % 16], d, kt, round(kt * 1.852))
                viento = (int(d), kt, gk)
            if gk:
                txt += ', rachas de %d kt' % gk
            out.append(txt)
            continue
        mv = re.fullmatch(r'(\d{3})V(\d{3})', t)
        if mv:
            out.append('Dirección variable entre %s° y %s°' % mv.groups())
            continue
        if t == 'CAVOK':
            out.append('CAVOK: visibilidad de 10 km o más y sin nubes significativas')
            continue
        if re.fullmatch(r'\d{4}', t):
            vis = int(t)
            out.append('Visibilidad: %s' % ('10 km o más' if vis >= 9999 else ('%d m' % vis if vis < 5000 else '%.0f km' % (vis / 1000.0))))
            continue
        if t.startswith('R') and '/' in t:
            continue  # alcance visual en pista: se omite
        mn = re.fullmatch(r'(FEW|SCT|BKN|OVC|VV)(\d{3}|///)(CB|TCU)?', t)
        if mn:
            tipo, alt, conv = mn.groups()
            txt = NUBES[tipo]
            if alt != '///':
                txt += ' a %d ft' % (int(alt) * 100)
            if conv:
                txt += ' (%s)' % ('cumulonimbos' if conv == 'CB' else 'cúmulos de gran desarrollo')
            out.append(txt[0].upper() + txt[1:])
            continue
        if t in ('NSC', 'NCD', 'SKC', 'CLR'):
            out.append('Sin nubes significativas')
            continue
        mtd = re.fullmatch(r'(M?\d{2})/(M?\d{2})', t)
        if mtd:
            tt, dd = (int(x.replace('M', '-')) for x in mtd.groups())
            out.append('Temperatura %d °C · punto de rocío %d °C' % (tt, dd))
            continue
        mq = re.fullmatch(r'Q(\d{4})', t)
        if mq:
            out.append('QNH %s hPa' % int(mq.group(1)))
            continue
        ma = re.fullmatch(r'A(\d{4})', t)
        if ma:
            out.append('Altímetro %.2f inHg' % (int(ma.group(1)) / 100.0))
            continue
        mf = re.fullmatch(r'(\+|-|VC)?(MI|BC|PR|DR|BL|SH|TS|FZ)?((?:DZ|RA|SN|SG|PL|GR|GS|UP|BR|FG|FU|VA|DU|SA|HZ|PO|SQ|FC|SS|DS)*)', t)
        if mf and (mf.group(3) or mf.group(2) == 'TS'):
            inten, desc, fen = mf.groups()
            partes = [FENOMENOS[fen[i:i + 2]] for i in range(0, len(fen), 2)]
            txt = ' y '.join(partes)
            if desc == 'TS' and not partes:
                txt, desc = 'tormenta', None
            if desc:
                txt = '%s %s' % (DESCRIPTORES[desc], txt)
            if inten == '-':
                txt += ' débil'
            elif inten == '+':
                txt += ' fuerte'
            elif inten == 'VC':
                txt += ' en las proximidades'
            out.append('Fenómeno: ' + txt)
            continue
    return out, viento


def pistas_lemd(viento):
    """Configuracion de pistas de Barajas estimada a partir del viento.
    Norte (preferente): aterrizajes 32L/32R, despegues 36L/36R.
    Sur: aterrizajes 18L/18R, despegues 14L/14R. Se cambia a Sur con viento en cola en las 32."""
    import math
    d, kt, gk = viento
    norte = 'Configuración NORTE · aterrizajes 32L/32R · despegues 36L/36R'
    sur = 'Configuración SUR · aterrizajes 18L/18R · despegues 14L/14R'
    if d is None or kt <= 5:
        return norte
    cola = -max(kt, gk or 0) * math.cos(math.radians(d - 323))
    return sur if cola > 5 else norte


def metar():
    icao = (xbmc.getInfoLabel('Skin.String(lemd.icao)') or 'LEMD').strip().upper()
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        raw = descargar(FUENTES_METAR, icao)
        taf = descargar(FUENTES_TAF, icao)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if not raw:
        xbmcgui.Dialog().ok('METAR %s' % icao, 'No se pudo descargar el METAR. Comprueba la conexión a Internet.')
        return
    lineas, viento = decodificar_metar(raw)
    pistas = pistas_lemd(viento) if icao == 'LEMD' else ''
    home = xbmcgui.Window(10000)
    home.setProperty('lemd.metar.raw', raw)
    home.setProperty('lemd.metar.resumen', ' · '.join(lineas[1:4]))
    home.setProperty('lemd.metar.pistas', pistas)
    texto = ['[B]METAR[/B]', raw, ''] + lineas
    if pistas:
        texto += ['', '[B]Pistas en uso (estimación)[/B]', pistas,
                  'Deducida del viento del METAR; la configuración real la decide el control aéreo.']
    if taf:
        texto += ['', '[B]TAF (previsión)[/B]', taf]
    xbmcgui.Dialog().textviewer('METAR / TAF · %s' % icao, '[CR]'.join(texto))


# ---------------------------------------------------------------- acciones de fila
def elegir(n):
    p = preajustes()
    etiquetas = []
    for g, l, ruta, _ in p:
        par = NOMBRES.get(ruta)
        avion = '  —  «%s»' % par[1] if par and jerga_activa() and par[1] != par[0] else ''
        etiquetas.append('%s  ·  %s%s' % (g, l, avion))
    extra = ['Explorar menús de Umbrella…', 'Escribir la ruta a mano…', 'Quitar esta fila']
    i = xbmcgui.Dialog().select('Fila %d: contenido' % n, extra[:1] + etiquetas + extra[1:])
    if i < 0:
        return
    if i == 0:
        r = explorar()
        if r:
            ruta, nombre = r
            estilo = 'wide' if any(k in ruta.lower() for k in ('episode', 'unfinished', 'progress', 'calendar', 'channel')) else 'poster'
            fila(n, ruta, nombre, estilo)
        return
    i -= 1
    if i < len(p):
        g, l, ruta, estilo = p[i]
        fila(n, ruta, nombre(ruta, re.split(r'  \[| \(aún| \(casi', l)[0]), estilo)
        return
    i -= len(p)
    if i == 0:
        ruta = xbmcgui.Dialog().input('Ruta (plugin://… o pvr://…)', skin_get(n, 'path'))
        if ruta:
            fila(n, ruta, skin_get(n, 'label') or 'Fila %d' % n, skin_get(n, 'style'))
    else:
        fila(n)


CLAVES_DEFECTO = ('fútbol, laliga, liga, champions, europa league, conference league, copa del rey, '
                  'supercopa, mundial, eurocopa, nations league, real madrid, barcelona, atlético, '
                  'derbi, clásico, fórmula 1, f1, gran premio, gp de, motogp, nba, euroliga, acb, '
                  'roland garros, wimbledon, open de australia, us open, ufc, boxeo')


def claves():
    """Palabras clave de «Vuelos destacados» (eventos de la guía)."""
    actual = xbmc.getInfoLabel('Skin.String(lemd.eventos)') or CLAVES_DEFECTO
    t = xbmcgui.Dialog().input('Palabras clave separadas por comas (vacío = las de siempre)', actual)
    if t is None:
        return
    t = t.strip()
    if not t or t == CLAVES_DEFECTO:
        xbmc.executebuiltin('Skin.Reset(lemd.eventos)')
    else:
        xbmc.executebuiltin('Skin.SetString(lemd.eventos,%s)' % escapar(t))
    aviso('Vuelos destacados se actualizará al volver a Inicio')


GEO = 'https://geocoding-api.open-meteo.com/v1/search'


def tiempo_defecto(forzar=False):
    """Si Kodi no tiene proveedor del tiempo, usa el de LEMD (Open-Meteo, sin clave)."""
    if xbmc.getInfoLabel('Weather.Plugin') and not forzar:
        return
    rpc('Settings.SetSettingValue', setting='weather.addon', value='skin.lemd')
    rpc('Settings.SetSettingValue', setting='weather.currentlocation', value=1)
    xbmc.executebuiltin('Weather.Refresh')


def ciudad():
    """Buscar y elegir la ciudad del tiempo (proveedor LEMD)."""
    import urllib.parse
    import urllib.request
    actual = xbmc.getInfoLabel('Skin.String(lemd.tiempo.nombre)') or 'Madrid'
    t = xbmcgui.Dialog().input('Ciudad para el tiempo', actual)
    if not t:
        return
    try:
        url = GEO + '?' + urllib.parse.urlencode({'name': t, 'count': 10, 'language': 'es', 'format': 'json'})
        req = urllib.request.Request(url, headers={'User-Agent': 'Kodi-skin-LEMD'})
        res = json.loads(urllib.request.urlopen(req, timeout=15).read().decode('utf-8')).get('results') or []
    except Exception:
        xbmcgui.Dialog().ok('LEMD', 'No se pudo buscar la ciudad. Comprueba la conexión a Internet.')
        return
    if not res:
        xbmcgui.Dialog().ok('LEMD', 'No he encontrado «%s».' % t)
        return
    opciones = [', '.join(x for x in (r.get('name'), r.get('admin1'), r.get('country')) if x) for r in res]
    i = xbmcgui.Dialog().select('Elige la ciudad', opciones)
    if i < 0:
        return
    r = res[i]
    xbmc.executebuiltin('Skin.SetString(lemd.tiempo.nombre,%s)' % escapar(r.get('name', t)))
    xbmc.executebuiltin('Skin.SetString(lemd.tiempo.lat,%s)' % r['latitude'])
    xbmc.executebuiltin('Skin.SetString(lemd.tiempo.lon,%s)' % r['longitude'])
    if xbmc.getInfoLabel('Weather.Plugin') in ('', 'skin.lemd', 'LEMD'):
        rpc('Settings.SetSettingValue', setting='weather.addon', value='skin.lemd')
    xbmc.sleep(300)
    xbmc.executebuiltin('Weather.Refresh')
    aviso('Tiempo de %s' % r.get('name', t))


TONOS = [('Grafito (recomendado)', 'SKINDEFAULT', 'grafito'), ('Negro', 'negro', 'negro'), ('Gris claro', 'gris', 'gris claro')]


def tono():
    """Tono del fondo de la skin (temas de color de colors/)."""
    i = xbmcgui.Dialog().select('Tono del fondo', [t[0] for t in TONOS])
    if i < 0:
        return
    xbmc.executebuiltin('Skin.SetString(lemd.tono,%s)' % TONOS[i][2])
    rpc('Settings.SetSettingValue', setting='lookandfeel.skincolors', value=TONOS[i][1])


# Cambio de canal con arriba/abajo viendo la TV. Kodi trae arriba/abajo = «ver el canal de al lado
# y pulsar OK para cambiar». LEMD pone un mapa de teclas que, SOLO en la TV a pantalla completa,
# convierte arriba/abajo en canal siguiente/anterior; Kodi cambia tras quedarse un momento en el
# canal (pvrplayback.channelentrytimeout, en ms). No se toca «Confirmar cambio de canal con OK»:
# si se quitara, Kodi cambiaria de canal al pulsar abajo en cualquier menu sin nada debajo.
ZAPPING = [('Automático tras 1 segundo', 1000, '1 s'), ('Automático tras 2 segundos (recomendado)', 2000, '2 s'),
           ('Automático tras 3 segundos', 3000, '3 s'), ('Al momento', 0, 'al momento'),
           ('Solo al pulsar OK (como trae Kodi)', None, 'con OK')]
KEYMAP = 'special://profile/keymaps/lemd_canales.xml'
KEYMAP_XML = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<!-- Creado por la skin LEMD (Ajustes de LEMD > Integraciones > Cambiar de canal con arriba/abajo).\n'
    '     Viendo la TV a pantalla completa, arriba/abajo cambian de canal. Se puede borrar. -->\n'
    '<keymap>\n  <FullscreenLiveTV>\n'
    '    <keyboard><up>ChannelUp</up><down>ChannelDown</down></keyboard>\n'
    '    <remote><up>ChannelUp</up><down>ChannelDown</down></remote>\n'
    '  </FullscreenLiveTV>\n</keymap>\n')


def zapping(elegir=False):
    i = 1
    if elegir:
        i = xbmcgui.Dialog().select('Cambiar de canal con arriba/abajo', [z[0] for z in ZAPPING])
        if i < 0:
            return
    _, espera, texto = ZAPPING[i]
    rpc('Settings.SetSettingValue', setting='pvrplayback.confirmchannelswitch', value=True)
    rpc('Settings.SetSettingValue', setting='pvrplayback.channelentrytimeout', value=espera or 0)
    if espera is None:
        if xbmcvfs.exists(KEYMAP):
            xbmcvfs.delete(KEYMAP)
    else:
        xbmcvfs.mkdirs('special://profile/keymaps/')
        with xbmcvfs.File(KEYMAP, 'w') as f:
            f.write(KEYMAP_XML)
    xbmc.executebuiltin('Action(reloadkeymaps)')
    xbmc.executebuiltin('Skin.SetString(lemd.zapping,%s)' % texto)
    xbmc.executebuiltin('Skin.SetBool(lemd.zapping2)')


# ---------------------------------------------------------------- temporizador de apagado
# En el Fire TV, «apagar» Kodi es cerrarlo: Android no deja a las apps apagar ni dormir el
# aparato. Al cerrarse Kodi, el Fire TV se duerme solo pasado su «Tiempo de suspensión».
def _segundos(etiqueta):
    try:
        p = [int(x) for x in xbmc.getInfoLabel(etiqueta).split(':')]
    except ValueError:
        return 0
    seg = 0
    for x in p:
        seg = seg * 60 + x
    return seg


def apagado():
    opciones, segundos = [], []
    if xbmc.getCondVisibility('Player.HasVideo'):
        if xbmc.getCondVisibility('VideoPlayer.Content(livetv)'):
            resto = _segundos('PVR.EpgEventRemainingTime(hh:mm:ss)')
            texto = 'Al terminar el programa de ahora'
        else:
            resto = _segundos('Player.TimeRemaining(hh:mm:ss)')
            texto = 'Al terminar lo que estoy viendo'
        if resto > 60:
            opciones.append('%s (en %d min)' % (texto, round(resto / 60.0)))
            segundos.append(resto + 30)
    for m in (15, 30, 45, 60, 90, 120, 180):
        opciones.append({60: 'Dentro de 1 hora', 90: 'Dentro de 1 hora y media', 120: 'Dentro de 2 horas',
                         180: 'Dentro de 3 horas'}.get(m, 'Dentro de %d minutos' % m))
        segundos.append(m * 60)
    i = xbmcgui.Dialog().select('Temporizador de apagado', opciones)
    if i < 0:
        return
    seg = segundos[i]
    xbmc.executebuiltin('CancelAlarm(shutdowntimer,true)')
    xbmc.executebuiltin('AlarmClock(shutdowntimer,RunScript(skin.lemd,apagar),%d:%02d,silent)' % (seg // 60, seg % 60))
    xbmcgui.Dialog().notification('Temporizador de apagado', 'Kodi se cerrará en %d min (antes avisa 30 s).' % round(seg / 60.0),
                                  xbmcgui.NOTIFICATION_INFO, 5000)


def apagar():
    """Lo lanza el temporizador: 30 s de aviso para poder cancelarlo y luego cierra Kodi."""
    dp = xbmcgui.DialogProgress()
    dp.create('Temporizador de apagado', 'Kodi se cierra en 30 s. Pulsa Cancelar para seguir viendo.')
    for n in range(30, 0, -1):
        if dp.iscanceled():
            dp.close()
            return
        dp.update(int((30 - n) * 100 / 30), 'Kodi se cierra en %d s. Pulsa Cancelar para seguir viendo.' % n)
        if xbmc.Monitor().waitForAbort(1):
            return
    dp.close()
    xbmc.executebuiltin('PlayerControl(Stop)')
    xbmc.sleep(800)
    xbmc.executebuiltin('Quit()')


# ---------------------------------------------------------------- modo ligero (Fire TV de 1-2 GB)
AVANZADOS = 'special://profile/advancedsettings.xml'
AVANZADOS_XML = (
    '<advancedsettings version="1.0">\n'
    '  <!-- Creado por la skin LEMD: imagenes mas pequenas = menos memoria y cache mas ligera. -->\n'
    '  <imageres>540</imageres>\n'
    '  <fanartres>720</fanartres>\n'
    '</advancedsettings>\n')


def memoria_mb():
    try:
        return int(''.join(c for c in xbmc.getInfoLabel('System.Memory(total)') if c.isdigit()))
    except ValueError:
        return 0


def optimizar(auto=False):
    """Ajustes que bajan memoria y CPU sin quitar nada que se vea. Solo toca lo que esta en su
    valor de serie (si alguien lo cambio a mano, se respeta)."""
    hecho = []
    mem = memoria_mb()

    def poner(ajuste, valor, si_es, texto):
        r = rpc('Settings.GetSettingValue', setting=ajuste)
        if r.get('value') == si_es:
            rpc('Settings.SetSettingValue', setting=ajuste, value=valor)
            hecho.append(texto)
    poner('epg.preventupdateswhileplayingtv', True, False, 'La guía no se actualiza mientras ves la TV')
    poner('epg.futuredaystodisplay', 2, 3, 'Guía: 2 días por delante en vez de 3 (menos memoria)')
    poner('lookandfeel.enablerssfeeds', False, True, 'Noticias RSS desactivadas')
    poner('filelists.showparentdiritems', False, True, 'Sin la casilla «..» al principio de las listas (Atrás del mando hace lo mismo)')
    # tamaño de la interfaz (Android): en 4K sin limite gasta mucha memoria grafica
    gui = rpc('Settings.GetSettingValue', setting='videoscreen.limitgui').get('value')
    if mem and mem < 1700 and gui in (0, 1080, 9999):
        rpc('Settings.SetSettingValue', setting='videoscreen.limitgui', value=720)
        xbmc.executebuiltin('Skin.SetString(lemd.interfaz,720p)')
        hecho.append('Interfaz de Kodi a 720p (poca memoria; el vídeo sigue a su resolución)')
    elif gui == 9999:
        rpc('Settings.SetSettingValue', setting='videoscreen.limitgui', value=1080)
        xbmc.executebuiltin('Skin.SetString(lemd.interfaz,1080p)')
        hecho.append('Interfaz de Kodi limitada a 1080p (el vídeo sigue a su resolución)')
    if not xbmcvfs.exists(AVANZADOS):
        with xbmcvfs.File(AVANZADOS, 'w') as f:
            f.write(AVANZADOS_XML)
        hecho.append('Carteles y fondos a menor resolución (al reiniciar Kodi)')
    b = bufer_video()
    if b:
        hecho.append(b)
    if mem and mem < 1700 and not xbmc.getCondVisibility('Skin.HasSetting(lemd.pocamem)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.pocamem)')  # filas de Inicio solo al bajar
        hecho.append('Filas de Inicio: se cargan al bajar (no todas a la vez)')
    if mem and mem < 1700 and not xbmc.getCondVisibility('Skin.HasSetting(lemd.noanim)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.noanim)')
        hecho.append('Sin animaciones (este aparato tiene %d MB de memoria)' % mem)
    xbmc.executebuiltin('Skin.SetBool(lemd.opt1)')
    if auto:
        return
    texto = ['Memoria del aparato: %s' % ('%d MB' % mem if mem else 'desconocida'), '']
    texto += ['· ' + h for h in hecho] if hecho else ['Ya estaba todo optimizado.']
    texto += ['', 'Además, LEMD ya carga las filas de Inicio poco a poco (al bajar), y la mini pantalla '
              'y los fondos solo usan memoria mientras se ven. Para que vaya aún más ligero: '
              'quita filas que no uses (Filas de Inicio) y deja en Kodi solo los grupos de canales '
              'que veas (Integraciones › Elegir grupos de canales).']
    xbmcgui.Dialog().textviewer('Optimizar para el Fire TV', '[CR]'.join(texto))


# ---------------------------------------------------------------- optimizar mas (1.9.11)
OPT_MAS = xbmcvfs.translatePath('special://profile/addon_data/skin.lemd/optimizar_mas.json')
# (ajuste, valor nuevo, texto). Solo se tocan si estan en otro valor; lo de antes se guarda
# para «Deshacer». (1.9.12: tambien el servidor de eventos y Zeroconf, que solo usan las apps de
# mando del movil (Kore, Yatse); LEMD habla con Kodi por dentro y el mando del Fire TV no los usa.)
OPT_AJUSTES = [
    ('services.esenabled', False, 'Control desde otras apps (servidor de eventos): apagado'),
    ('services.zeroconf', False, 'Anunciar Kodi en la red (Zeroconf): apagado'),
    ('services.upnp', False, 'Compartir en red (UPnP): apagado'),
    ('services.upnpserver', False, 'Servidor UPnP: apagado'),
    ('services.upnprenderer', False, 'Reproductor UPnP: apagado'),
    ('services.upnpcontroller', False, 'Control UPnP: apagado'),
    ('services.airplay', False, 'AirPlay: apagado'),
    ('epg.pastdaystodisplay', 1, 'Guía de TV: 1 día hacia atrás (antes %s)'),
    ('debug.showloginfo', False, 'Registro de depuración: apagado'),
    ('debug.extralogging', False, 'Registro extra: apagado'),
]


def _leer_json(ruta, defecto):
    try:
        with open(ruta, encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return defecto


def _guardar_json(ruta, datos):
    try:
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
        with open(ruta, 'w', encoding='utf-8') as fh:
            json.dump(datos, fh)
    except OSError as e:
        xbmc.log('[LEMD] guardar %s: %s' % (ruta, e), xbmc.LOGWARNING)


def limpieza(dias=60, maximo=4000):
    """Zips de instalacion viejos (addons/packages) y caratulas guardadas que no se usan desde
    hace «dias». Las caratulas se quitan con la API de Kodi (borra fichero y registro)."""
    hecho = []
    pk = xbmcvfs.translatePath('special://home/addons/packages/')
    libres, n = 0, 0
    try:
        for f in os.listdir(pk):
            ruta = os.path.join(pk, f)
            if f.lower().endswith('.zip') and os.path.isfile(ruta):
                libres += os.path.getsize(ruta)
                os.remove(ruta)
                n += 1
    except OSError:
        pass
    if n:
        hecho.append('Paquetes de instalación borrados: %d (%d MB)' % (n, libres // 1048576))
    s = borrar_subtitulos(horas=1)
    if s:
        hecho.append('Subtítulos descargados borrados: %d' % s)
    limite = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - dias * 86400))
    viejas = rpc('Textures.GetTextures', properties=['sizes'],
                 filter={'field': 'lastused', 'operator': 'lessthan', 'value': limite}).get('textures') or []
    borradas = 0
    for t in viejas[:maximo]:
        usos = [z.get('lastused') or '' for z in t.get('sizes') or []]
        if usos and max(usos) and max(usos) < limite:  # ningun tamano usado desde entonces
            rpc('Textures.RemoveTexture', textureid=t['textureid'])
            borradas += 1
    if borradas:
        hecho.append('Carátulas sin usar en %d días borradas de la caché: %d' % (dias, borradas))
    xbmc.executebuiltin('Skin.SetString(lemd.limpieza,%s)' % time.strftime('%Y%m%d'))
    return hecho


SUB_EXT = ('.srt', '.ass', '.ssa', '.sub', '.idx', '.smi', '.vtt')
A4K = 'service.subtitles.a4ksubtitles'


def borrar_subtitulos(horas=12):
    """Subtitulos descargados que ya no se usan, con mas de «horas» (nunca el de lo que se ve
    ahora): los que Kodi deja en su carpeta temporal y todo lo de la temporal de a4kSubtitles."""
    limite = time.time() - horas * 3600
    n = 0

    def quitar(ruta):
        try:
            if os.path.getmtime(ruta) < limite:
                os.remove(ruta)
                return 1
        except OSError:
            pass
        return 0
    tmp = xbmcvfs.translatePath('special://temp/')
    try:
        for f in os.listdir(tmp):  # solo la carpeta de arriba (no la cache de add-ons)
            if f.lower().endswith(SUB_EXT) and os.path.isfile(os.path.join(tmp, f)):
                n += quitar(os.path.join(tmp, f))
    except OSError:
        pass
    a4k = xbmcvfs.translatePath('special://profile/addon_data/%s/temp/' % A4K)
    for raiz, _, ficheros in os.walk(a4k):
        for f in ficheros:
            n += quitar(os.path.join(raiz, f))
    return n


def ajustar_a4k():
    """a4kSubtitles: fuera las fuentes que piden cuenta o clave si no hay (sin ella se quedan
    esperando hasta agotar el tiempo y la busqueda parecia colgada) y espera maxima de 8 s."""
    if not tiene(A4K):
        return
    try:
        a = xbmcaddon.Addon(A4K)
        for fuente, clave in (('opensubtitles', 'opensubtitles.username'), ('subdl', 'subdl.apikey'),
                              ('subsource', 'subsource.apikey')):
            if not a.getSetting(clave) and a.getSetting(fuente + '.enabled') != 'false':
                a.setSetting(fuente + '.enabled', 'false')
        try:
            if int(float(a.getSetting('general.timeout') or 15)) > 8:
                a.setSetting('general.timeout', '8')
        except ValueError:
            pass
    except Exception as e:
        xbmc.log('[LEMD] a4k: %s' % e, xbmc.LOGWARNING)


def idiomas_subtitulos():
    """Kodi busca subtitulos solo en ingles de serie: si es asi, espanol primero y luego ingles."""
    actual = rpc('Settings.GetSettingValue', setting='subtitles.languages').get('value')
    if isinstance(actual, list) and actual in (['English'], []):
        rpc('Settings.SetSettingValue', setting='subtitles.languages', value=['Spanish', 'English'])
        return True
    return False


def audio_espanol(manual=False):
    """Audio y subtitulos en espanol: Kodi elige la pista de audio en espanol si el archivo la trae;
    si no, subtitulos en espanol (y si no hay, en ingles), bajando solo el primero con a4kSubtitles.
    El audio depende del archivo que elige Umbrella: si solo viene en ingles, no se puede cambiar.
    Sin «manual», solo cambia lo que sigue como viene de serie."""
    hecho = []

    def poner(ajuste, valor, de_serie, texto):
        actual = rpc('Settings.GetSettingValue', setting=ajuste).get('value')
        if actual is None or actual == valor or (not manual and actual not in de_serie):
            return
        rpc('Settings.SetSettingValue', setting=ajuste, value=valor)
        hecho.append(texto)
    poner('locale.audiolanguage', 'Spanish', ('mediadefault', 'original', 'default'), 'Audio: en español si el archivo lo trae')
    poner('locale.subtitlelanguage', 'Spanish', ('original', 'default', 'none'), 'Subtítulos preferidos: español')
    poner('subtitles.languages', ['Spanish', 'English'], (['English'], []), 'Buscar subtítulos en español e inglés')
    if tiene(A4K):
        ajustar_a4k()
        poner('subtitles.movie', A4K, ('',), 'Servicio de subtítulos de películas: a4kSubtitles')
        poner('subtitles.tv', A4K, ('',), 'Servicio de subtítulos de series: a4kSubtitles')
        poner('subtitles.downloadfirst', True, (False,), 'Bajar solo el primer subtítulo si el vídeo no trae en español')
    if tiene(UMB):
        try:
            a = xbmcaddon.Addon(UMB)
            if manual or a.getSetting('subtitles.lang.1') in ('', 'English'):
                if a.getSetting('subtitles.lang.1') != 'Spanish':
                    a.setSetting('subtitles.lang.1', 'Spanish')
                    a.setSetting('subtitles.lang.2', 'English')
                    hecho.append('Umbrella: subtítulos en español (y si no, inglés)')
        except Exception as e:
            xbmc.log('[LEMD] umbrella subtitulos: %s' % e, xbmc.LOGWARNING)
    if manual:
        texto = ['[B]Hecho:[/B]'] + ['· ' + h for h in hecho] if hecho else ['Ya estaba todo en español.']
        if not tiene(A4K):
            texto += ['', 'Para que los subtítulos se bajen solos falta un servicio de subtítulos: en el reproductor, '
                      'botón de subtítulos › [B]Descargar de Internet…[/B] (LEMD ofrece instalar a4kSubtitles).']
        texto += ['', '[B]Ojo:[/B] el audio sale del archivo que elige Umbrella. Si ese archivo solo trae inglés, no hay '
                  'otra pista que poner: en la lista de fuentes de Umbrella busca las que dicen SPANISH, CASTELLANO, '
                  'MULTI o DUAL.']
        xbmcgui.Dialog().textviewer('Audio y subtítulos en español', '[CR]'.join(texto))
    return hecho


def colores_umbrella():
    """Umbrella pinta «Nueva busqueda», el historial y otros con su color de resaltado; si es claro
    (amarillo, verde neon...) no se lee sobre el fondo blanco de lo enfocado: naranja oscuro."""
    if not tiene(UMB):
        return False
    try:
        a = xbmcaddon.Addon(UMB)
        c = (a.getSetting('highlight.color') or '').strip()
        if len(c) == 8:
            r, g, b = int(c[2:4], 16), int(c[4:6], 16), int(c[6:8], 16)
            if (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.55:
                a.setSetting('highlight.color', 'FFD2600A')
                a.setSetting('highlight.color.display', '[COLOR=FFD2600A]FFD2600A[/COLOR]')
                return True
    except Exception as e:
        xbmc.log('[LEMD] color umbrella: %s' % e, xbmc.LOGWARNING)
    return False


def limpieza_mensual():
    """Al arrancar: si hace mas de 30 dias de la ultima limpieza (o nunca), se hace sola."""
    ultima = xbmc.getInfoLabel('Skin.String(lemd.limpieza)')
    try:
        hace = (time.time() - time.mktime(time.strptime(ultima, '%Y%m%d'))) / 86400 if ultima else 999
    except ValueError:
        hace = 999
    if hace >= 30 and not xbmc.getCondVisibility('Player.HasMedia'):
        h = limpieza()
        xbmc.log('[LEMD] limpieza mensual: %s' % '; '.join(h), xbmc.LOGINFO)


def optimizar_mas(auto=False):
    antes = _leer_json(OPT_MAS, {})
    hecho = []
    for ajuste, valor, texto in OPT_AJUSTES:
        actual = rpc('Settings.GetSettingValue', setting=ajuste).get('value')
        if actual is None or actual == valor:
            continue  # no existe en este Kodi o ya esta bien
        if ajuste == 'epg.pastdaystodisplay' and isinstance(actual, int) and actual < valor:
            continue
        antes.setdefault(ajuste, actual)
        rpc('Settings.SetSettingValue', setting=ajuste, value=valor)
        hecho.append(texto % actual if '%s' in texto else texto)
    _guardar_json(OPT_MAS, antes)
    hecho += limpieza()
    xbmc.executebuiltin('Skin.SetBool(lemd.opt2)')
    if auto:
        if hecho:
            xbmcgui.Dialog().notification('LEMD', 'Optimizado: %d cambios (Rendimiento › Optimizar más)' % len(hecho),
                                          xbmcgui.NOTIFICATION_INFO, 6000)
        return hecho
    texto = ['· ' + h for h in hecho] if hecho else ['Ya estaba todo optimizado.']
    texto += ['', 'Si algún día usas una app de mando en el móvil (Kore, Yatse), vuelve a encender en Ajustes › '
              'Servicios › Control «Permitir control remoto desde aplicaciones» y Zeroconf, o pulsa Rendimiento › '
              'Deshacer «Optimizar más». La limpieza de la caché se repite sola una vez al mes.']
    xbmcgui.Dialog().textviewer('Optimizar más', '[CR]'.join(texto))
    return hecho


def deshacer_optimizar_mas():
    antes = _leer_json(OPT_MAS, {})
    if not antes:
        xbmcgui.Dialog().ok('Optimizar más', 'No hay nada que deshacer.')
        return
    for ajuste, valor in antes.items():
        rpc('Settings.SetSettingValue', setting=ajuste, value=valor)
    _guardar_json(OPT_MAS, {})
    xbmcgui.Dialog().ok('Optimizar más', 'Vuelven los ajustes de antes (%d). Las carátulas borradas de la caché se '
                        'vuelven a descargar solas cuando hagan falta.' % len(antes))


# ---------------------------------------------------------------- add-ons que arrancan con Kodi
SERVICIOS_INFO = {
    'plugin.video.umbrella': 'Sincroniza con Trakt (lo visto, lo que dejas a medias, tus listas) y refresca las '
                             'filas de Inicio. Necesario para «Retomar vuelo» y «Mi tarjeta de embarque».',
    'plugin.video.youtube': 'Mantenimiento del add-on de YouTube (sesión y caché). LEMD ya no lo usa: si no ves YouTube en Kodi, se puede desinstalar.',
    'service.xbmc.versioncheck': 'Avisa cuando sale una versión nueva de Kodi. En el Fire TV Kodi se actualiza aparte '
                                 '(tienda o descarga), así que no aporta nada: se puede desactivar.',
    'service.subtitles.a4ksubtitles': 'Servicio de subtítulos de Internet (lo usa «Descargar de Internet…»).',
    'script.module.resolveurl': 'Ayuda a otros add-ons a abrir enlaces de vídeo.',
    'service.upnext': 'Ofrece el siguiente episodio al acabar uno.',
    'script.trakt': 'Marca en Trakt lo que ves. Umbrella ya lo hace: tenerlo duplicado no hace falta.',
    'service.iptv.manager': 'Junta listas y guías de varios add-ons de TV para IPTV Simple.',
    'weather.multi': 'Proveedor del tiempo.',
    'inputstream.ffmpegdirect': 'Lo usa IPTV Simple para reproducir los canales (y poder pausar o retroceder la '
                                'tele). Imprescindible para la TV: no tocar.',
    'inputstream.adaptive': 'Reproduce vídeo por partes (HLS/DASH): lo usan Umbrella, YouTube y algunos canales. '
                            'Imprescindible: no tocar.',
    'repository.lemd': 'Repositorio de LEMD (no arranca nada por sí solo).',
}
NO_TOCAR = ('skin.lemd', 'resource.', 'pvr.')


def _puntos_addon(ruta):
    """Extensiones (point=...) que declara el addon.xml de un add-on."""
    try:
        with open(os.path.join(xbmcvfs.translatePath(ruta or ''), 'addon.xml'), encoding='utf-8') as fh:
            return re.findall(r'<extension[^>]*point="([^"]+)"', fh.read())
    except Exception:
        return []


def servicios():
    """Add-ons con un servicio que se pone en marcha al encender Kodi: que son y para que sirven.
    Solo se ofrece desactivar los que son un servicio suelto (si el servicio va dentro de un
    add-on que se usa, como Umbrella, desactivarlo apagaria el add-on entero)."""
    r = rpc('Addons.GetAddons', type='xbmc.service', enabled=True,
            properties=['name', 'summary', 'description', 'author', 'thumbnail', 'path'])
    lista = []
    for a in r.get('addons') or []:
        # Kodi devuelve aqui tambien add-ons que no son servicios (p. ej. el inputstream de la TV)
        # y como «type» repite el pedido: se mira el addon.xml de verdad
        puntos = _puntos_addon(a.get('path'))
        if 'xbmc.service' not in puntos:
            continue
        a['type'] = 'xbmc.service' if set(puntos) <= {'xbmc.service', 'xbmc.addon.metadata'} else 'otro'
        lista.append(a)
    pvr = rpc('Addons.GetAddons', type='kodi.pvrclient', enabled=True, properties=['name', 'summary']).get('addons') or []
    if not lista and not pvr:
        xbmcgui.Dialog().ok('Add-ons que arrancan con Kodi', 'Ninguno: Kodi arranca limpio.')
        return
    while True:
        elementos, datos = [], []
        for a in sorted(lista, key=lambda x: (x.get('type') != 'xbmc.service', x.get('name', '').lower())):
            aid = a.get('addonid', '')
            texto = SERVICIOS_INFO.get(aid) or a.get('summary') or a.get('description') or ''
            suelto = a.get('type') == 'xbmc.service'
            li = xbmcgui.ListItem(re.sub(r'\[/?[A-Z]+[^\]]*\]', '', a.get('name') or aid),
                                  ('Servicio suelto · ' if suelto else 'Va dentro del add-on · ') + texto)
            li.setArt({'icon': a.get('thumbnail') or 'DefaultAddonService.png'})
            elementos.append(li)
            datos.append((a, texto, suelto))
        for a in pvr:
            li = xbmcgui.ListItem(a.get('name') or a.get('addonid'), 'TV en directo · Carga tus canales y la guía al encender.')
            li.setArt({'icon': 'DefaultAddonPVRClient.png'})
            elementos.append(li)
            datos.append((a, 'Cliente de TV en directo: carga los canales y la guía al encender Kodi. Para que '
                             'arranque antes: Integraciones › Elegir grupos de canales.', None))
        i = xbmcgui.Dialog().select('Add-ons que arrancan con Kodi (%d)' % len(elementos), elementos, useDetails=True)
        if i < 0:
            return
        a, texto, suelto = datos[i]
        aid = a.get('addonid', '')
        nombre_a = re.sub(r'\[/?[A-Z]+[^\]]*\]', '', a.get('name') or aid)
        if suelto and not aid.startswith(NO_TOCAR):
            if xbmcgui.Dialog().yesno(nombre_a, '%s[CR][CR]¿Desactivarlo? (se puede volver a activar en Add-ons › Mis '
                                      'add-ons › Servicios)' % texto, nolabel='Dejarlo', yeslabel='Desactivar'):
                rpc('Addons.SetAddonEnabled', addonid=aid, enabled=False)
                lista = [x for x in lista if x.get('addonid') != aid]
                xbmcgui.Dialog().notification('LEMD', '%s desactivado' % nombre_a, xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            extra = '' if suelto is None else ('[CR][CR]Este servicio va dentro del add-on: desactivarlo apagaría '
                                               'el add-on entero, así que mejor dejarlo.')
            xbmcgui.Dialog().ok(nombre_a, texto + extra)


def interfaz():
    """Tamaño al que Kodi dibuja la interfaz (solo Android). En Kodi esta escondido en
    Ajustes › Sistema › Pantalla con el nivel «Avanzado»."""
    actual = rpc('Settings.GetSettingValue', setting='videoscreen.limitgui').get('value')
    if actual is None:
        xbmcgui.Dialog().ok('Tamaño de la interfaz', 'Este ajuste solo existe en Kodi para Android (Fire TV).')
        return
    ops = [(720, '720p: menos memoria (recomendado con 1-1,5 GB)'), (1080, '1080p: más nítido (2 GB o más)'),
           (0, 'Automático (lo decide Kodi)'), (9999, 'Sin límite (4K: mucha memoria)')]
    pre = next((i for i, (v, _) in enumerate(ops) if v == actual), -1)
    i = xbmcgui.Dialog().select('Tamaño de la interfaz', [t for _, t in ops], preselect=pre)
    if i < 0:
        return
    rpc('Settings.SetSettingValue', setting='videoscreen.limitgui', value=ops[i][0])
    xbmc.executebuiltin('Skin.SetString(lemd.interfaz,%s)' % ops[i][1].split(':')[0].split(' (')[0])
    xbmcgui.Dialog().ok('Tamaño de la interfaz', 'Hecho. Se nota del todo al reiniciar Kodi. El vídeo se sigue viendo a '
                        'su resolución: esto solo cambia menús y textos.')


# ---------------------------------------------------------------- sonidos
SONIDOS = 'resource.uisounds.lemd'


def poner_sonidos(instalar=True):
    """Deja Kodi listo para los sonidos de cabina. Devuelve la lista de cambios hechos.
    Kodi no suena nada (ni el «pim-pum») si los sonidos de la interfaz estan en «Nunca» o el
    paquete de sonidos en «Ninguno»."""
    hecho = []
    det = rpc('Addons.GetAddonDetails', addonid=SONIDOS, properties=['enabled']).get('addon') or {}
    if det and not det.get('enabled'):
        # instalado pero desactivado: Kodi no lo ofrece en Ajustes › Interfaz › Sonidos
        rpc('Addons.SetAddonEnabled', addonid=SONIDOS, enabled=True)
        xbmc.sleep(800)
        hecho.append('Activado el paquete «LEMD · sonidos de cabina» (estaba desactivado)')
    if not xbmc.getCondVisibility('System.HasAddon(%s)' % SONIDOS) and instalar:
        # la skin lo descarga e instala ella misma (no hace falta el repositorio LEMD en Kodi)
        import actualizar_skin
        if actualizar_skin.instalar_sonidos():
            hecho.append('Instalados los sonidos de cabina')
    if xbmc.getCondVisibility('System.HasAddon(%s)' % SONIDOS) and \
            rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value') != SONIDOS:
        rpc('Settings.SetSettingValue', setting='lookandfeel.soundskin', value=SONIDOS)
        if rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value') == SONIDOS:
            hecho.append('Sonidos de la interfaz: LEMD · sonidos de cabina')
        else:
            hecho.append('[COLOR red]Kodi no ha aceptado el paquete de cabina[/COLOR]')
    if not rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value'):
        # sin paquete elegido Kodi no suena nada: al menos los de serie
        rpc('Settings.SetSettingValue', setting='lookandfeel.soundskin', value='resource.uisounds.kodi')
        hecho.append('Sonidos de la interfaz: los de Kodi (estaban en «Ninguno»)')
    if rpc('Settings.GetSettingValue', setting='audiooutput.guisoundmode').get('value') == 0:
        rpc('Settings.SetSettingValue', setting='audiooutput.guisoundmode', value=1)
        hecho.append('Reproducir sonidos de la interfaz: «solo cuando no se reproduce nada» (estaba en «Nunca»)')
    vol = rpc('Settings.GetSettingValue', setting='audiooutput.guisoundvolume').get('value')
    if isinstance(vol, int) and vol < 60:
        rpc('Settings.SetSettingValue', setting='audiooutput.guisoundvolume', value=100)
        hecho.append('Volumen de los sonidos de la interfaz: 100 %% (estaba en %d %%)' % vol)
    if rpc('Settings.GetSettingValue', setting='audiooutput.streamsilence').get('value') == 0:
        # con el audio «dormido», el Fire TV tarda en despertarlo y un sonido corto se pierde
        rpc('Settings.SetSettingValue', setting='audiooutput.streamsilence', value=1)
        hecho.append('Mantener el audio despierto 1 minuto (si no, los sonidos cortos se pierden)')
    return hecho


SIGUIENTE = ('next page', 'página siguiente', 'pagina siguiente', 'siguiente', 'next', 'más…', 'more')


def _ruta_siguiente(cid=None):
    """Ruta del elemento «pagina siguiente» de la lista que se ve (o None). Umbrella lo pone al
    final (SpecialSort=bottom, «Next Page»). Se mira la lista de la ventana (Container sin numero:
    vale aunque el foco no este en las caratulas) y, si no esta al final, toda la lista."""
    pre = 'Container(%s).' % cid if cid else 'Container.'
    try:
        n = int(xbmc.getInfoLabel(pre + 'NumItems') or 0)
    except ValueError:
        return None
    actual = xbmc.getInfoLabel('Container.FolderPath')

    def mira(i):
        base = '%sListItemAbsolute(%d).' % (pre, i)
        ruta = xbmc.getInfoLabel(base + 'FolderPath')
        if not ruta or ruta == actual:
            return None
        etiqueta = re.sub(r'\[/?[A-Z]+[^\]]*\]', '', xbmc.getInfoLabel(base + 'Label')).strip().lower()
        especial = xbmc.getInfoLabel(base + 'Property(SpecialSort)') == 'bottom'
        pagina = re.search(r'(page|pagina)(%3d|=)\d+|action=\w*page', ruta, re.I)
        if especial or etiqueta.startswith(SIGUIENTE) or (pagina and 'next' in etiqueta):
            return ruta
        return None
    for i in [n - 1, n, n - 2] + list(range(n - 3, -1, -1)):  # primero el final
        if 0 <= i <= n:
            r = mira(i)
            if r:
                return r
    if n:
        ult = '%sListItemAbsolute(%d).' % (pre, n - 1)
        xbmc.log('[LEMD] sin pagina siguiente en %s (%d elementos; ultimo: %s | %s)' % (
            actual, n, xbmc.getInfoLabel(ult + 'Label'), xbmc.getInfoLabel(ult + 'FolderPath')), xbmc.LOGINFO)
    return None


def ver_canal(canal, inicio=0, titulo=''):
    """Pone un canal de TV (filas «Vuelos destacados» y «Ultimas puertas» y su «Ver todo»). Si el
    evento aun no ha empezado, pregunta antes. (Se perdio sin querer en 1.9.17: vuelve en 1.9.32.)"""
    from urllib.parse import unquote
    titulo = unquote(titulo or '')
    if inicio and inicio > time.time() + 60:
        from datetime import datetime
        import fuente
        hora = fuente.cuando(datetime.fromtimestamp(inicio), datetime.now())
        if not xbmcgui.Dialog().yesno('LEMD', '«%s» empieza %s.[CR]¿Poner el canal ahora?' % (
                titulo, hora.lower() if hora.startswith(('Hoy', 'Mañana')) else 'el ' + hora.lower())):
            return
    if not canal:
        return
    # si no arranca, Kodi muestra su aviso de error y la skin le anade la ayuda (otra opcion / reiniciar)
    rpc('Player.Open', item={'channelid': int(canal)})


def siguiente():
    """Abajo en la ultima fila (o derecha en la ultima) de una lista de add-on: su pagina
    siguiente, con la misma vista."""
    ruta = _siguiente_lemd() or _ruta_siguiente()
    if ruta:
        xbmc.executebuiltin('Container.Update(%s)' % escapar(ruta))
        xbmc.sleep(800)
        carteles()
    else:
        xbmcgui.Dialog().notification('LEMD', 'No hay más páginas', xbmcgui.NOTIFICATION_INFO, 2500)


def instalar_addon(addon_id, espera=90):
    """Pide a Kodi instalar un add-on de sus repositorios (Kodi pregunta) y espera a que este."""
    if tiene(addon_id):
        return True
    xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
    actividad = False
    for i in range(espera * 2):
        xbmc.sleep(500)
        if tiene(addon_id):
            return True
        if xbmc.getCondVisibility('System.HasActiveModalDialog | Window.IsVisible(extendedprogressdialog)'):
            actividad = True  # Kodi pregunta o esta descargando
        elif i >= 10 and not actividad:
            break  # Kodi no lo encuentra en sus repositorios (no sale nada)
        if xbmc.Monitor().abortRequested():
            break
    return tiene(addon_id)


SUBS_RECOMENDADO = 'service.subtitles.a4ksubtitles'  # varias fuentes (OpenSubtitles, SubDL...), sin cuenta


def descargar_subtitulos():
    servicios = rpc('Addons.GetAddons', type='kodi.subtitle.module', enabled=True).get('addons') or []
    if not servicios:
        if not xbmcgui.Dialog().yesno('Subtítulos', 'Para buscar subtítulos en Internet Kodi necesita un servicio de '
                                      'subtítulos y no tienes ninguno.[CR][CR]¿Instalar [B]a4kSubtitles[/B]? (busca en '
                                      'OpenSubtitles, SubDL y otras; no hace falta cuenta)',
                                      nolabel='No', yeslabel='Instalar'):
            return
        if not instalar_addon(SUBS_RECOMENDADO):
            # no esta en los repositorios de este Kodi: la lista de servicios disponibles
            xbmcgui.Dialog().ok('Subtítulos', 'Elige un servicio de subtítulos de la lista (por ejemplo OpenSubtitles) '
                                'e instálalo; luego vuelve a «Descargar de Internet».')
            xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://repository.xbmc.org/kodi.subtitle.module/,return)')
            return
    ajustar_a4k()
    idiomas_subtitulos()
    xbmc.executebuiltin('ActivateWindow(SubtitleSearch)')


ES_AUDIO = ('spa', 'es', 'esp', 'cas', 'spanish', 'español', 'espanol', 'castellano', 'latino')


def _es_espanol(pista):
    texto = ('%s %s' % (pista.get('language') or '', pista.get('name') or '')).lower()
    return any(re.search(r'(^|[^a-z])%s([^a-z]|$)' % re.escape(c), texto) for c in ES_AUDIO)


def comprobar_idioma():
    """Al empezar una pelicula o un episodio (VideoFullScreen): si no trae audio en espanol (ni
    subtitulos en espanol puestos), avisa con dos salidas: subtitulos en espanol o elegir otra fuente
    en Umbrella. Una vez por video; solo con Kodi en espanol; nunca en TV en directo."""
    if xbmc.getCondVisibility('Skin.HasSetting(lemd.noidioma) | VideoPlayer.Content(livetv) | !Player.HasVideo'):
        return
    if not (rpc('Settings.GetSettingValue', setting='locale.language').get('value') or '').startswith('resource.language.es'):
        return
    home = xbmcgui.Window(10000)
    archivo = xbmc.getInfoLabel('Player.Filenameandpath')
    if not archivo or home.getProperty('lemd.idioma.visto') == archivo:
        return
    home.setProperty('lemd.idioma.visto', archivo)
    jug = rpc('Player.GetActivePlayers')
    jug = [j for j in (jug if isinstance(jug, list) else []) if j.get('type') == 'video']
    if not jug:
        return
    pid, pr = jug[0]['playerid'], {}
    mon = xbmc.Monitor()
    for _ in range(40):  # las pistas tardan un poco en salir (video de Internet)
        pr = rpc('Player.GetProperties', playerid=pid,
                 properties=['audiostreams', 'subtitles', 'currentsubtitle', 'subtitleenabled'])
        if pr.get('audiostreams') or mon.waitForAbort(0.5):
            break
    audio = pr.get('audiostreams') or []
    if not audio or any(_es_espanol(a) for a in audio):
        return  # sin datos, o hay espanol (Kodi ya elige esa pista: audio preferido)
    if pr.get('subtitleenabled') and _es_espanol(pr.get('currentsubtitle') or {}):
        return
    idiomas = ', '.join(sorted({(a.get('language') or a.get('name') or '?') for a in audio}))
    ops, acc = ['Poner subtítulos en español'], ['subs']
    imdb, tmdb = xbmc.getInfoLabel('VideoPlayer.IMDBNumber'), xbmc.getInfoLabel('VideoPlayer.UniqueID(tmdb)')
    if tiene(UMB) and (imdb or tmdb):
        ops.append('Elegir otra fuente (busca SPANISH, CASTELLANO, MULTI o DUAL)')
        acc.append('fuente')
    ops.append('Seguir así')
    acc.append('nada')
    i = xbmcgui.Dialog().select('No trae audio en español (%s)' % idiomas, ops, autoclose=20000)
    if i < 0 or acc[i] == 'nada':
        return
    if acc[i] == 'subs':
        subs = [s for s in pr.get('subtitles') or [] if _es_espanol(s)]
        if subs:
            rpc('Player.SetSubtitle', playerid=pid, subtitle=subs[0]['index'], enable=True)
            if xbmc.getCondVisibility('Player.SeekEnabled'):
                rpc('Player.Seek', playerid=pid, value={'seconds': -2})
            aviso('Subtítulos: español')
        else:
            descargar_subtitulos()
        return
    # otra fuente: Umbrella vuelve a buscar y ensena la lista para elegir
    from urllib.parse import urlencode
    q = {'title': xbmc.getInfoLabel('VideoPlayer.Title'), 'year': xbmc.getInfoLabel('VideoPlayer.Year'),
         'imdb': imdb, 'tmdb': tmdb, 'select': '0', 'rescrape': 'true'}
    serie = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
    if serie:
        q.update({'tvshowtitle': serie, 'season': xbmc.getInfoLabel('VideoPlayer.Season'),
                  'episode': xbmc.getInfoLabel('VideoPlayer.Episode'),
                  'tvdb': xbmc.getInfoLabel('VideoPlayer.UniqueID(tvdb)'),
                  'premiered': xbmc.getInfoLabel('VideoPlayer.Premiered')})
    xbmc.executebuiltin('PlayerControl(Stop)')
    xbmc.sleep(1500)
    xbmc.executebuiltin('PlayMedia(plugin://%s/?action=play_Item&%s)' % (UMB, urlencode(q)))


def subtitulos():
    """Boton de subtitulos del reproductor: pistas, quitar, descargar de Internet y ajustes.
    (El «Buscar subtitulos…» de Kodi abre un explorador de archivos: con un video de Internet
    se queda colgado intentando listar la carpeta del servidor.)"""
    jug = rpc('Player.GetActivePlayers')
    jug = [j for j in (jug if isinstance(jug, list) else []) if j.get('type') == 'video']
    if not jug:
        return
    pid = jug[0]['playerid']
    pr = rpc('Player.GetProperties', playerid=pid, properties=['subtitles', 'currentsubtitle', 'subtitleenabled'])
    pistas = pr.get('subtitles') or []
    actual = (pr.get('currentsubtitle') or {}).get('index') if pr.get('subtitleenabled') else None
    ops, acc = [], []
    for t in pistas:
        nombre = ' · '.join(x for x in (t.get('language') or '', t.get('name') or '') if x) or 'Pista %d' % (t['index'] + 1)
        ops.append(('[B]• %s[/B]' if t.get('index') == actual else '%s') % nombre)
        acc.append(('pista', t.get('index')))
    if pistas:
        ops.append('Sin subtítulos' + ('  ✓' if actual is None else ''))
        acc.append(('off', None))
    ops.append('Descargar de Internet…')
    acc.append(('internet', None))
    ops.append('Más ajustes (retraso, tamaño…)')
    acc.append(('ajustes', None))
    titulo = 'Subtítulos' if pistas else 'Subtítulos · este vídeo no trae ninguno'
    i = xbmcgui.Dialog().select(titulo, ops)
    if i < 0:
        return
    que, idx = acc[i]
    if que == 'pista':
        rpc('Player.SetSubtitle', playerid=pid, subtitle=idx, enable=True)
        aviso('Subtítulos: %s' % re.sub(r'\[/?B\]|^• ', '', ops[i]))
        # en un video de Internet Kodi solo los ensena al llegar el siguiente trozo de subtitulos
        # (tardaba unos segundos): 2 s atras y el reproductor los recarga ya
        if xbmc.getCondVisibility('Player.SeekEnabled') and not xbmc.getCondVisibility('VideoPlayer.Content(livetv)'):
            rpc('Player.Seek', playerid=pid, value={'seconds': -2})
    elif que == 'off':
        rpc('Player.SetSubtitle', playerid=pid, subtitle='off')
    elif que == 'internet':
        descargar_subtitulos()
    else:
        xbmc.executebuiltin('ActivateWindow(osdsubtitlesettings)')


# ---------------------------------------------------------------- paginas grandes dentro de Umbrella
PAGINA_INICIO = '20'   # filas de Inicio: rapidas (muestran 15)
PAGINA_DENTRO = '60'   # «Ver todo» y menus de Umbrella: el maximo que admite Umbrella


def _pagina(valor):
    """Elementos por pagina de Umbrella (un solo ajuste para todas sus listas)."""
    if not tiene(UMB):
        return
    try:
        a = xbmcaddon.Addon(UMB)
        if a.getSetting('page.item.limit') not in (valor, valor + '.0'):
            a.setSetting('page.item.limit', valor)
    except Exception as e:
        xbmc.log('[LEMD] pagina umbrella: %s' % e, xbmc.LOGWARNING)


def lista_canales(ruta):
    """«Ver todo» de «Vuelos destacados» y «Ultimas puertas»: una lista de LEMD en vez de la
    ventana Videos (alli Kodi trata cada canal como un video y tarda casi un minuto en rendirse).
    Al elegir, se pone el canal al momento."""
    import fuente
    from datetime import datetime
    elementos, acciones = [], []
    if 'accion=eventos' in ruta:
        titulo = nombre(EVENTOS, 'Vuelos destacados')
        ahora = time.time()
        for e in fuente.eventos_con_cache():
            directo = e['inicio'] <= ahora < e['fin']
            cuando = 'En directo' if directo else fuente.cuando(datetime.fromtimestamp(e['inicio']), datetime.now())
            li = xbmcgui.ListItem(e['titulo'], '%s · %s' % (cuando, e['nombre']))
            li.setArt({'icon': e['logo'], 'thumb': e['logo']})
            elementos.append(li)
            acciones.append((e['canal'], int(e['inicio']), e['titulo']))
    else:
        titulo = nombre(RECIENTES, 'Últimas puertas')
        for idc, nombre_c, icono, numero, _ in fuente.vistos():
            li = xbmcgui.ListItem(('%s  %s' % (numero, nombre_c)) if numero else nombre_c)
            li.setArt({'icon': icono or '', 'thumb': icono or ''})
            elementos.append(li)
            acciones.append((idc, 0, ''))
    if not elementos:
        xbmcgui.Dialog().notification('LEMD', 'No hay nada en «%s»' % titulo, xbmcgui.NOTIFICATION_INFO, 3000)
        return
    i = xbmcgui.Dialog().select(titulo, elementos, useDetails=True)
    if i >= 0:
        from urllib.parse import quote
        canal, inicio, tit = acciones[i]
        ver_canal(canal, inicio, quote(tit or '', safe=''))


def ruta_paginas(base, pagina=1):
    """Ruta de Umbrella para la pagina N de una lista de PAGINAS_UMB (con la marca lemdp=1)."""
    from datetime import date, timedelta
    from urllib.parse import quote
    accion, plantilla = PAGINAS_UMB[base]
    try:
        tmdb_corta = xbmcaddon.Addon(UMB).getSetting('tmdb.baseaddress') == 'true'
    except Exception:
        tmdb_corta = False
    idioma = (xbmc.getLanguage(xbmc.ISO_639_1) or 'en').lower()
    hoy = date.today()
    url = (plantilla.replace('{T}', 'https://api.trakt.tv')
           .replace('{M}', 'https://api.tmdb.org' if tmdb_corta else 'https://api.themoviedb.org')
           .replace('{L}', PAGINA_DENTRO).replace('{P}', str(pagina))
           .replace('{LANG}', 'en' if idioma == 'en' else idioma + ',en')
           .replace('{HOY}', hoy.strftime('%Y-%m-%d'))
           .replace('{D31}', (hoy - timedelta(days=31)).strftime('%Y-%m-%d')))
    return U + accion + '&url=' + quote(url, safe='') + '&lemdp=1'


def _siguiente_lemd():
    """Pagina siguiente de una lista abierta con ruta_paginas (o None): la misma ruta con
    page+1, si la pagina actual tiene contenido (con menos de 10 se da por acabada)."""
    ruta = xbmc.getInfoLabel('Container.FolderPath')
    if 'lemdp=1' not in ruta:
        return None
    m = re.search(r'page%3D(\d+)', ruta)
    try:
        n = int(xbmc.getInfoLabel('Container.NumItems') or 0)
    except ValueError:
        n = 0
    if not m or n < 10:
        return None
    return ruta[:m.start()] + 'page%%3D%d' % (int(m.group(1)) + 1) + ruta[m.end():]


def abrir_lista(ruta, todo=False):
    """Abre una lista en Videos con paginas grandes. El ajuste se cambia ANTES de abrir (si no,
    Umbrella daria la primera pagina con el tamano de Inicio). «Ver todo» lleva una marca en la
    ruta para que Kodi no reutilice la lista de la fila (15-20 elementos) que ya tiene guardada."""
    if ruta.startswith(('plugin://skin.lemd/?accion=eventos', 'plugin://skin.lemd/?accion=recientes')):
        lista_canales(ruta)
        return
    if 'plugin.video.umbrella' in ruta or 'skin.lemd/?accion=trakt' in ruta:
        _pagina(PAGINA_DENTRO)
        xbmc.executebuiltin('SetProperty(lemd.paginas,1,home)')
    if todo and ruta.startswith(LISTA):
        ruta += '&todo=1'  # todas, tambien las aun no estrenadas (al final)
    if todo:
        # recomendaciones de Trakt: Umbrella pide 40 fijas y Trakt no las da por paginas;
        # en «Ver todo» se le pasa la direccion de Trakt con el maximo (100)
        base = ruta.split('&lemd=')[0]
        if base in MAS_TRAKT:
            ruta = MAS_TRAKT[base]
        elif base in PAGINAS_UMB:
            ruta = ruta_paginas(base, 1)
    if todo and ruta.startswith('plugin://plugin.video.umbrella/'):
        # marca distinta cada vez: Kodi no reutiliza la lista de la fila ni abre en la pagina
        # donde se dejo la vez anterior (siempre empieza en la 1)
        ruta += '&lemd=%d' % (time.time() % 100000)
    xbmc.executebuiltin('ActivateWindow(Videos,%s,return)' % escapar(ruta))
    if todo:
        carteles()


def carteles(espera=20):
    """Peliculas y series en «Carteles» (vista 51), como «Ver todo» de peliculas: Kodi elegia la
    lista para las series. Espera a que la lista este cargada (como mucho «espera» s)."""
    mon, fin = xbmc.Monitor(), time.time() + espera
    while time.time() < fin and not mon.abortRequested():
        if mon.waitForAbort(0.4):
            return
        if not xbmc.getCondVisibility('Window.IsActive(videos)') or xbmc.getCondVisibility('Container.IsUpdating'):
            continue
        if xbmc.getInfoLabel('Container.NumItems') in ('', '0'):
            continue
        if xbmc.getCondVisibility('Container.Content(tvshows) | Container.Content(movies)') \
                and not xbmc.getCondVisibility('Control.IsVisible(51)'):
            xbmc.executebuiltin('Container.SetViewMode(51)')
        return


def paginas_inicio():
    """Al volver a Inicio: paginas pequenas otra vez (las filas cargan antes)."""
    if xbmc.getInfoLabel('Window(Home).Property(lemd.paginas)') or not xbmc.getCondVisibility('Skin.HasSetting(lemd.pag1)'):
        xbmc.executebuiltin('ClearProperty(lemd.paginas,home)')
        xbmc.executebuiltin('Skin.SetBool(lemd.pag1)')
        _pagina(PAGINA_INICIO)


def bufer_video():
    """Mas bufer para el video de Internet (TV, Umbrella): con la tele en pequeno y la CPU
    ocupada cargando listas, el audio daba pequenos cortes. Solo si sigue en el valor de serie."""
    mem = memoria_mb()
    mb = 64 if not mem or mem >= 1700 else 32
    actual = rpc('Settings.GetSettingValue', setting='filecache.memorysize').get('value')
    if actual is None:
        return None  # Kodi 20: no tiene este ajuste
    if actual == 20:
        rpc('Settings.SetSettingValue', setting='filecache.memorysize', value=mb)
        return 'Búfer de vídeo: %d MB (estaba en 20 MB)' % mb
    return None


def diag_umbrella():
    """Diagnostico de paginas en Umbrella: version, ajustes, cuantas peliculas tiene guardadas de
    la lista de Trakt y que devuelve al pedirle la primera pagina de «Ver todo»."""
    import sqlite3
    from contextlib import closing
    if not tiene(UMB):
        xbmcgui.Dialog().ok('Diagnóstico de Umbrella', 'Umbrella no está instalado.')
        return
    a = xbmcaddon.Addon(UMB)
    t = ['[B]Umbrella[/B] %s' % a.getAddonInfo('version')]
    for k, n in (('page.item.limit', 'Elementos por página'), ('services.paginate.lists', 'Paginar listas de Trakt'),
                 ('tmdb.paginate.lists', 'Paginar listas de TMDb'), ('hidecinema', 'Ocultar no estrenadas'),
                 ('sort.movies.watchlist.type', 'Orden de la lista (0 = el de Trakt)')):
        t.append('%s: %s' % (n, a.getSetting(k) or '—'))
    db = os.path.join(xbmcvfs.translatePath('special://profile/addon_data/%s/' % UMB), 'traktSync.db')
    t.append('')
    try:
        with closing(sqlite3.connect('file:%s?mode=ro' % db, uri=True, timeout=5)) as c:
            for tabla, n in (('movies_watchlist', 'Películas en tu lista de Trakt'), ('shows_watchlist', 'Series en tu lista'),
                             ('movies_collection', 'Películas en tu colección'), ('bookmarks', 'A medias (pelis y series)')):
                try:
                    t.append('%s: %d' % (n, c.execute('SELECT COUNT(*) FROM %s' % tabla).fetchone()[0]))
                except Exception:
                    t.append('%s: (no hay tabla)' % n)
    except Exception as e:
        t.append('No se pudo leer la copia de Trakt: %s' % e)
    # lo que devuelve Umbrella para la pagina 1 de «Ver todo» (con 60 por pagina, como alli)
    aviso = xbmcgui.DialogProgressBG()
    aviso.create('LEMD', 'Pidiendo a Umbrella la página 1…')
    _pagina(PAGINA_DENTRO)
    r = rpc('Files.GetDirectory', directory=U + 'movies&url=traktwatchlist&lemd=diag%d' % (time.time() % 100000),
            media='video', properties=['title'])
    _pagina(PAGINA_INICIO)
    aviso.close()
    fich = r.get('files') or []
    sig = [f for f in fich if 'next page' in re.sub(r'\[/?[A-Z]+[^\]]*\]', '', f.get('label') or '').lower()]
    t += ['', '[B]Página 1 de «Mi tarjeta de embarque: películas»[/B]: %d elementos' % len(fich),
          'Página siguiente: %s' % ('sí: ' + re.sub(r'\[/?[A-Z]+[^\]]*\]', '', sig[-1].get('label', ''))
                                    if sig else '[COLOR red]no[/COLOR]')]
    if fich:
        t.append('Último: %s' % re.sub(r'\[/?[A-Z]+[^\]]*\]', '', fich[-1].get('label') or ''))
    xbmcgui.Dialog().textviewer('Diagnóstico de Umbrella (manda una foto)', '[CR]'.join(t))


def probar_sonidos():
    hecho = poner_sonidos()
    sonando = xbmc.getCondVisibility('Player.HasMedia')
    piel = rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value') or ''
    try:
        nombre = xbmcaddon.Addon(piel).getAddonInfo('name') if piel else 'ninguno'
    except Exception:
        nombre = piel
    det = rpc('Addons.GetAddonDetails', addonid=SONIDOS, properties=['enabled', 'version']).get('addon') or {}
    if not det:
        estado = '[COLOR red]no instalado[/COLOR] (¿sin Internet? Vuelve a probar en un rato)'
    elif not det.get('enabled'):
        estado = '[COLOR red]desactivado[/COLOR]: Add-ons › Mis add-ons › Sonidos de la interfaz › LEMD › Activar'
    else:
        estado = 'instalado y activado (versión %s)' % det.get('version', '?')
    texto = ['[B]Sonidos de la interfaz:[/B] %s' % nombre, '[B]Paquete de cabina:[/B] %s' % estado]
    texto += ['', 'Cambiado ahora:'] + ['· ' + h for h in hecho] if hecho else ['', 'Todo estaba bien puesto.']
    if sonando:
        texto += ['', 'Ahora se está reproduciendo algo: Kodi no hace sonar la interfaz mientras tanto. '
                  'Para el vídeo o el canal y vuelve a probar.']
    texto += ['', 'Al cerrar esta ventana suena el «pim-pum». Si no lo oyes, sube el volumen del Fire TV o de '
              'la tele (algunas barras de sonido tardan en despertar y se comen los sonidos cortos).']
    xbmcgui.Dialog().textviewer('Probar los sonidos', '[CR]'.join(texto))
    xbmc.sleep(400)
    ruta = os.path.join(xbmcaddon.Addon('skin.lemd').getAddonInfo('path'), 'sounds', 'cinturon.wav')
    xbmc.playSFX(ruta, False)
    xbmc.sleep(2700)


def umbrella_espanol():
    """Umbrella solo trae ingles: LEMD pone en su carpeta la traduccion al espanol de sus menus
    (Herramientas, cache, ajustes...). Solo si Kodi esta en espanol, sin pisar una traduccion que no
    sea de LEMD; si una actualizacion de Umbrella la borra, se vuelve a poner (vale al reiniciar Kodi)."""
    if not tiene(UMB):
        return False
    idioma = rpc('Settings.GetSettingValue', setting='locale.language').get('value') or ''
    if not idioma.startswith('resource.language.es'):
        return False
    origen = os.path.join(xbmcaddon.Addon('skin.lemd').getAddonInfo('path'), 'resources', 'umbrella', 'strings.po')
    carpeta = os.path.join(xbmcaddon.Addon(UMB).getAddonInfo('path'), 'resources', 'language', idioma)
    destino = os.path.join(carpeta, 'strings.po')
    try:
        with open(origen, encoding='utf-8') as f:
            nuevo = f.read()
        if os.path.exists(destino):
            with open(destino, encoding='utf-8') as f:
                actual = f.read()
            if actual == nuevo or 'LEMD' not in actual.split('\n', 1)[0]:
                return False  # ya esta, o es una traduccion de Umbrella: no se toca
        os.makedirs(carpeta, exist_ok=True)
        with open(destino, 'w', encoding='utf-8') as f:
            f.write(nuevo)
        return True
    except (OSError, IOError) as e:
        xbmc.log('[LEMD] umbrella es: %s' % e, xbmc.LOGWARNING)
        return False


def juntar_series():
    """1.9.26: «Continuar viendo: series» y «Proximos episodios» repetian casi todo: si estan
    las dos, la primera pasa a ser la de LEMD que junta ambas y la otra se quita."""
    filas = [n for n in range(1, FILAS + 1) if skin_get(n, 'path') in SERIES_UMB]
    if len(filas) < 2 or any(skin_get(n, 'path') == SERIES for n in range(1, FILAS + 1)):
        return False
    fila(filas[0], SERIES, nombre(SERIES, 'Continuar viendo: series'), 'wide')
    for n in filas[1:]:
        fila(n)
    return True


def quitar_spotting():
    """1.9.23: fuera la fila de spotting de YouTube (la fila queda libre)."""
    quitadas = 0
    for n in range(1, FILAS + 1):
        if skin_get(n, 'path') == SPOTTING:
            fila(n)
            quitadas += 1
    return quitadas


NO_ESTRENADAS = {U + 'tmdbmovies&url=tmdb_nowplaying': (U + 'tmdbmovies&url=tmdb_toprated', 'Mejor valoradas'),
                 U + 'movies&url=traktanticipated': (U + 'movies&url=traktpopular', 'Películas populares (Trakt)'),
                 U + 'tmdbmovies&url=tmdb_upcoming': (U + 'movies&url=traktpopular', 'Películas populares (Trakt)')}


def solo_estrenadas():
    """Que no salgan peliculas que Umbrella luego no encuentra: las aun no estrenadas.
    Umbrella las oculta con su ajuste «hidecinema»; y las filas «En cines ahora», «Las mas
    esperadas» y «Proximos estrenos» (casi todo sin estreno digital) se cambian por otras."""
    hecho = []
    if tiene(UMB):
        try:
            a = xbmcaddon.Addon(UMB)
            if a.getSetting('hidecinema') != 'true':
                a.setSetting('hidecinema', 'true')
                hecho.append('Umbrella: ocultar películas aún no estrenadas')
        except Exception as e:
            xbmc.log('[LEMD] hidecinema: %s' % e, xbmc.LOGWARNING)
    usadas = {skin_get(n, 'path') for n in range(1, FILAS + 1)}
    for n in range(1, FILAS + 1):
        ruta = skin_get(n, 'path')
        if ruta in NO_ESTRENADAS:
            otras = [NO_ESTRENADAS[ruta], (U + 'tmdbmovies&url=tmdb_toprated', 'Mejor valoradas'),
                     (U + 'movies&url=traktpopular', 'Películas populares (Trakt)'),
                     (U + 'tmdbmovies&url=tmdb_popular', 'Películas populares'),
                     (U + 'movies&url=oscars', 'Premios Óscar')]
            libre = next(((r, l) for r, l in otras if r not in usadas), None)
            if not libre:
                fila(n)
                hecho.append('Fila %d: quitada (eran películas aún sin estrenar)' % n)
                continue
            nueva, label = libre
            usadas.add(nueva)
            fila(n, nueva, nombre(nueva, label), 'poster')
            hecho.append('Fila %d: «%s» en lugar de películas aún sin estrenar' % (n, nombre(nueva, label)))
    return hecho


def poner_retomar():
    """«Retomar vuelo: peliculas» con la fuente de LEMD: cambia la de Umbrella (que sale vacia
    entera si una pelicula viene sin duracion) y, si no estaba y hay Trakt, la anade tras las
    filas de TV."""
    rutas = [skin_get(n, 'path') for n in range(1, FILAS + 1)]
    if RETOMAR in rutas:
        return
    if RETOMAR_UMB in rutas:
        n = rutas.index(RETOMAR_UMB) + 1
        fila(n, RETOMAR, nombre(RETOMAR, 'Continuar viendo: películas'), 'wide')
        return
    if not trakt_en_umbrella():
        return
    pos = next((i for i, r in enumerate(rutas, 1) if r not in (EVENTOS, RECIENTES, LASTPLAYED, 'pvr://channels/tv/*')), 1)
    hueco = next((i for i in range(pos, FILAS + 1) if not rutas[i - 1]), FILAS)
    for i in range(hueco, pos, -1):  # se corren una hacia abajo (se pierde la ultima si no hay hueco)
        for campo in CAMPOS:
            skin_set(i, campo, skin_get(i - 1, campo))
    fila(pos, RETOMAR, nombre(RETOMAR, 'Continuar viendo: películas'), 'wide')


TRAKT_FILAS = [('Continuar viendo: películas', RETOMAR, 'wide'),
               ('Continuar viendo: series', SERIES, 'wide'),
               ('Mi lista: películas', LISTA + 'movies_watchlist', 'poster'),
               ('Mi lista: series', LISTA + 'shows_watchlist', 'poster'),
               ('Recomendadas para ti', U + 'movies&url=traktrecommendations', 'poster'),
               ('Mi colección: películas', LISTA + 'movies_collection', 'poster')]


def filas_trakt():
    """Si se vincula Trakt en Umbrella despues de instalar LEMD, las filas de Inicio se eligieron
    sin Trakt (sin «Mi lista», «Continuar viendo»...). La primera vez que LEMD ve Trakt vinculado y
    no hay ninguna fila de Trakt, las pone detras de las de TV (las demas se corren hacia abajo).
    Una sola vez: si luego se quitan, no vuelven."""
    if xbmc.getCondVisibility('Skin.HasSetting(lemd.trakt1)') or not trakt_en_umbrella():
        return False
    xbmc.executebuiltin('Skin.SetBool(lemd.trakt1)')
    de_trakt = {r for _, r, _ in TRAKT_FILAS} | set(SERIES_UMB) | set(LISTAS_UMB) | {
        RETOMAR_UMB, U + 'tvshows&url=traktrecommendations', LISTA + 'shows_collection'}
    rutas = [skin_get(n, 'path') for n in range(1, FILAS + 1)]
    if any(r in de_trakt for r in rutas):
        return False  # ya tiene filas de Trakt
    pos = next((i for i, r in enumerate(rutas, 1) if r not in (EVENTOS, RECIENTES, LASTPLAYED, 'pvr://channels/tv/*')), 1)
    for label, ruta, estilo in TRAKT_FILAS:
        rutas = [skin_get(n, 'path') for n in range(1, FILAS + 1)]
        hueco = next((i for i in range(pos, FILAS + 1) if not rutas[i - 1]), FILAS)
        for i in range(hueco, pos, -1):  # se corren una hacia abajo (sin hueco, se pierde la ultima)
            for campo in CAMPOS:
                skin_set(i, campo, skin_get(i - 1, campo))
        fila(pos, ruta, nombre(ruta, label), estilo)
        pos += 1
        if pos > FILAS:
            break
    return True


def recuperar_filas():
    """1.9.7: Inicio pasa de 16 a 20 filas. Con 16 llenas, la fila de spotting ocupo la de
    documentales (1.9.2) y «Retomar vuelo» empujo la ultima fuera (1.9.4): vuelven los documentales."""
    rutas = [skin_get(n, 'path') for n in range(1, FILAS + 1)]

    def hueco():
        return next((i for i, r in enumerate(rutas, 1) if not r), None)
    hecho = []
    if tiene(UMB) and DOC_PELIS not in rutas:
        n = hueco()
        if n:
            fila(n, DOC_PELIS, nombre(DOC_PELIS, 'Documentales'), 'poster')
            rutas[n - 1] = DOC_PELIS
            hecho.append('Documentales')
    return hecho


def listas_lemd():
    """1.9.21: las filas de listas de Trakt pasan a la fuente de LEMD (todas, sin paginas)."""
    for n in range(1, FILAS + 1):
        ruta = skin_get(n, 'path')
        if ruta in LISTAS_UMB:
            nueva = LISTAS_UMB[ruta]
            label = skin_get(n, 'label')
            par = NOMBRES.get(ruta)
            skin_set(n, 'path', nueva)
            if not label or (par and label in par):
                skin_set(n, 'label', nombre(nueva, label))


def actualizar():
    """Cambios de una sola vez al estrenar una version (Inicio lo lanza si falta alguna marca)."""
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.zapping2)'):
        zapping()
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.opt1)'):
        optimizar(auto=True)
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.umb20)'):
        # la 1.7.4 subio Umbrella a 40 por pagina: las filas de Inicio tardaban mas. Vuelve a 20
        # (las filas muestran 15 y «Ver todo» pasa de pagina)
        try:
            if tiene(UMB) and xbmcaddon.Addon(UMB).getSetting('page.item.limit') in ('40', '40.0'):
                xbmcaddon.Addon(UMB).setSetting('page.item.limit', '20')
        except Exception as e:
            xbmc.log('[LEMD] umbrella 20: %s' % e, xbmc.LOGWARNING)
        xbmc.executebuiltin('Skin.SetBool(lemd.umb20)')
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.listas1)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.listas1)')
        listas_lemd()
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.opt3)'):
        optimizar_mas(auto=True)  # opt3: 1.9.12 anade servidor de eventos y Zeroconf
        xbmc.executebuiltin('Skin.SetBool(lemd.opt3)')
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.filas20)'):
        if not xbmc.getCondVisibility('Player.HasMedia'):  # puede preguntar: no con algo puesto
            xbmc.executebuiltin('Skin.SetBool(lemd.filas20)')
            h = recuperar_filas()
            if h:
                xbmcgui.Dialog().notification('LEMD', 'Filas recuperadas: ' + ', '.join(h), xbmcgui.NOTIFICATION_INFO, 6000)
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.buf1)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.buf1)')
        bufer_video()
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.retomar1)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.retomar1)')
        poner_retomar()
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.cine1)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.cine1)')
        if solo_estrenadas():
            xbmcgui.Dialog().notification('LEMD', 'Fuera películas aún sin estrenar', xbmcgui.NOTIFICATION_INFO, 5000)
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.idioma1)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.idioma1)')
        if (rpc('Settings.GetSettingValue', setting='locale.language').get('value') or '').startswith('resource.language.es'):
            audio_espanol()
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.series1)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.series1)')
        if juntar_series():
            xbmcgui.Dialog().notification('LEMD', 'Series: una sola fila (a medias y siguiente episodio)',
                                          xbmcgui.NOTIFICATION_INFO, 5000)
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.color1)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.color1)')
        colores_umbrella()
        ajustar_a4k()
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.nospot1)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.nospot1)')
        quitar_spotting()
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.sonidos3)'):
        # sonidos de cabina (tono flojito al moverse, «ding» al elegir, «pim-pum»...): una vez
        xbmc.executebuiltin('Skin.SetBool(lemd.sonidos3)')
        if poner_sonidos():
            xbmcgui.Dialog().notification('LEMD', 'Sonidos de cabina activados', xbmcgui.NOTIFICATION_INFO, 4000)
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.mem1)'):
        mem = memoria_mb()
        if mem and mem < 1700:
            xbmc.executebuiltin('Skin.SetBool(lemd.pocamem)')  # filas de Inicio solo al bajar
        xbmc.executebuiltin('Skin.SetBool(lemd.mem1)')
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.doblem2)'):
        # la guia de dobleM pasa a ser la principal (una vez; se puede volver a la del proveedor).
        # Si hay algo reproduciendose, se deja para la proxima vez (antes se daba por hecho: fallo)
        import reparar
        if not tiene('pvr.iptvsimple') or xbmc.getInfoLabel('Skin.String(lemd.guia)') == 'proveedor' \
                or reparar.usa_dobleM():
            xbmc.executebuiltin('Skin.SetBool(lemd.doblem2)')
        elif not xbmc.getCondVisibility('Player.HasMedia'):
            intentos = int(xbmc.getInfoLabel('Skin.String(lemd.doblem.intentos)') or 0) + 1
            xbmc.executebuiltin('Skin.SetString(lemd.doblem.intentos,%d)' % intentos)
            if reparar.poner_dobleM(silencioso=True) or intentos >= 3:
                xbmc.executebuiltin('Skin.SetBool(lemd.doblem2)')
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.recientes1)'):
        # «Últimas puertas»: la fila de Kodi no deja quitar canales; la de LEMD si
        for n in range(1, FILAS + 1):
            if skin_get(n, 'path') == LASTPLAYED:
                skin_set(n, 'path', RECIENTES)
        xbmc.executebuiltin('Skin.SetBool(lemd.recientes1)')


def renombrar(n):
    t = xbmcgui.Dialog().input('Nombre de la fila %d' % n, skin_get(n, 'label'))
    if t:
        skin_set(n, 'label', t)


def estilo(n):
    skin_set(n, 'style', '' if skin_get(n, 'style') == 'wide' else 'wide')


def mover(n, d):
    m = n + d
    if not 1 <= m <= FILAS:
        return
    a = {c: skin_get(n, c) for c in CAMPOS}
    b = {c: skin_get(m, c) for c in CAMPOS}
    for c in CAMPOS:
        skin_set(n, c, b[c])
        skin_set(m, c, a[c])


def menu_fila(n):
    nombre = skin_get(n, 'label') or 'vacía'
    vacia = not skin_get(n, 'path')
    ops = [('Cambiar contenido…', elegir)]
    if not vacia:
        es_wide = skin_get(n, 'style') == 'wide'
        ops += [('Renombrar…', renombrar),
                ('Estilo: %s (cambiar a %s)' % (('Panorámica', 'Carteles') if es_wide else ('Carteles', 'Panorámica')), estilo)]
        if n > 1:
            ops.append(('Subir', lambda k: mover(k, -1)))
        if n < FILAS:
            ops.append(('Bajar', lambda k: mover(k, 1)))
        ops.append(('Quitar fila', lambda k: fila(k)))
    i = xbmcgui.Dialog().select('Fila %d · %s' % (n, nombre), [o[0] for o in ops])
    if i >= 0:
        ops[i][1](n)


def main():
    args = sys.argv[1:]
    if not args:
        return
    accion = args[0]
    n = int(args[1]) if len(args) > 1 and args[1].isdigit() else 0
    if accion == 'defaults':
        defaults()
    elif accion == 'resetall':
        if xbmcgui.Dialog().yesno('LEMD', '¿Volver a las filas de Inicio por defecto?'):
            defaults()
    elif accion == 'detect':
        detect()
    elif accion == 'widget' and n:
        elegir(n)
    elif accion == 'label' and n:
        renombrar(n)
    elif accion == 'style' and n:
        estilo(n)
    elif accion == 'up' and n:
        mover(n, -1)
    elif accion == 'down' and n:
        mover(n, 1)
    elif accion == 'clear' and n:
        fila(n)
    elif accion == 'row' and n:
        menu_fila(n)
    elif accion == 'jerga':
        renombrar_jerga()
    elif accion == 'claves':
        claves()
    elif accion == 'ciudad':
        ciudad()
    elif accion == 'tiempodefecto':
        tiempo_defecto()
    elif accion == 'usartiempo':
        tiempo_defecto(True)
        aviso('Tiempo: LEMD · Open-Meteo')
    elif accion == 'tono':
        tono()
    elif accion == 'arranque':  # una vez por sesion, al abrir Inicio
        borrar_subtitulos()
        umbrella_espanol()
        if tiene('pvr.iptvsimple'):
            try:
                import reparar
                ligera = reparar.mantener_lista()
                if ligera:
                    xbmcgui.Dialog().notification('LEMD', 'TV: lista ligera con tus grupos (%d canales): carga más rápido'
                                                  % ligera['canales'], xbmcgui.NOTIFICATION_INFO, 6000)
            except Exception as e:
                xbmc.log('[LEMD] lista ligera: %s' % e, xbmc.LOGWARNING)
        if filas_trakt():
            xbmcgui.Dialog().notification('LEMD', 'Trakt vinculado: añadidas tus listas y «Continuar viendo»',
                                          xbmcgui.NOTIFICATION_INFO, 6000)
        if not xbmc.getCondVisibility('Skin.HasSetting(lemd.noupdcheck)'):
            import actualizar_skin
            actualizar_skin.comprobar()
            actualizar_skin.actualizar_sonidos()
        limpieza_mensual()
    elif accion == 'espanol':
        audio_espanol(manual=True)
    elif accion == 'idioma':
        comprobar_idioma()
    elif accion == 'buscarupd':
        import actualizar_skin
        actualizar_skin.actualizar_sonidos()
        actualizar_skin.comprobar(manual=True)
    elif accion == 'canal':
        import vigia
        marcar = args[1:]
        vigia.ver_canal(marcar[0] if marcar else '', marcar[1] if len(marcar) > 1 else '')
    elif accion == 'reparar':
        import reparar
        reparar.reparar(auto=len(args) > 1 and args[1] == 'auto')
    elif accion == 'restaurar':
        import reparar
        reparar.restaurar()
    elif accion == 'metar':
        metar()
    elif accion == 'subtitulos':
        subtitulos()
    elif accion == 'vertodo':
        abrir_lista(args[1] if len(args) > 1 else '', todo=True)
    elif accion == 'abrir':
        abrir_lista(args[1] if len(args) > 1 else '')
    elif accion == 'paginas':
        paginas_inicio()
    elif accion == 'vercanal':
        ver_canal(int(args[1]) if len(args) > 1 and args[1].isdigit() else 0,
                  int(args[2]) if len(args) > 2 and args[2].isdigit() else 0,
                  args[3] if len(args) > 3 else '')
    elif accion == 'siguiente':
        siguiente()
    elif accion == 'sonidos':
        probar_sonidos()
    elif accion == 'chime':
        # «pim-pum» de la senal de cinturones (sintetizado: herramientas/generar_cinturon.py)
        ruta = os.path.join(xbmcaddon.Addon('skin.lemd').getAddonInfo('path'), 'sounds', 'cinturon.wav')
        if os.path.exists(ruta):
            xbmc.playSFX(ruta, False)
            xbmc.sleep(2700)  # que termine antes de cerrar el script
    elif accion == 'interfaz':
        interfaz()
    elif accion == 'optimizar':
        optimizar()
    elif accion == 'diagumbrella':
        diag_umbrella()
    elif accion == 'servicios':
        servicios()
    elif accion == 'optimizarmas':
        optimizar_mas()
    elif accion == 'deshaceropt':
        deshacer_optimizar_mas()
    elif accion == 'limpieza':
        limpieza_mensual()
    elif accion == 'apagado':
        apagado()
    elif accion == 'apagar':
        apagar()
    elif accion == 'actualizar':
        actualizar()
    elif accion == 'fuenteguia':
        import reparar
        reparar.fuente_guia()
    elif accion == 'grupos':
        import reparar
        reparar.elegir_grupos()
    elif accion == 'zapping':
        zapping(elegir=len(args) > 1 and args[1] == 'elegir')


if __name__ == '__main__':
    main()
