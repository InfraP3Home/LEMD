# -*- coding: utf-8 -*-
"""Ayudante de la skin LEMD.

Se ejecuta SOLO cuando el usuario lo pide (RunScript desde la skin). No hay
servicio en segundo plano ni bucles: hace su trabajo y termina.

Acciones (RunScript(special://skin/scripts/lemd.py,<accion>[,N])):
  defaults      Rellena las filas de Inicio por defecto (TV en directo y Umbrella).
  detect        Muestra que hay instalado (Umbrella, Trakt, TV, tiempo).
  widget,N      Elegir el contenido de la fila N (preajustes o explorar Umbrella).
  label,N       Renombrar la fila N.
  style,N       Alternar cartel / panoramica en la fila N.
  up,N / down,N Mover la fila N.
  clear,N       Vaciar la fila N.
  row,N         Menu de la fila N (todo lo anterior).
  jerga         Pone o quita los nombres de aeropuerto en las filas automaticas.
  claves        Palabras clave de «Vuelos destacados» (eventos de la guía).
  ciudad        Ciudad del tiempo (proveedor LEMD, Open-Meteo).
  tiempodefecto Pone LEMD como proveedor del tiempo si no hay ninguno.
  tono          Tono del fondo: grafito, negro o gris claro.
  vpn           Mira si la VPN está encendida (Window(Home).Property(lemd.vpn)).
  canal,RUTA,NOMBRE  Pone un canal y avisa si no arranca (VPN / reiniciar el Fire TV).
  reparar[,auto] Repara guía y logos de IPTV Simple (tvg-id por nombre); restaurar lo deshace.
  metar         Descarga y traduce el METAR/TAF (LEMD por defecto) y estima las pistas en uso.
  resetall      Volver a las filas por defecto.
"""
import json
import os
import re
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

FILAS = 16
UMB = 'plugin.video.umbrella'
U = 'plugin://plugin.video.umbrella/?action='
CAMPOS = ('path', 'label', 'style')


# ---------------------------------------------------------------- utilidades
def rpc(method, **params):
    q = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    r = json.loads(xbmc.executeJSONRPC(json.dumps(q)))
    return r.get('result') or {}


def skin_get(n, campo):
    return xbmc.getInfoLabel('Skin.String(lemd.w%d.%s)' % (n, campo))


def skin_set(n, campo, valor):
    clave = 'lemd.w%d.%s' % (n, campo)
    if valor:
        xbmc.executebuiltin('Skin.SetString(%s,%s)' % (clave, escapar(valor)))
    else:
        xbmc.executebuiltin('Skin.Reset(%s)' % clave)


def escapar(valor):
    # Kodi separa los parametros de los builtins por comas: hay que entrecomillar
    return '"%s"' % valor.replace('\\', '\\\\').replace('"', '\\"')


def fila(n, path='', label='', style=''):
    skin_set(n, 'path', path)
    skin_set(n, 'label', label)
    skin_set(n, 'style', 'wide' if style == 'wide' else '')


def tiene(addon_id):
    return xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % addon_id)


def trakt_en_umbrella():
    if not tiene(UMB):
        return False
    try:
        a = xbmcaddon.Addon(UMB)
        return a.getSetting('trakt.isauthed') == 'true' or bool(a.getSetting('trakt.user.token'))
    except Exception:
        return False


def aviso(msg):
    xbmcgui.Dialog().notification('LEMD', msg, xbmcgui.NOTIFICATION_INFO, 3000)


# ---------------------------------------------------------------- tema Barajas: nombres
YT = 'plugin.video.youtube'
SPOTTING = 'plugin://plugin.video.youtube/kodion/search/query/?q=Madrid%20Barajas%20planespotting%20live'
EVENTOS = 'plugin://skin.lemd/?accion=eventos'
RECIENTES = 'plugin://skin.lemd/?accion=recientes'  # como lastplayed de Kodi, pero se pueden quitar canales
LASTPLAYED = 'pvr://channels/tv/*?view=lastplayed'
# documentales: populares de Trakt por genero (no hace falta vincular Trakt)
DOC_PELIS = U + 'trakt_genre&listtype=popular&mediatype=Movies&genre=Documentary&url=documentary'
DOC_SERIES = U + 'trakt_genre&listtype=popular&mediatype=TVShows&genre=Documentary&url=documentary'
# ruta -> (nombre normal, nombre con jerga de aeropuerto)
NOMBRES = {
    LASTPLAYED: ('Vistos recientemente', 'Últimas puertas'),
    RECIENTES: ('Vistos recientemente', 'Últimas puertas'),
    'pvr://channels/tv/*': ('Canales', 'En pista'),
    'pvr://recordings/tv/active?view=flat': ('Grabaciones recientes', 'Caja negra'),
    U + 'episodesUnfinished&url=traktunfinished': ('Continuar viendo: series', 'Retomar vuelo: series'),
    U + 'moviesUnfinished&url=traktunfinished': ('Continuar viendo: películas', 'Retomar vuelo: películas'),
    U + 'calendar&url=progress': ('Próximos episodios', 'Próximas salidas'),
    U + 'movies&url=trakttrending': ('Películas en tendencia', 'Películas despegando'),
    U + 'tvshows&url=trakttrending': ('Series en tendencia', 'Series despegando'),
    U + 'tmdbmovies&url=tmdb_popular': ('Películas populares', 'Primera clase: películas'),
    U + 'tmdbTvshows&url=tmdb_popular': ('Series populares', 'Primera clase: series'),
    U + 'movies&url=traktwatchlist': ('Mi lista: películas', 'Mi tarjeta de embarque: películas'),
    U + 'tvshows&url=traktwatchlist': ('Mi lista: series', 'Mi tarjeta de embarque: series'),
    U + 'tmdbmovies&url=tmdb_nowplaying': ('En cines ahora', 'Recién aterrizadas'),
    SPOTTING: ('Spotting en Barajas (directo)', 'Spotting en Barajas (directo)'),
    EVENTOS: ('Eventos destacados en TV', 'Vuelos destacados'),
    DOC_PELIS: ('Documentales', 'Vuelo de reconocimiento'),
    DOC_SERIES: ('Series documentales', 'Vuelo de reconocimiento: series'),
    # Trakt (cuenta)
    U + 'movies&url=traktcollection': ('Mi colección: películas', 'Mi hangar: películas'),
    U + 'tvshows&url=traktcollection': ('Mi colección: series', 'Mi hangar: series'),
    U + 'movies&url=trakthistory': ('Películas vistas', 'Cuaderno de bitácora'),
    U + 'calendar&url=trakthistory': ('Episodios vistos', 'Bitácora de episodios'),
    U + 'movies&url=traktrecommendations': ('Recomendadas para ti', 'La torre recomienda'),
    U + 'tvshows&url=traktrecommendations': ('Series recomendadas', 'La torre recomienda: series'),
    U + 'movies&url=traktbasedonrecent': ('Porque viste...', 'Rutas parecidas'),
    U + 'tvshows&url=traktbasedonrecent': ('Series porque viste...', 'Rutas parecidas: series'),
    # Descubrir
    U + 'movies&url=traktanticipated': ('Las más esperadas', 'Próximas llegadas'),
    U + 'movies&url=traktboxoffice': ('Taquilla', 'Récord de pasajeros'),
    U + 'tmdbmovies&url=tmdb_toprated': ('Mejor valoradas', 'Clase business'),
    U + 'tmdbTvshows&url=tmdb_toprated': ('Series mejor valoradas', 'Clase business: series'),
    U + 'tmdbmovies&url=tmdb_upcoming': ('Próximos estrenos', 'En aproximación final'),
    U + 'tmdbTvshows&url=tmdb_airingtoday': ('Se emiten hoy', 'En vuelo hoy'),
    U + 'tmdbTvshows&url=tmdb_ontheair': ('Series en emisión', 'En ruta'),
    U + 'tvshows&url=tmdb_newshows': ('Series nuevas', 'Vuelo inaugural'),
    U + 'movies&url=oscars': ('Premios Óscar', 'Pasajeros de honor'),
    U + 'tmdbmovies&url=tmdb_boxoffice': ('Taquilla (TMDb)', 'Récord de pasajeros (TMDb)'),
    U + 'movies&url=traktpopular': ('Películas populares (Trakt)', 'Puente aéreo: películas'),
    U + 'tvshows&url=traktpopular': ('Series populares (Trakt)', 'Puente aéreo: series'),
}


def jerga_activa():
    return not xbmc.getCondVisibility('Skin.HasSetting(lemd.nojerga)')


def nombre(path, por_defecto):
    n = NOMBRES.get(path)
    if not n:
        return por_defecto
    return n[1] if jerga_activa() else n[0]


def renombrar_jerga():
    """Aplica (o quita) la jerga a las filas que conservan su nombre automatico."""
    for n in range(1, FILAS + 1):
        path, label = skin_get(n, 'path'), skin_get(n, 'label')
        par = NOMBRES.get(path)
        if par and label in par:
            skin_set(n, 'label', par[1] if jerga_activa() else par[0])


# ---------------------------------------------------------------- preajustes
def preajustes():
    """Lista de (grupo, etiqueta, ruta, estilo). Solo Umbrella y TV en directo."""
    p = []
    pvr = xbmc.getCondVisibility('System.HasPVRAddon')
    if pvr:
        p.append(('TV', 'Eventos destacados (fútbol, F1...) de la guía', EVENTOS, 'wide'))
    if tiene(UMB):
        g = 'Trakt' if trakt_en_umbrella() else 'Trakt (sin vincular en Umbrella)'
        p += [
            (g, 'Continuar viendo: películas', U + 'moviesUnfinished&url=traktunfinished', 'wide'),
            (g, 'Continuar viendo: series', U + 'episodesUnfinished&url=traktunfinished', 'wide'),
            (g, 'Próximos episodios', U + 'calendar&url=progress', 'wide'),
            (g, 'Mi lista: películas', U + 'movies&url=traktwatchlist', 'poster'),
            (g, 'Mi lista: series', U + 'tvshows&url=traktwatchlist', 'poster'),
            (g, 'Mi colección: películas', U + 'movies&url=traktcollection', 'poster'),
            (g, 'Mi colección: series', U + 'tvshows&url=traktcollection', 'poster'),
            (g, 'Recomendadas para mí: películas', U + 'movies&url=traktrecommendations', 'poster'),
            (g, 'Recomendadas para mí: series', U + 'tvshows&url=traktrecommendations', 'poster'),
            (g, 'Parecidas a lo último que vi: películas', U + 'movies&url=traktbasedonrecent', 'poster'),
            (g, 'Parecidas a lo último que vi: series', U + 'tvshows&url=traktbasedonrecent', 'poster'),
            (g, 'Películas que he visto', U + 'movies&url=trakthistory', 'poster'),
            (g, 'Episodios que he visto', U + 'calendar&url=trakthistory', 'wide'),
            ('Películas', 'En tendencia', U + 'movies&url=trakttrending', 'poster'),
            ('Películas', 'Populares', U + 'tmdbmovies&url=tmdb_popular', 'poster'),
            ('Películas', 'Populares (Trakt)', U + 'movies&url=traktpopular', 'poster'),
            ('Películas', 'Las más esperadas', U + 'movies&url=traktanticipated', 'poster'),
            ('Películas', 'Taquilla', U + 'movies&url=traktboxoffice', 'poster'),
            ('Películas', 'En cines ahora', U + 'tmdbmovies&url=tmdb_nowplaying', 'poster'),
            ('Películas', 'Próximos estrenos', U + 'tmdbmovies&url=tmdb_upcoming', 'poster'),
            ('Películas', 'Mejor valoradas', U + 'tmdbmovies&url=tmdb_toprated', 'poster'),
            ('Películas', 'Premios Óscar', U + 'movies&url=oscars', 'poster'),
            ('Películas', 'Documentales', DOC_PELIS, 'poster'),
            ('Series', 'En tendencia', U + 'tvshows&url=trakttrending', 'poster'),
            ('Series', 'Populares', U + 'tmdbTvshows&url=tmdb_popular', 'poster'),
            ('Series', 'Populares (Trakt)', U + 'tvshows&url=traktpopular', 'poster'),
            ('Series', 'Se emiten hoy', U + 'tmdbTvshows&url=tmdb_airingtoday', 'poster'),
            ('Series', 'En emisión', U + 'tmdbTvshows&url=tmdb_ontheair', 'poster'),
            ('Series', 'Series nuevas', U + 'tvshows&url=tmdb_newshows', 'poster'),
            ('Series', 'Mejor valoradas', U + 'tmdbTvshows&url=tmdb_toprated', 'poster'),
            ('Series', 'Series documentales', DOC_SERIES, 'poster'),
        ]
    if tiene(YT):
        p.append(('Aviación', 'Spotting en Barajas (directo, YouTube)', SPOTTING, 'wide'))
    if pvr:
        p += [
            ('TV', 'Todos los canales', 'pvr://channels/tv/*', 'wide'),
            ('TV', 'Canales vistos recientemente', RECIENTES, 'wide'),
            ('TV', 'Grabaciones recientes', 'pvr://recordings/tv/active?view=flat', 'wide'),
        ]
    return p


def defaults():
    for n in range(1, FILAS + 1):
        fila(n)
    filas = []
    pvr = xbmc.getCondVisibility('System.HasPVRAddon')
    trakt = trakt_en_umbrella()
    if pvr:
        filas.append(('Eventos destacados en TV', EVENTOS, 'wide'))
        filas.append(('Vistos recientemente', RECIENTES, 'wide'))
    if tiene(UMB):
        if trakt:
            filas += [
                ('Continuar viendo: películas', U + 'moviesUnfinished&url=traktunfinished', 'wide'),
                ('Continuar viendo: series', U + 'episodesUnfinished&url=traktunfinished', 'wide'),
                ('Próximos episodios', U + 'calendar&url=progress', 'wide'),
                ('Mi lista: películas', U + 'movies&url=traktwatchlist', 'poster'),
                ('Mi lista: series', U + 'tvshows&url=traktwatchlist', 'poster'),
                ('Recomendadas para ti', U + 'movies&url=traktrecommendations', 'poster'),
                ('Mi colección: películas', U + 'movies&url=traktcollection', 'poster'),
            ]
        filas += [
            ('Películas en tendencia', U + 'movies&url=trakttrending', 'poster'),
            ('Series en tendencia', U + 'tvshows&url=trakttrending', 'poster'),
            ('En cines ahora', U + 'tmdbmovies&url=tmdb_nowplaying', 'poster'),
            ('Las más esperadas', U + 'movies&url=traktanticipated', 'poster'),
            ('Películas populares', U + 'tmdbmovies&url=tmdb_popular', 'poster'),
            ('Series populares', U + 'tmdbTvshows&url=tmdb_popular', 'poster'),
        ]
        if not trakt:
            filas += [
                ('Mejor valoradas', U + 'tmdbmovies&url=tmdb_toprated', 'poster'),
                ('Se emiten hoy', U + 'tmdbTvshows&url=tmdb_airingtoday', 'poster'),
            ]
        filas.append(('Documentales', DOC_PELIS, 'poster'))  # siempre la última
    if tiene(YT) and len(filas) < FILAS:  # si cabe, antes de los documentales (que van al final)
        pos = len(filas) - 1 if filas and filas[-1][1] == DOC_PELIS else len(filas)
        filas.insert(pos, ('Spotting en Barajas (directo)', SPOTTING, 'wide'))
    for n, (label, path, style) in enumerate(filas[:FILAS], 1):
        fila(n, path, nombre(path, label), style)
    xbmc.executebuiltin('Skin.SetBool(lemd.init18)')


def detect():
    """Resumen de lo que hay instalado (Umbrella, Trakt, TV y tiempo)."""
    partes = ['Umbrella: %s' % ('sí' if tiene(UMB) else 'no instalado'),
              'Trakt en Umbrella: %s' % ('vinculado' if trakt_en_umbrella() else 'no vinculado'),
              'TV en directo: %s' % ('sí' if xbmc.getCondVisibility('System.HasPVRAddon') else 'sin cliente PVR (instala IPTV Simple Client)'),
              'Meteorología: %s' % (xbmc.getInfoLabel('Weather.Plugin') or 'sin proveedor')]
    xbmcgui.Dialog().ok('LEMD · estado', '[CR]'.join(partes))


# ---------------------------------------------------------------- explorador
def explorar():
    """Navega por los menus de Umbrella y devuelve (ruta, nombre) de la carpeta elegida."""
    if not tiene(UMB):
        aviso('Umbrella no está instalado')
        return None
    pila = [('plugin://%s/' % UMB, 'Umbrella')]
    while pila:
        ruta, nombre = pila[-1]
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        try:
            res = rpc('Files.GetDirectory', directory=ruta, media='video', properties=['title', 'thumbnail'])
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        carpetas = [f for f in res.get('files', []) if f.get('filetype') == 'directory']
        etiquetas = ['[B]» Usar «%s» como fila[/B]' % nombre] + [f.get('label', '') for f in carpetas]
        j = xbmcgui.Dialog().select(nombre, etiquetas)
        if j < 0:
            pila.pop()
            continue
        if j == 0:
            return ruta, nombre
        f = carpetas[j - 1]
        pila.append((f['file'], f.get('label', '')))
    return None


# ---------------------------------------------------------------- tema Barajas: METAR / TAF
FUENTES_METAR = [
    'https://aviationweather.gov/api/data/metar?ids={icao}&format=raw',
    'https://tgftp.nws.noaa.gov/data/observations/metar/stations/{icao}.TXT',
]
FUENTES_TAF = [
    'https://aviationweather.gov/api/data/taf?ids={icao}&format=raw',
    'https://tgftp.nws.noaa.gov/data/forecasts/taf/stations/{icao}.TXT',
]
FENOMENOS = {
    'DZ': 'llovizna', 'RA': 'lluvia', 'SN': 'nieve', 'SG': 'cinarra', 'PL': 'hielo granulado', 'GR': 'granizo',
    'GS': 'granizo pequeño', 'UP': 'precipitación desconocida', 'BR': 'neblina', 'FG': 'niebla', 'FU': 'humo',
    'VA': 'ceniza volcánica', 'DU': 'polvo', 'SA': 'arena', 'HZ': 'calima', 'PO': 'remolinos de polvo',
    'SQ': 'turbonada', 'FC': 'nube embudo', 'SS': 'tempestad de arena', 'DS': 'tempestad de polvo',
}
DESCRIPTORES = {'MI': 'baja', 'BC': 'en bancos', 'PR': 'parcial', 'DR': 'ventisca baja', 'BL': 'ventisca alta',
                'SH': 'chubascos de', 'TS': 'tormenta con', 'FZ': 'engelante'}
NUBES = {'FEW': 'pocas nubes', 'SCT': 'nubes dispersas', 'BKN': 'muy nuboso', 'OVC': 'cubierto', 'VV': 'visibilidad vertical'}
PUNTOS = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSO', 'SO', 'OSO', 'O', 'ONO', 'NO', 'NNO']


def descargar(urls, icao):
    import urllib.request
    for u in urls:
        try:
            req = urllib.request.Request(u.format(icao=icao), headers={'User-Agent': 'Kodi-skin-LEMD'})
            txt = urllib.request.urlopen(req, timeout=10).read().decode('utf-8', 'replace').strip()
        except Exception:
            continue
        if not txt:
            continue
        import re
        # NOAA pone una primera linea con la fecha (2026/11/25 10:30): fuera
        lineas = [l.strip() for l in txt.splitlines() if l.strip() and not re.match(r'^\d{4}/\d{2}/\d{2}', l.strip())]
        if lineas:
            return ' '.join(lineas) if 'taf' in u.lower() else lineas[0]
    return ''


def decodificar_metar(m):
    """Devuelve (lista de lineas en espanol, viento (dir|None, kt, racha))."""
    import re
    out, viento = [], (None, 0, 0)
    tokens = m.replace('=', '').split()
    for t in tokens:
        if t in ('METAR', 'SPECI', 'AUTO', 'COR') or re.fullmatch(r'[A-Z]{4}', t) and not out and t not in ('CAVOK', 'NSC', 'NCD', 'SKC', 'CLR'):
            continue
        if t in ('NOSIG',):
            out.append('Tendencia: sin cambios significativos')
            break
        if t in ('BECMG', 'TEMPO'):
            out.append('Tendencia: cambios previstos (%s)' % ('temporales' if t == 'TEMPO' else 'graduales'))
            break
        mt = re.fullmatch(r'(\d{2})(\d{2})(\d{2})Z', t)
        if mt:
            out.append('Observación del día %s a las %s:%s UTC' % mt.groups())
            continue
        mw = re.fullmatch(r'(\d{3}|VRB)(\d{2,3})(?:G(\d{2,3}))?(KT|MPS)', t)
        if mw:
            d, v, g, u = mw.groups()
            f = 1.944 if u == 'MPS' else 1.0
            kt, gk = round(int(v) * f), round(int(g) * f) if g else 0
            if d == 'VRB':
                txt = 'Viento variable de %d kt' % kt
                viento = (None, kt, gk)
            elif kt == 0:
                txt = 'Viento en calma'
                viento = (None, 0, 0)
            else:
                txt = 'Viento del %s (%s°) a %d kt (%d km/h)' % (PUNTOS[int((int(d) % 360) / 22.5 + 0.5) % 16], d, kt, round(kt * 1.852))
                viento = (int(d), kt, gk)
            if gk:
                txt += ', rachas de %d kt' % gk
            out.append(txt)
            continue
        mv = re.fullmatch(r'(\d{3})V(\d{3})', t)
        if mv:
            out.append('Dirección variable entre %s° y %s°' % mv.groups())
            continue
        if t == 'CAVOK':
            out.append('CAVOK: visibilidad de 10 km o más y sin nubes significativas')
            continue
        if re.fullmatch(r'\d{4}', t):
            vis = int(t)
            out.append('Visibilidad: %s' % ('10 km o más' if vis >= 9999 else ('%d m' % vis if vis < 5000 else '%.0f km' % (vis / 1000.0))))
            continue
        if t.startswith('R') and '/' in t:
            continue  # alcance visual en pista: se omite
        mn = re.fullmatch(r'(FEW|SCT|BKN|OVC|VV)(\d{3}|///)(CB|TCU)?', t)
        if mn:
            tipo, alt, conv = mn.groups()
            txt = NUBES[tipo]
            if alt != '///':
                txt += ' a %d ft' % (int(alt) * 100)
            if conv:
                txt += ' (%s)' % ('cumulonimbos' if conv == 'CB' else 'cúmulos de gran desarrollo')
            out.append(txt[0].upper() + txt[1:])
            continue
        if t in ('NSC', 'NCD', 'SKC', 'CLR'):
            out.append('Sin nubes significativas')
            continue
        mtd = re.fullmatch(r'(M?\d{2})/(M?\d{2})', t)
        if mtd:
            tt, dd = (int(x.replace('M', '-')) for x in mtd.groups())
            out.append('Temperatura %d °C · punto de rocío %d °C' % (tt, dd))
            continue
        mq = re.fullmatch(r'Q(\d{4})', t)
        if mq:
            out.append('QNH %s hPa' % int(mq.group(1)))
            continue
        ma = re.fullmatch(r'A(\d{4})', t)
        if ma:
            out.append('Altímetro %.2f inHg' % (int(ma.group(1)) / 100.0))
            continue
        mf = re.fullmatch(r'(\+|-|VC)?(MI|BC|PR|DR|BL|SH|TS|FZ)?((?:DZ|RA|SN|SG|PL|GR|GS|UP|BR|FG|FU|VA|DU|SA|HZ|PO|SQ|FC|SS|DS)*)', t)
        if mf and (mf.group(3) or mf.group(2) == 'TS'):
            inten, desc, fen = mf.groups()
            partes = [FENOMENOS[fen[i:i + 2]] for i in range(0, len(fen), 2)]
            txt = ' y '.join(partes)
            if desc == 'TS' and not partes:
                txt, desc = 'tormenta', None
            if desc:
                txt = '%s %s' % (DESCRIPTORES[desc], txt)
            if inten == '-':
                txt += ' débil'
            elif inten == '+':
                txt += ' fuerte'
            elif inten == 'VC':
                txt += ' en las proximidades'
            out.append('Fenómeno: ' + txt)
            continue
    return out, viento


def pistas_lemd(viento):
    """Configuracion de pistas de Barajas estimada a partir del viento.
    Norte (preferente): aterrizajes 32L/32R, despegues 36L/36R.
    Sur: aterrizajes 18L/18R, despegues 14L/14R. Se cambia a Sur con viento en cola en las 32."""
    import math
    d, kt, gk = viento
    norte = 'Configuración NORTE · aterrizajes 32L/32R · despegues 36L/36R'
    sur = 'Configuración SUR · aterrizajes 18L/18R · despegues 14L/14R'
    if d is None or kt <= 5:
        return norte
    cola = -max(kt, gk or 0) * math.cos(math.radians(d - 323))
    return sur if cola > 5 else norte


def metar():
    icao = (xbmc.getInfoLabel('Skin.String(lemd.icao)') or 'LEMD').strip().upper()
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        raw = descargar(FUENTES_METAR, icao)
        taf = descargar(FUENTES_TAF, icao)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if not raw:
        xbmcgui.Dialog().ok('METAR %s' % icao, 'No se pudo descargar el METAR. Comprueba la conexión a Internet.')
        return
    lineas, viento = decodificar_metar(raw)
    pistas = pistas_lemd(viento) if icao == 'LEMD' else ''
    home = xbmcgui.Window(10000)
    home.setProperty('lemd.metar.raw', raw)
    home.setProperty('lemd.metar.resumen', ' · '.join(lineas[1:4]))
    home.setProperty('lemd.metar.pistas', pistas)
    if pistas:  # el METAR manda sobre la estimacion con el viento del tiempo
        sur = 'SUR' in pistas
        home.setProperty('lemd.config', 'SUR' if sur else 'NORTE')
        home.setProperty('lemd.config.pistas', '↓18L/R · ↑14L/R' if sur else '↓32L/R · ↑36L/R')
    texto = ['[B]METAR[/B]', raw, ''] + lineas
    if pistas:
        texto += ['', '[B]Pistas en uso (estimación)[/B]', pistas,
                  'Deducida del viento del METAR; la configuración real la decide el control aéreo.']
    if taf:
        texto += ['', '[B]TAF (previsión)[/B]', taf]
    xbmcgui.Dialog().textviewer('METAR / TAF · %s' % icao, '[CR]'.join(texto))


# ---------------------------------------------------------------- acciones de fila
def elegir(n):
    p = preajustes()
    etiquetas = []
    for g, l, ruta, _ in p:
        par = NOMBRES.get(ruta)
        avion = '  —  «%s»' % par[1] if par and jerga_activa() and par[1] != par[0] else ''
        etiquetas.append('%s  ·  %s%s' % (g, l, avion))
    extra = ['Explorar menús de Umbrella…', 'Escribir la ruta a mano…', 'Quitar esta fila']
    i = xbmcgui.Dialog().select('Fila %d: contenido' % n, extra[:1] + etiquetas + extra[1:])
    if i < 0:
        return
    if i == 0:
        r = explorar()
        if r:
            ruta, nombre = r
            estilo = 'wide' if any(k in ruta.lower() for k in ('episode', 'unfinished', 'progress', 'calendar', 'channel')) else 'poster'
            fila(n, ruta, nombre, estilo)
        return
    i -= 1
    if i < len(p):
        g, l, ruta, estilo = p[i]
        fila(n, ruta, nombre(ruta, l), estilo)
        return
    i -= len(p)
    if i == 0:
        ruta = xbmcgui.Dialog().input('Ruta (plugin://… o pvr://…)', skin_get(n, 'path'))
        if ruta:
            fila(n, ruta, skin_get(n, 'label') or 'Fila %d' % n, skin_get(n, 'style'))
    else:
        fila(n)


CLAVES_DEFECTO = ('fútbol, laliga, liga, champions, europa league, conference league, copa del rey, '
                  'supercopa, mundial, eurocopa, nations league, real madrid, barcelona, atlético, '
                  'derbi, clásico, fórmula 1, f1, gran premio, gp de, motogp, nba, euroliga, acb, '
                  'roland garros, wimbledon, open de australia, us open, ufc, boxeo')


def claves():
    """Palabras clave de «Vuelos destacados» (eventos de la guía)."""
    actual = xbmc.getInfoLabel('Skin.String(lemd.eventos)') or CLAVES_DEFECTO
    t = xbmcgui.Dialog().input('Palabras clave separadas por comas (vacío = las de siempre)', actual)
    if t is None:
        return
    t = t.strip()
    if not t or t == CLAVES_DEFECTO:
        xbmc.executebuiltin('Skin.Reset(lemd.eventos)')
    else:
        xbmc.executebuiltin('Skin.SetString(lemd.eventos,%s)' % escapar(t))
    aviso('Vuelos destacados se actualizará al volver a Inicio')


GEO = 'https://geocoding-api.open-meteo.com/v1/search'


def tiempo_defecto(forzar=False):
    """Si Kodi no tiene proveedor del tiempo, usa el de LEMD (Open-Meteo, sin clave)."""
    if xbmc.getInfoLabel('Weather.Plugin') and not forzar:
        return
    rpc('Settings.SetSettingValue', setting='weather.addon', value='skin.lemd')
    rpc('Settings.SetSettingValue', setting='weather.currentlocation', value=1)
    xbmc.executebuiltin('Weather.Refresh')


def ciudad():
    """Buscar y elegir la ciudad del tiempo (proveedor LEMD)."""
    import urllib.parse
    import urllib.request
    actual = xbmc.getInfoLabel('Skin.String(lemd.tiempo.nombre)') or 'Madrid'
    t = xbmcgui.Dialog().input('Ciudad para el tiempo', actual)
    if not t:
        return
    try:
        url = GEO + '?' + urllib.parse.urlencode({'name': t, 'count': 10, 'language': 'es', 'format': 'json'})
        req = urllib.request.Request(url, headers={'User-Agent': 'Kodi-skin-LEMD'})
        res = json.loads(urllib.request.urlopen(req, timeout=15).read().decode('utf-8')).get('results') or []
    except Exception:
        xbmcgui.Dialog().ok('LEMD', 'No se pudo buscar la ciudad. Comprueba la conexión a Internet.')
        return
    if not res:
        xbmcgui.Dialog().ok('LEMD', 'No he encontrado «%s».' % t)
        return
    opciones = [', '.join(x for x in (r.get('name'), r.get('admin1'), r.get('country')) if x) for r in res]
    i = xbmcgui.Dialog().select('Elige la ciudad', opciones)
    if i < 0:
        return
    r = res[i]
    xbmc.executebuiltin('Skin.SetString(lemd.tiempo.nombre,%s)' % escapar(r.get('name', t)))
    xbmc.executebuiltin('Skin.SetString(lemd.tiempo.lat,%s)' % r['latitude'])
    xbmc.executebuiltin('Skin.SetString(lemd.tiempo.lon,%s)' % r['longitude'])
    if xbmc.getInfoLabel('Weather.Plugin') in ('', 'skin.lemd', 'LEMD'):
        rpc('Settings.SetSettingValue', setting='weather.addon', value='skin.lemd')
    xbmc.sleep(300)
    xbmc.executebuiltin('Weather.Refresh')
    aviso('Tiempo de %s' % r.get('name', t))


TONOS = [('Grafito (recomendado)', 'SKINDEFAULT', 'grafito'), ('Negro', 'negro', 'negro'), ('Gris claro', 'gris', 'gris claro')]


def tono():
    """Tono del fondo de la skin (temas de color de colors/)."""
    i = xbmcgui.Dialog().select('Tono del fondo', [t[0] for t in TONOS])
    if i < 0:
        return
    xbmc.executebuiltin('Skin.SetString(lemd.tono,%s)' % TONOS[i][2])
    rpc('Settings.SetSettingValue', setting='lookandfeel.skincolors', value=TONOS[i][1])


# Cambio de canal con arriba/abajo viendo la TV. Kodi trae arriba/abajo = «ver el canal de al lado
# y pulsar OK para cambiar». LEMD pone un mapa de teclas que, SOLO en la TV a pantalla completa,
# convierte arriba/abajo en canal siguiente/anterior; Kodi cambia tras quedarse un momento en el
# canal (pvrplayback.channelentrytimeout, en ms). No se toca «Confirmar cambio de canal con OK»:
# si se quitara, Kodi cambiaria de canal al pulsar abajo en cualquier menu sin nada debajo.
ZAPPING = [('Automático tras 1 segundo', 1000, '1 s'), ('Automático tras 2 segundos (recomendado)', 2000, '2 s'),
           ('Automático tras 3 segundos', 3000, '3 s'), ('Al momento', 0, 'al momento'),
           ('Solo al pulsar OK (como trae Kodi)', None, 'con OK')]
KEYMAP = 'special://profile/keymaps/lemd_canales.xml'
KEYMAP_XML = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<!-- Creado por la skin LEMD (Ajustes de LEMD > Integraciones > Cambiar de canal con arriba/abajo).\n'
    '     Viendo la TV a pantalla completa, arriba/abajo cambian de canal. Se puede borrar. -->\n'
    '<keymap>\n  <FullscreenLiveTV>\n'
    '    <keyboard><up>ChannelUp</up><down>ChannelDown</down></keyboard>\n'
    '    <remote><up>ChannelUp</up><down>ChannelDown</down></remote>\n'
    '  </FullscreenLiveTV>\n</keymap>\n')


def zapping(elegir=False):
    i = 1
    if elegir:
        i = xbmcgui.Dialog().select('Cambiar de canal con arriba/abajo', [z[0] for z in ZAPPING])
        if i < 0:
            return
    _, espera, texto = ZAPPING[i]
    rpc('Settings.SetSettingValue', setting='pvrplayback.confirmchannelswitch', value=True)
    rpc('Settings.SetSettingValue', setting='pvrplayback.channelentrytimeout', value=espera or 0)
    if espera is None:
        if xbmcvfs.exists(KEYMAP):
            xbmcvfs.delete(KEYMAP)
    else:
        xbmcvfs.mkdirs('special://profile/keymaps/')
        with xbmcvfs.File(KEYMAP, 'w') as f:
            f.write(KEYMAP_XML)
    xbmc.executebuiltin('Action(reloadkeymaps)')
    xbmc.executebuiltin('Skin.SetString(lemd.zapping,%s)' % texto)
    xbmc.executebuiltin('Skin.SetBool(lemd.zapping2)')


# ---------------------------------------------------------------- temporizador de apagado
# En el Fire TV, «apagar» Kodi es cerrarlo: Android no deja a las apps apagar ni dormir el
# aparato. Al cerrarse Kodi, el Fire TV se duerme solo pasado su «Tiempo de suspensión».
def _segundos(etiqueta):
    try:
        p = [int(x) for x in xbmc.getInfoLabel(etiqueta).split(':')]
    except ValueError:
        return 0
    seg = 0
    for x in p:
        seg = seg * 60 + x
    return seg


def apagado():
    opciones, segundos = [], []
    if xbmc.getCondVisibility('Player.HasVideo'):
        if xbmc.getCondVisibility('VideoPlayer.Content(livetv)'):
            resto = _segundos('PVR.EpgEventRemainingTime(hh:mm:ss)')
            texto = 'Al terminar el programa de ahora'
        else:
            resto = _segundos('Player.TimeRemaining(hh:mm:ss)')
            texto = 'Al terminar lo que estoy viendo'
        if resto > 60:
            opciones.append('%s (en %d min)' % (texto, round(resto / 60.0)))
            segundos.append(resto + 30)
    for m in (15, 30, 45, 60, 90, 120, 180):
        opciones.append({60: 'Dentro de 1 hora', 90: 'Dentro de 1 hora y media', 120: 'Dentro de 2 horas',
                         180: 'Dentro de 3 horas'}.get(m, 'Dentro de %d minutos' % m))
        segundos.append(m * 60)
    i = xbmcgui.Dialog().select('Temporizador de apagado', opciones)
    if i < 0:
        return
    seg = segundos[i]
    xbmc.executebuiltin('CancelAlarm(shutdowntimer,true)')
    xbmc.executebuiltin('AlarmClock(shutdowntimer,RunScript(skin.lemd,apagar),%d:%02d,silent)' % (seg // 60, seg % 60))
    xbmcgui.Dialog().notification('Temporizador de apagado', 'Kodi se cerrará en %d min (antes avisa 30 s).' % round(seg / 60.0),
                                  xbmcgui.NOTIFICATION_INFO, 5000)


def apagar():
    """Lo lanza el temporizador: 30 s de aviso para poder cancelarlo y luego cierra Kodi."""
    dp = xbmcgui.DialogProgress()
    dp.create('Temporizador de apagado', 'Kodi se cierra en 30 s. Pulsa Cancelar para seguir viendo.')
    for n in range(30, 0, -1):
        if dp.iscanceled():
            dp.close()
            return
        dp.update(int((30 - n) * 100 / 30), 'Kodi se cierra en %d s. Pulsa Cancelar para seguir viendo.' % n)
        if xbmc.Monitor().waitForAbort(1):
            return
    dp.close()
    xbmc.executebuiltin('PlayerControl(Stop)')
    xbmc.sleep(800)
    xbmc.executebuiltin('Quit()')


# ---------------------------------------------------------------- modo ligero (Fire TV de 1-2 GB)
AVANZADOS = 'special://profile/advancedsettings.xml'
AVANZADOS_XML = (
    '<advancedsettings version="1.0">\n'
    '  <!-- Creado por la skin LEMD: imagenes mas pequenas = menos memoria y cache mas ligera. -->\n'
    '  <imageres>540</imageres>\n'
    '  <fanartres>720</fanartres>\n'
    '</advancedsettings>\n')


def memoria_mb():
    try:
        return int(''.join(c for c in xbmc.getInfoLabel('System.Memory(total)') if c.isdigit()))
    except ValueError:
        return 0


def optimizar(auto=False):
    """Ajustes que bajan memoria y CPU sin quitar nada que se vea. Solo toca lo que esta en su
    valor de serie (si alguien lo cambio a mano, se respeta)."""
    hecho = []
    mem = memoria_mb()

    def poner(ajuste, valor, si_es, texto):
        r = rpc('Settings.GetSettingValue', setting=ajuste)
        if r.get('value') == si_es:
            rpc('Settings.SetSettingValue', setting=ajuste, value=valor)
            hecho.append(texto)
    poner('epg.preventupdateswhileplayingtv', True, False, 'La guía no se actualiza mientras ves la TV')
    poner('epg.futuredaystodisplay', 2, 3, 'Guía: 2 días por delante en vez de 3 (menos memoria)')
    poner('lookandfeel.enablerssfeeds', False, True, 'Noticias RSS desactivadas')
    poner('filelists.showparentdiritems', False, True, 'Sin la casilla «..» al principio de las listas (Atrás del mando hace lo mismo)')
    # tamaño de la interfaz (Android): en 4K sin limite gasta mucha memoria grafica
    gui = rpc('Settings.GetSettingValue', setting='videoscreen.limitgui').get('value')
    if mem and mem < 1700 and gui in (0, 1080, 9999):
        rpc('Settings.SetSettingValue', setting='videoscreen.limitgui', value=720)
        xbmc.executebuiltin('Skin.SetString(lemd.interfaz,720p)')
        hecho.append('Interfaz de Kodi a 720p (poca memoria; el vídeo sigue a su resolución)')
    elif gui == 9999:
        rpc('Settings.SetSettingValue', setting='videoscreen.limitgui', value=1080)
        xbmc.executebuiltin('Skin.SetString(lemd.interfaz,1080p)')
        hecho.append('Interfaz de Kodi limitada a 1080p (el vídeo sigue a su resolución)')
    if not xbmcvfs.exists(AVANZADOS):
        with xbmcvfs.File(AVANZADOS, 'w') as f:
            f.write(AVANZADOS_XML)
        hecho.append('Carteles y fondos a menor resolución (al reiniciar Kodi)')
    if mem and mem < 1700 and not xbmc.getCondVisibility('Skin.HasSetting(lemd.pocamem)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.pocamem)')  # filas de Inicio solo al bajar
        hecho.append('Filas de Inicio: se cargan al bajar (no todas a la vez)')
    if mem and mem < 1700 and not xbmc.getCondVisibility('Skin.HasSetting(lemd.noanim)'):
        xbmc.executebuiltin('Skin.SetBool(lemd.noanim)')
        hecho.append('Sin animaciones (este aparato tiene %d MB de memoria)' % mem)
    xbmc.executebuiltin('Skin.SetBool(lemd.opt1)')
    if auto:
        return
    texto = ['Memoria del aparato: %s' % ('%d MB' % mem if mem else 'desconocida'), '']
    texto += ['· ' + h for h in hecho] if hecho else ['Ya estaba todo optimizado.']
    texto += ['', 'Además, LEMD ya carga las filas de Inicio poco a poco (al bajar), y la mini pantalla '
              'y los fondos solo usan memoria mientras se ven. Para que vaya aún más ligero: '
              'quita filas que no uses (Filas de Inicio) y deja en Kodi solo los grupos de canales '
              'que veas (Integraciones › Elegir grupos de canales).']
    xbmcgui.Dialog().textviewer('Optimizar para el Fire TV', '[CR]'.join(texto))


def interfaz():
    """Tamaño al que Kodi dibuja la interfaz (solo Android). En Kodi esta escondido en
    Ajustes › Sistema › Pantalla con el nivel «Avanzado»."""
    actual = rpc('Settings.GetSettingValue', setting='videoscreen.limitgui').get('value')
    if actual is None:
        xbmcgui.Dialog().ok('Tamaño de la interfaz', 'Este ajuste solo existe en Kodi para Android (Fire TV).')
        return
    ops = [(720, '720p: menos memoria (recomendado con 1-1,5 GB)'), (1080, '1080p: más nítido (2 GB o más)'),
           (0, 'Automático (lo decide Kodi)'), (9999, 'Sin límite (4K: mucha memoria)')]
    pre = next((i for i, (v, _) in enumerate(ops) if v == actual), -1)
    i = xbmcgui.Dialog().select('Tamaño de la interfaz', [t for _, t in ops], preselect=pre)
    if i < 0:
        return
    rpc('Settings.SetSettingValue', setting='videoscreen.limitgui', value=ops[i][0])
    xbmc.executebuiltin('Skin.SetString(lemd.interfaz,%s)' % ops[i][1].split(':')[0].split(' (')[0])
    xbmcgui.Dialog().ok('Tamaño de la interfaz', 'Hecho. Se nota del todo al reiniciar Kodi. El vídeo se sigue viendo a '
                        'su resolución: esto solo cambia menús y textos.')


# ---------------------------------------------------------------- sonidos
SONIDOS = 'resource.uisounds.lemd'


def poner_sonidos(instalar=True):
    """Deja Kodi listo para los sonidos de cabina. Devuelve la lista de cambios hechos.
    Kodi no suena nada (ni el «pim-pum») si los sonidos de la interfaz estan en «Nunca» o el
    paquete de sonidos en «Ninguno»."""
    hecho = []
    det = rpc('Addons.GetAddonDetails', addonid=SONIDOS, properties=['enabled']).get('addon') or {}
    if det and not det.get('enabled'):
        # instalado pero desactivado: Kodi no lo ofrece en Ajustes › Interfaz › Sonidos
        rpc('Addons.SetAddonEnabled', addonid=SONIDOS, enabled=True)
        xbmc.sleep(800)
        hecho.append('Activado el paquete «LEMD · sonidos de cabina» (estaba desactivado)')
    if not xbmc.getCondVisibility('System.HasAddon(%s)' % SONIDOS) and instalar:
        # la skin lo descarga e instala ella misma (no hace falta el repositorio LEMD en Kodi)
        import actualizar_skin
        if actualizar_skin.instalar_sonidos():
            hecho.append('Instalados los sonidos de cabina')
    if xbmc.getCondVisibility('System.HasAddon(%s)' % SONIDOS) and \
            rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value') != SONIDOS:
        rpc('Settings.SetSettingValue', setting='lookandfeel.soundskin', value=SONIDOS)
        if rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value') == SONIDOS:
            hecho.append('Sonidos de la interfaz: LEMD · sonidos de cabina')
        else:
            hecho.append('[COLOR red]Kodi no ha aceptado el paquete de cabina[/COLOR]')
    if not rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value'):
        # sin paquete elegido Kodi no suena nada: al menos los de serie
        rpc('Settings.SetSettingValue', setting='lookandfeel.soundskin', value='resource.uisounds.kodi')
        hecho.append('Sonidos de la interfaz: los de Kodi (estaban en «Ninguno»)')
    if rpc('Settings.GetSettingValue', setting='audiooutput.guisoundmode').get('value') == 0:
        rpc('Settings.SetSettingValue', setting='audiooutput.guisoundmode', value=1)
        hecho.append('Reproducir sonidos de la interfaz: «solo cuando no se reproduce nada» (estaba en «Nunca»)')
    vol = rpc('Settings.GetSettingValue', setting='audiooutput.guisoundvolume').get('value')
    if isinstance(vol, int) and vol < 60:
        rpc('Settings.SetSettingValue', setting='audiooutput.guisoundvolume', value=100)
        hecho.append('Volumen de los sonidos de la interfaz: 100 %% (estaba en %d %%)' % vol)
    if rpc('Settings.GetSettingValue', setting='audiooutput.streamsilence').get('value') == 0:
        # con el audio «dormido», el Fire TV tarda en despertarlo y un sonido corto se pierde
        rpc('Settings.SetSettingValue', setting='audiooutput.streamsilence', value=1)
        hecho.append('Mantener el audio despierto 1 minuto (si no, los sonidos cortos se pierden)')
    return hecho


SIGUIENTE = ('next page', 'página siguiente', 'pagina siguiente', 'siguiente', 'next', 'más…', 'more')


def siguiente():
    """Abajo en la ultima fila de una lista de add-on: abre su pagina siguiente (el elemento
    «Next page» que Umbrella y otros ponen al final), con la misma vista."""
    cid = xbmc.getInfoLabel('System.CurrentControlId')
    try:
        n = int(xbmc.getInfoLabel('Container(%s).NumItems' % cid) or 0)
    except ValueError:
        return
    for i in (n - 1, n):  # n si hay elemento «..» al principio
        if i < 0:
            continue
        base = 'Container(%s).ListItemAbsolute(%d).' % (cid, i)
        etiqueta = re.sub(r'\[/?[A-Z]+[^\]]*\]', '', xbmc.getInfoLabel(base + 'Label')).strip().lower()
        ruta = xbmc.getInfoLabel(base + 'FolderPath')
        especial = xbmc.getInfoLabel(base + 'Property(SpecialSort)') == 'bottom'
        if ruta and ruta != xbmc.getInfoLabel('Container.FolderPath') and (especial or etiqueta.startswith(SIGUIENTE)):
            xbmc.executebuiltin('Container.Update(%s)' % escapar(ruta))
            return


def probar_sonidos():
    hecho = poner_sonidos()
    sonando = xbmc.getCondVisibility('Player.HasMedia')
    piel = rpc('Settings.GetSettingValue', setting='lookandfeel.soundskin').get('value') or ''
    try:
        nombre = xbmcaddon.Addon(piel).getAddonInfo('name') if piel else 'ninguno'
    except Exception:
        nombre = piel
    det = rpc('Addons.GetAddonDetails', addonid=SONIDOS, properties=['enabled', 'version']).get('addon') or {}
    if not det:
        estado = '[COLOR red]no instalado[/COLOR] (¿sin Internet? Vuelve a probar en un rato)'
    elif not det.get('enabled'):
        estado = '[COLOR red]desactivado[/COLOR]: Add-ons › Mis add-ons › Sonidos de la interfaz › LEMD › Activar'
    else:
        estado = 'instalado y activado (versión %s)' % det.get('version', '?')
    texto = ['[B]Sonidos de la interfaz:[/B] %s' % nombre, '[B]Paquete de cabina:[/B] %s' % estado]
    texto += ['', 'Cambiado ahora:'] + ['· ' + h for h in hecho] if hecho else ['', 'Todo estaba bien puesto.']
    if sonando:
        texto += ['', 'Ahora se está reproduciendo algo: Kodi no hace sonar la interfaz mientras tanto. '
                  'Para el vídeo o el canal y vuelve a probar.']
    texto += ['', 'Al cerrar esta ventana suena el «pim-pum». Si no lo oyes, sube el volumen del Fire TV o de '
              'la tele (algunas barras de sonido tardan en despertar y se comen los sonidos cortos).']
    xbmcgui.Dialog().textviewer('Probar los sonidos', '[CR]'.join(texto))
    xbmc.sleep(400)
    ruta = os.path.join(xbmcaddon.Addon('skin.lemd').getAddonInfo('path'), 'sounds', 'cinturon.wav')
    xbmc.playSFX(ruta, False)
    xbmc.sleep(2700)


def actualizar():
    """Cambios de una sola vez al estrenar una version (Inicio lo lanza si falta alguna marca)."""
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.zapping2)'):
        zapping()
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.opt1)'):
        optimizar(auto=True)
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.umb20)'):
        # la 1.7.4 subio Umbrella a 40 por pagina: las filas de Inicio tardaban mas. Vuelve a 20
        # (las filas muestran 15 y «Ver todo» pasa de pagina)
        try:
            if tiene(UMB) and xbmcaddon.Addon(UMB).getSetting('page.item.limit') in ('40', '40.0'):
                xbmcaddon.Addon(UMB).setSetting('page.item.limit', '20')
        except Exception as e:
            xbmc.log('[LEMD] umbrella 20: %s' % e, xbmc.LOGWARNING)
        xbmc.executebuiltin('Skin.SetBool(lemd.umb20)')
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.sonidos3)'):
        # sonidos de cabina (tono flojito al moverse, «ding» al elegir, «pim-pum»...): una vez
        xbmc.executebuiltin('Skin.SetBool(lemd.sonidos3)')
        if poner_sonidos():
            xbmcgui.Dialog().notification('LEMD', 'Sonidos de cabina activados', xbmcgui.NOTIFICATION_INFO, 4000)
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.mem1)'):
        mem = memoria_mb()
        if mem and mem < 1700:
            xbmc.executebuiltin('Skin.SetBool(lemd.pocamem)')  # filas de Inicio solo al bajar
        xbmc.executebuiltin('Skin.SetBool(lemd.mem1)')
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.doblem2)'):
        # la guia de dobleM pasa a ser la principal (una vez; se puede volver a la del proveedor).
        # Si hay algo reproduciendose, se deja para la proxima vez (antes se daba por hecho: fallo)
        import reparar
        if not tiene('pvr.iptvsimple') or xbmc.getInfoLabel('Skin.String(lemd.guia)') == 'proveedor' \
                or reparar.usa_dobleM():
            xbmc.executebuiltin('Skin.SetBool(lemd.doblem2)')
        elif not xbmc.getCondVisibility('Player.HasMedia'):
            intentos = int(xbmc.getInfoLabel('Skin.String(lemd.doblem.intentos)') or 0) + 1
            xbmc.executebuiltin('Skin.SetString(lemd.doblem.intentos,%d)' % intentos)
            if reparar.poner_dobleM(silencioso=True) or intentos >= 3:
                xbmc.executebuiltin('Skin.SetBool(lemd.doblem2)')
    if not xbmc.getCondVisibility('Skin.HasSetting(lemd.recientes1)'):
        # «Últimas puertas»: la fila de Kodi no deja quitar canales; la de LEMD si
        for n in range(1, FILAS + 1):
            if skin_get(n, 'path') == LASTPLAYED:
                skin_set(n, 'path', RECIENTES)
        xbmc.executebuiltin('Skin.SetBool(lemd.recientes1)')


def renombrar(n):
    t = xbmcgui.Dialog().input('Nombre de la fila %d' % n, skin_get(n, 'label'))
    if t:
        skin_set(n, 'label', t)


def estilo(n):
    skin_set(n, 'style', '' if skin_get(n, 'style') == 'wide' else 'wide')


def mover(n, d):
    m = n + d
    if not 1 <= m <= FILAS:
        return
    a = {c: skin_get(n, c) for c in CAMPOS}
    b = {c: skin_get(m, c) for c in CAMPOS}
    for c in CAMPOS:
        skin_set(n, c, b[c])
        skin_set(m, c, a[c])


def menu_fila(n):
    nombre = skin_get(n, 'label') or 'vacía'
    vacia = not skin_get(n, 'path')
    ops = [('Cambiar contenido…', elegir)]
    if not vacia:
        es_wide = skin_get(n, 'style') == 'wide'
        ops += [('Renombrar…', renombrar),
                ('Estilo: %s (cambiar a %s)' % (('Panorámica', 'Carteles') if es_wide else ('Carteles', 'Panorámica')), estilo)]
        if n > 1:
            ops.append(('Subir', lambda k: mover(k, -1)))
        if n < FILAS:
            ops.append(('Bajar', lambda k: mover(k, 1)))
        ops.append(('Quitar fila', lambda k: fila(k)))
    i = xbmcgui.Dialog().select('Fila %d · %s' % (n, nombre), [o[0] for o in ops])
    if i >= 0:
        ops[i][1](n)


def main():
    args = sys.argv[1:]
    if not args:
        return
    accion = args[0]
    n = int(args[1]) if len(args) > 1 and args[1].isdigit() else 0
    if accion == 'defaults':
        defaults()
    elif accion == 'resetall':
        if xbmcgui.Dialog().yesno('LEMD', '¿Volver a las filas de Inicio por defecto?'):
            defaults()
    elif accion == 'detect':
        detect()
    elif accion == 'widget' and n:
        elegir(n)
    elif accion == 'label' and n:
        renombrar(n)
    elif accion == 'style' and n:
        estilo(n)
    elif accion == 'up' and n:
        mover(n, -1)
    elif accion == 'down' and n:
        mover(n, 1)
    elif accion == 'clear' and n:
        fila(n)
    elif accion == 'row' and n:
        menu_fila(n)
    elif accion == 'jerga':
        renombrar_jerga()
    elif accion == 'claves':
        claves()
    elif accion == 'ciudad':
        ciudad()
    elif accion == 'tiempodefecto':
        tiempo_defecto()
    elif accion == 'usartiempo':
        tiempo_defecto(True)
        aviso('Tiempo: LEMD · Open-Meteo')
    elif accion == 'tono':
        tono()
    elif accion == 'vpn':
        import vigia
        vigia.marcar_vpn()
    elif accion == 'vpninfo':
        import vigia
        vigia.marcar_vpn()
        xbmcgui.Dialog().textviewer('Comprobar VPN', vigia.informe())
    elif accion == 'arranque':  # una vez por sesion, al abrir Inicio
        import vigia
        vigia.marcar_vpn()
        if not xbmc.getCondVisibility('Skin.HasSetting(lemd.noupdcheck)'):
            import actualizar_skin
            actualizar_skin.comprobar()
            actualizar_skin.actualizar_sonidos()
    elif accion == 'buscarupd':
        import actualizar_skin
        actualizar_skin.actualizar_sonidos()
        actualizar_skin.comprobar(manual=True)
    elif accion == 'canal':
        import vigia
        marcar = args[1:]
        vigia.ver_canal(marcar[0] if marcar else '', marcar[1] if len(marcar) > 1 else '')
    elif accion == 'reparar':
        import reparar
        reparar.reparar(auto=len(args) > 1 and args[1] == 'auto')
    elif accion == 'restaurar':
        import reparar
        reparar.restaurar()
    elif accion == 'metar':
        metar()
    elif accion == 'siguiente':
        siguiente()
    elif accion == 'sonidos':
        probar_sonidos()
    elif accion == 'chime':
        # «pim-pum» de la senal de cinturones (sintetizado: herramientas/generar_cinturon.py)
        ruta = os.path.join(xbmcaddon.Addon('skin.lemd').getAddonInfo('path'), 'sounds', 'cinturon.wav')
        if os.path.exists(ruta):
            xbmc.playSFX(ruta, False)
            xbmc.sleep(2700)  # que termine antes de cerrar el script
    elif accion == 'interfaz':
        interfaz()
    elif accion == 'optimizar':
        optimizar()
    elif accion == 'apagado':
        apagado()
    elif accion == 'apagar':
        apagar()
    elif accion == 'actualizar':
        actualizar()
    elif accion == 'fuenteguia':
        import reparar
        reparar.fuente_guia()
    elif accion == 'grupos':
        import reparar
        reparar.elegir_grupos()
    elif accion == 'zapping':
        zapping(elegir=len(args) > 1 and args[1] == 'elegir')


if __name__ == '__main__':
    main()
