# -*- coding: utf-8 -*-
"""Calendario deportivo real (ESPN, gratis y sin clave) para «Vuelos destacados».

Se descarga como mucho cada 3 horas (unas 35 consultas pequenas en paralelo, ~1 s) y se
cruza con la guia de TV: un programa solo es «destacado» si coincide con un evento real por
equipos o por competicion Y empieza a esa hora. Asi se quedan fuera reemisiones, previas y
resumenes, y entran partidos aunque el titulo de la guia no diga «LaLiga».
Sin conexion devuelve None y fuente.py usa las palabras clave de siempre.
"""
import json
import os
import re
import time
import unicodedata
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

API = 'https://site.api.espn.com/apis/site/v2/sports/%s/scoreboard?dates=%s'
DURACION_CACHE = 3 * 3600
# ruta ESPN -> (nombre corto, palabras que identifican la competicion en la guia)
LIGAS = {
    'soccer/esp.1': ('LaLiga', ['laliga', 'la liga', 'liga ea', 'primera division']),
    'soccer/esp.copa_del_rey': ('Copa del Rey', ['copa del rey']),
    'soccer/esp.super_cup': ('Supercopa', ['supercopa']),
    'soccer/uefa.champions': ('Champions', ['champions', 'liga de campeones']),
    'soccer/uefa.europa': ('Europa League', ['europa league', 'uefa europa']),
    'soccer/uefa.europa.conf': ('Conference', ['conference league', 'conference']),
    'soccer/uefa.nations': ('Nations League', ['nations league', 'liga de naciones']),
    'soccer/fifa.world': ('Mundial', ['mundial', 'copa del mundo']),
    'soccer/uefa.euro': ('Eurocopa', ['eurocopa']),
    'soccer/fifa.cwc': ('Mundial de Clubes', ['mundial de clubes']),
    'basketball/nba': ('NBA', ['nba']),
    'mma/ufc': ('UFC', ['ufc']),
}
F1 = 'racing/f1'
CLAVES_F1 = ['f1', 'formula 1', 'gran premio', 'gp']
SESIONES = {'FP1': 'Libres 1', 'FP2': 'Libres 2', 'FP3': 'Libres 3', 'Qual': 'Clasificación',
            'SQ': 'Clasificación sprint', 'Sprint': 'Sprint', 'Race': 'Carrera'}
# palabras que no identifican a un equipo
VACIAS = {'fc', 'cf', 'cd', 'ud', 'sd', 'rc', 'rcd', 'sad', 'club', 'de', 'del', 'la', 'el', 'los', 'las',
          'the', 'afc', 'ac', 'as', 'sc', 'ss', 'sv', 'fk', 'bk', 'if', 'cp', 'ca', 'sk', 'nk', 'and', 'y'}


def normal(t):
    t = unicodedata.normalize('NFD', (t or '').lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9]+', ' ', t).strip()


def fichas(nombre):
    return frozenset(p for p in normal(nombre).split() if p not in VACIAS)


def _pedir(ruta, fechas):
    req = urllib.request.Request(API % (ruta, fechas), headers={'User-Agent': 'Kodi-skin-LEMD',
                                                               'Accept-Encoding': 'gzip'})
    with urllib.request.urlopen(req, timeout=8) as r:
        datos = r.read()
        if r.headers.get('Content-Encoding') == 'gzip':
            import gzip
            datos = gzip.decompress(datos)
    return ruta, json.loads(datos.decode('utf-8'))


def _ts(fecha):
    return int(datetime.strptime(fecha, '%Y-%m-%dT%H:%MZ').replace(tzinfo=timezone.utc).timestamp())


def descargar():
    hoy = datetime.now()
    dias = [(hoy + timedelta(days=i)).strftime('%Y%m%d') for i in range(3)]
    trabajos = [(r, d) for r in LIGAS for d in dias]
    trabajos.append((F1, '%s-%s' % (dias[0], (hoy + timedelta(days=3)).strftime('%Y%m%d'))))
    eventos, ok = [], 0
    with ThreadPoolExecutor(max_workers=8) as ex:
        for fut in [ex.submit(_pedir, r, d) for r, d in trabajos]:
            try:
                ruta, datos = fut.result()
            except Exception:
                continue
            ok += 1
            for e in datos.get('events', []):
                try:
                    if ruta == F1:
                        gp = e.get('name', '').replace('Grand Prix', 'GP').strip()
                        for s in e.get('competitions', []):
                            tipo = (s.get('type') or {}).get('abbreviation', '')
                            eventos.append({'liga': 'F1', 'nombre': '%s · %s' % (gp, SESIONES.get(tipo, tipo)),
                                            'inicio': _ts(s['date']), 'equipos': [], 'claves': CLAVES_F1,
                                            'margen': 10 * 60})
                        continue
                    comp = e['competitions'][0]
                    equipos = []
                    for c in comp.get('competitors', []):
                        t = c.get('team') or {}
                        variantes = {fichas(t.get(k, '')) for k in ('displayName', 'shortDisplayName', 'name', 'location')}
                        equipos.append([v for v in variantes if v])
                    eventos.append({'liga': LIGAS[ruta][0], 'nombre': e.get('name', ''), 'inicio': _ts(e['date']),
                                    'equipos': equipos, 'claves': LIGAS[ruta][1], 'margen': 15 * 60})
                except (KeyError, ValueError, TypeError):
                    continue
    if not ok:
        return None
    vistos, unicos = set(), []
    for e in eventos:
        k = (e['nombre'], e['inicio'])
        if k not in vistos:
            vistos.add(k)
            unicos.append(e)
    return unicos


def calendario(cache):
    """Eventos reales de las proximas ~72 h (cache de 3 h) o None si no hay conexion."""
    try:
        with open(cache, encoding='utf-8') as f:
            d = json.load(f)
        if d.get('v') == 1 and time.time() - d['hora'] < DURACION_CACHE:
            return _cargar(d['eventos'])
    except Exception:
        pass
    evs = descargar()
    if evs is None:
        return None
    try:
        os.makedirs(os.path.dirname(cache), exist_ok=True)
        guardar = [dict(e, equipos=[[sorted(v) for v in eq] for eq in e['equipos']]) for e in evs]
        with open(cache, 'w', encoding='utf-8') as f:
            json.dump({'v': 1, 'hora': time.time(), 'eventos': guardar}, f)
    except Exception:
        pass
    return evs


def _cargar(lista):
    for e in lista:
        e['equipos'] = [[frozenset(v) for v in eq] for eq in e['equipos']]
    return lista


def _tiene(palabras, texto_norm, clave):
    return (' %s ' % clave) in (' %s ' % texto_norm)


def casar(titulo, ini, fin, eventos):
    """Evento real con el que coincide un programa de la guia (o None).
    Hora: el programa tiene que estar emitiendose al empezar el evento (y un rato despues)."""
    tn = normal(titulo)
    palabras = set(tn.split())
    mejor = None
    for e in eventos:
        if not (ini <= e['inicio'] + 20 * 60 and fin >= e['inicio'] + e['margen']):
            continue
        equipos_ok = sum(1 for eq in e['equipos'] if any(v and v <= palabras for v in eq))
        if e['equipos'] and not equipos_ok:
            continue  # partido: tiene que salir algun equipo (no vale «LaLiga» en una tertulia)
        liga_ok = any(_tiene(palabras, tn, c) for c in e['claves'])
        if equipos_ok == 2:
            return e
        if equipos_ok == 1 or liga_ok:
            mejor = mejor or e
    return mejor
