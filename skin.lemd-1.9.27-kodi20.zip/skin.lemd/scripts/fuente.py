# -*- coding: utf-8 -*-
"""Fuente de contenido de LEMD (plugin://skin.lemd/...). Solo se ejecuta cuando Inicio
pinta una fila que la usa; no hay servicio en segundo plano.

  plugin://skin.lemd/?accion=eventos          «Vuelos destacados»: proximos eventos de la guia
                                              (futbol, F1, MotoGP...) segun las palabras clave
  plugin://skin.lemd/?accion=ver&canal=N      pone el canal N (lo usa la fila al pulsar)
  plugin://skin.lemd/?accion=recientes        «Últimas puertas»: canales vistos hace poco. Al dejar
                                              pulsado OK: quitar uno o vaciar la fila
  plugin://skin.lemd/?accion=trakt            menu de Trakt (las secciones de Trakt de Umbrella)

Lee la guia directamente de las bases de datos de Kodi (Epg*.db y TV*.db), que es mucho mas
ligero que pedir la programacion canal a canal, y la cruza con el calendario real de ESPN
(calendario.py): futbol, F1, NBA y UFC solo entran si coinciden con un evento real a esa hora.
Lo demas (MotoGP, tenis...) va por palabras clave, y tambien todo si no hay conexion.
El resultado se guarda 20 minutos y el calendario 3 horas.
"""
import glob
import json
import os
import re
import sqlite3
import sys
import time
import unicodedata
from contextlib import closing
from datetime import datetime, timedelta
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = 'skin.lemd'
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
PARAMS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
CACHE = xbmcvfs.translatePath('special://profile/addon_data/%s/eventos.json' % ADDON)
DURACION_CACHE = 20 * 60
HORAS = 48          # cuanto miramos hacia delante
MAXIMO = 30

CLAVES_DEFECTO = ('fútbol, laliga, liga, champions, europa league, conference league, copa del rey, '
                  'supercopa, mundial, eurocopa, nations league, real madrid, barcelona, atlético, '
                  'derbi, clásico, fórmula 1, f1, gran premio, gp de, motogp, nba, euroliga, acb, '
                  'roland garros, wimbledon, open de australia, us open, ufc, boxeo')
# programas que mencionan esas palabras pero no son eventos
EXCLUIR = ('resumen', 'previa', 'tertulia', 'magazine', 'noticias', 'informativo', 'repetición',
           'highlights', 'mejores momentos', 'código f1', 'gearbox', 'reportaje', 'entrevista',
           'rueda de prensa', 'pesaje', 'cara a cara', 'post partido', 'postpartido', 'pospartido',
           'análisis', 'debate', 'documental', 'diferido', 'reemisión', 'redifusión', 'lo mejor',
           'goles de', 'todos los goles', 'jugadas', 'el día después', 'chiringuito', 'clásicos de',
           'historia de', 'leyendas', 'grandes momentos', 'en el vestuario', 'zona mixta')
MIN_DURACION = 40 * 60  # lo que no confirma el calendario y dura menos (entrevistas, avances...) no entra
DIAS = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo']
CALENDARIO = xbmcvfs.translatePath('special://profile/addon_data/%s/calendario.json' % ADDON)
# motociclismo: el calendario (ESPN) no lo tiene; entra por palabras clave
MOTOS = ['motogp', 'moto2', 'moto3', 'superbike', 'motociclismo']


def normal(t):
    t = unicodedata.normalize('NFD', (t or '').lower())
    return ''.join(c for c in t if unicodedata.category(c) != 'Mn')


def claves():
    txt = xbmc.getInfoLabel('Skin.String(lemd.eventos)') or CLAVES_DEFECTO
    return [normal(c.strip()) for c in txt.split(',') if c.strip()]


def coincide(titulo, lista):
    t = ' %s ' % re.sub(r'[^a-z0-9]+', ' ', normal(titulo))
    for c in lista:
        c = re.sub(r'[^a-z0-9]+', ' ', c).strip()
        if c and (' %s ' % c) in t:
            return True
    return False


def base(patron):
    ficheros = glob.glob(os.path.join(xbmcvfs.translatePath('special://database/'), patron))
    ficheros.sort(key=lambda f: int(re.sub(r'\D', '', os.path.basename(f)) or 0))
    return ficheros[-1] if ficheros else None


def cuando(inicio, ahora):
    hora = inicio.strftime('%H:%M')
    if inicio.date() == ahora.date():
        return 'Hoy ' + hora
    if inicio.date() == (ahora + timedelta(days=1)).date():
        return 'Mañana ' + hora
    return '%s %s' % (DIAS[inicio.weekday()].capitalize(), hora)


COLOR = re.compile(r'\[(?:COLOR [^\]]*|/COLOR|B|/B|I|/I)\]', re.I)
TEMPORADA = re.compile(r'^T\d{2}(/\d{2})?$|^T\d{4}$')


def analizar(titulo):
    """(titulo limpio, competicion, en_directo). La guia dobleM pone titulos como
    «DIRECTO Jornada 14: Elche - Atlético [COLOR tomato]T26/27[/COLOR] [COLOR goldenrod]LALIGA EA SPORTS[/COLOR]»."""
    t = titulo or ''
    partes = [p.strip() for p in re.split(r'\[COLOR [^\]]*\](.*?)\[/COLOR\]', t, flags=re.I)]
    partes = [COLOR.sub('', p).strip() for p in partes]
    partes = [p for p in partes if p and not TEMPORADA.match(p)]
    directo = bool(partes) and partes[0].upper().startswith('DIRECTO')
    if directo:
        partes[0] = partes[0][7:].strip(' :-·')
        partes = [p for p in partes if p]
    if len(partes) >= 2:
        # el partido es la parte con «A - B»; la otra, la competicion
        partido = next((p for p in partes if ' - ' in p), partes[0])
        liga = next((p for p in partes if p is not partido), '')
        return partido, liga, directo
    return (partes[0] if partes else COLOR.sub('', t).strip()), '', directo


def buscar():
    epg, tv = base('Epg*.db'), base('TV*.db')
    if not epg or not tv:
        return []
    ahora_ts = int(time.time())
    lista = claves()
    excluir = [normal(e) for e in EXCLUIR]
    canales = {}
    with closing(sqlite3.connect('file:%s?mode=ro' % tv, uri=True, timeout=5)) as c:
        for idc, nombre, icono, idepg, numero in c.execute(
                'SELECT c.idChannel, c.sChannelName, c.sIconPath, c.idEpg, MIN(m.iChannelNumber) '
                'FROM channels c LEFT JOIN map_channelgroups_channels m ON m.idChannel = c.idChannel '
                'WHERE c.bIsRadio = 0 AND c.bIsHidden = 0 GROUP BY c.idChannel'):
            canales[idepg] = (idc, nombre, icono, numero or 9999)
    try:
        import calendario as cal
        reales = cal.calendario(CALENDARIO)
    except Exception as e:
        xbmc.log('[LEMD] calendario: %s' % e, xbmc.LOGWARNING)
        reales = None
    if reales is not None:  # solo los eventos que caen en la ventana de la guia
        reales = [e for e in reales if ahora_ts - 4 * 3600 < e['inicio'] < ahora_ts + HORAS * 3600]
    eventos = {}
    # Primer filtro dentro de SQLite (rapido aunque la guia tenga millones de programas): solo
    # programas que contienen alguna palabra clave o que se emiten cuando empieza un evento real.
    filtro, args = [], [ahora_ts, ahora_ts + HORAS * 3600]
    for k in set(lista) | set(c.strip().lower() for c in (xbmc.getInfoLabel('Skin.String(lemd.eventos)')
                                                           or CLAVES_DEFECTO).split(',') if c.strip()):
        filtro.append('sTitle LIKE ?')
        args.append('%' + k + '%')
    for e in (reales or []):
        # a esa hora y con el nombre de un equipo o de la competicion en el titulo
        palabras = {max(v, key=len) for eq in e['equipos'] for v in eq if v} | set(e['claves'])
        palabras = {re.sub(r'[^a-z0-9 ]', '', w) for w in palabras}  # sin comillas: va dentro del SQL
        palabras = [w for w in palabras if len(w) >= 2]
        if not palabras:
            continue
        filtro.append('(iStartTime <= %d AND iEndTime >= %d AND (%s))' % (
            e['inicio'] + 20 * 60, e['inicio'] + e['margen'], ' OR '.join("sTitle LIKE '%%%s%%'" % w for w in palabras)))
    # guia dobleM: «DIRECTO ...» con categoria de deportes = retransmision en vivo
    filtro.append("(sTitle LIKE 'DIRECTO%' AND (sGenre LIKE '%Sport%' OR sGenre LIKE '%Football%' "
                  "OR sGenre LIKE '%Deport%' OR sGenre LIKE '%Motor%' OR sGenre LIKE '%Tennis%'))")
    with closing(sqlite3.connect('file:%s?mode=ro' % epg, uri=True, timeout=5)) as c:
        for idepg, titulo, plot, icono, ini, fin, genero in c.execute(
                'SELECT idEpg, sTitle, sPlot, sIconPath, iStartTime, iEndTime, sGenre FROM epgtags '
                'WHERE iEndTime > ? AND iStartTime < ? AND (%s) ORDER BY iStartTime' % ' OR '.join(filtro), args):
            if idepg not in canales or not titulo:
                continue
            titulo, liga_guia, directo = analizar(titulo)
            nt = normal(titulo)
            if any(e in nt for e in excluir):
                continue
            deporte = bool(re.search(r'sport|football|deport|motor|tennis', (genero or '').lower()))
            real = cal.casar(titulo, ini, fin, reales) if reales else None
            prio = 0
            directo = directo or bool(re.search(r'\ben directo\b|\(directo\)|\(d\)$', nt))
            if real:
                pass
            elif fin - ini < MIN_DURACION:
                continue  # entrevistas, avances, conexiones...
            elif directo and deporte:
                # dobleM dice que es en directo y de deportes: vale siempre; si no es de lo que
                # buscas (palabras clave), va detras de lo importante
                prio = 0 if coincide(titulo + ' ' + liga_guia, lista) else 1
            elif directo and coincide(titulo, lista):
                pass
            elif coincide(titulo, MOTOS) and coincide(titulo, lista):
                pass  # motos: el calendario no las tiene
            else:
                continue  # sin calendario ni «directo»: reemision, previa, programa...
            canal = canales[idepg]
            # el mismo evento en varios canales (FHD, HD... o con otro titulo): solo una vez
            clave = ('real', real['nombre'], real['inicio']) if real else (nt, ini)
            if clave in eventos and eventos[clave]['numero'] <= canal[3]:
                continue
            eventos[clave] = {'titulo': titulo, 'plot': plot or '', 'icono': icono or '', 'inicio': ini,
                              'fin': fin, 'genero': genero or '', 'canal': canal[0], 'nombre': canal[1],
                              'logo': canal[2] or '', 'numero': canal[3],
                              'liga': real['liga'] if real else liga_guia, 'prio': prio}
    # lo confirmado (calendario o palabras clave) primero; el resto de directos, si queda sitio
    res = sorted(eventos.values(), key=lambda e: (e['prio'], e['inicio'], e['numero']))[:MAXIMO]
    res.sort(key=lambda e: (e['inicio'], e['numero']))
    for e in res:  # logo tal como lo muestra Kodi (la base de datos a veces no lo tiene)
        e['logo'] = logo_canal(e['canal']) or e['logo']
    return res


def rpc(metodo, **p):
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': metodo,
                                                          'params': p}))).get('result') or {}
    except Exception:
        return {}


def detalles_canal(idc, extra=()):
    return rpc('PVR.GetChannelDetails', channelid=int(idc),
               properties=['thumbnail', 'icon'] + list(extra)).get('channeldetails') or {}


def logo_canal(idc):
    d = detalles_canal(idc)
    return d.get('thumbnail') or d.get('icon') or ''


def eventos_con_cache():
    try:
        with open(CACHE, encoding='utf-8') as f:
            datos = json.load(f)
        if datos.get('v') == 5 and time.time() - datos['hora'] < DURACION_CACHE and datos['claves'] == claves():
            ahora = time.time()
            return [e for e in datos['eventos'] if e['fin'] > ahora]
    except Exception:
        pass
    try:
        evs = buscar()
    except Exception as e:  # base de datos ocupada o de otra version: fila vacia, sin errores
        xbmc.log('[LEMD] eventos: %s' % e, xbmc.LOGWARNING)
        return []
    if evs:
        try:
            os.makedirs(os.path.dirname(CACHE), exist_ok=True)
            with open(CACHE, 'w', encoding='utf-8') as f:
                json.dump({'v': 5, 'hora': time.time(), 'claves': claves(), 'eventos': evs}, f)
        except Exception:
            pass
    return evs


def url_canal(canal, inicio=0, titulo=''):
    """Pulsar = poner el canal YA. Si el elemento apunta a esta fuente (plugin://), Kodi lo trata
    como un video a «resolver» y se queda esperando antes de cambiar de canal (lo que tardaba).
    Con favourites:// Kodi ejecuta directamente la orden, como un favorito."""
    from urllib.parse import quote
    if xbmc.getCondVisibility('Window.IsActive(videos)'):
        # en «Ver todo» (ventana Videos) Kodi no abre favourites://: ahi, como antes
        return 'plugin://%s/?%s' % (ADDON, urlencode({'accion': 'ver', 'canal': canal, 'titulo': titulo or '',
                                                       'inicio': int(inicio)}))
    orden = 'RunScript(skin.lemd,vercanal,%d,%d,%s)' % (int(canal), int(inicio), quote(titulo or '', safe=''))
    return 'favourites://' + quote(orden, safe='')


def listar_eventos():
    xbmcplugin.setContent(HANDLE, 'videos')
    ahora_ts = time.time()
    ahora = datetime.now()
    for e in eventos_con_cache():
        ini = datetime.fromtimestamp(e['inicio'])
        en_directo = e['inicio'] <= ahora_ts < e['fin']
        texto = ('En directo' if en_directo else cuando(ini, ahora)) + ' · ' + e['nombre']
        if e.get('liga'):
            texto = e['liga'] + ' · ' + texto
        li = xbmcgui.ListItem(e['titulo'], label2=texto, offscreen=True)
        info = li.getVideoInfoTag()
        info.setTitle(e['titulo'])
        info.setPlot(e['plot'])
        if e['genero']:
            info.setGenres([e['genero']])
        info.setDuration(int(e['fin'] - e['inicio']))
        # siempre el logo del canal (la imagen del evento a veces no carga y la ficha sale vacia)
        li.setArt({'icon': e['logo'], 'thumb': e['logo']})
        li.setProperty('lemd.evento', '1')
        li.setProperty('lemd.cuando', texto)
        if en_directo:
            li.setProperty('lemd.directo', '1')
        url = url_canal(e['canal'], e['inicio'], e['titulo'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def ver():
    canal = int(PARAMS.get('canal', 0))
    inicio = int(PARAMS.get('inicio', 0))
    if inicio > time.time() + 60:
        hora = cuando(datetime.fromtimestamp(inicio), datetime.now())
        if not xbmcgui.Dialog().yesno('LEMD', '«%s» empieza %s.[CR]¿Poner el canal ahora?' % (
                PARAMS.get('titulo', ''), hora.lower() if hora.startswith(('Hoy', 'Mañana')) else 'el ' + hora.lower())):
            return
    # si no arranca, Kodi muestra su aviso de error y la skin le añade la ayuda (otra opción / reiniciar)
    xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
                                    'params': {'item': {'channelid': canal}}}))


# ---------------------------------------------------------------- Últimas puertas
OCULTOS = xbmcvfs.translatePath('special://profile/addon_data/%s/recientes_ocultos.json' % ADDON)
RECIENTES = 'plugin://%s/?accion=recientes' % ADDON


def _ocultos():
    try:
        with open(OCULTOS, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _guardar_ocultos(d):
    os.makedirs(os.path.dirname(OCULTOS), exist_ok=True)
    with open(OCULTOS, 'w', encoding='utf-8') as f:
        json.dump(d, f)


def vistos():
    """[(idChannel, nombre, icono, numero, ultima_vez)] del mas reciente al mas antiguo, sin los quitados.
    Kodi no deja borrar un canal de «vistos recientemente», asi que LEMD guarda cuando se quito:
    vuelve a salir si se ve otra vez despues."""
    tv = base('TV*.db')
    if not tv:
        return []
    oc = _ocultos()
    todos = float(oc.get('*', 0))
    out = []
    with closing(sqlite3.connect('file:%s?mode=ro' % tv, uri=True, timeout=5)) as c:
        for idc, nombre, icono, visto, numero in c.execute(
                'SELECT c.idChannel, c.sChannelName, c.sIconPath, c.iLastWatched, MIN(m.iChannelNumber) '
                'FROM channels c LEFT JOIN map_channelgroups_channels m ON m.idChannel = c.idChannel '
                'WHERE c.iLastWatched > 0 AND c.bIsRadio = 0 AND c.bIsHidden = 0 '
                'GROUP BY c.idChannel ORDER BY c.iLastWatched DESC LIMIT 60'):
            if visto <= max(todos, float(oc.get(str(idc), 0))):
                continue
            out.append((idc, nombre, icono, numero or 0, visto))
            if len(out) >= 20:
                break
    return out


def listar_recientes():
    xbmcplugin.setContent(HANDLE, 'videos')
    for idc, nombre, icono, numero, _ in vistos():
        d = detalles_canal(idc, ['broadcastnow'])
        ahora = d.get('broadcastnow') or {}
        titulo = ahora.get('title') or ''
        li = xbmcgui.ListItem('%s  %s' % (numero, nombre) if numero else nombre, offscreen=True)
        info = li.getVideoInfoTag()
        info.setTitle(nombre)
        info.setPlot(ahora.get('plot') or '')
        logo = d.get('thumbnail') or d.get('icon') or icono or ''
        li.setArt({'icon': logo, 'thumb': logo})
        li.setProperty('lemd.evento', '1')  # ficha con el logo del canal
        li.setProperty('lemd.cuando', ('Ahora: ' + titulo) if titulo else 'Sin información de la guía')
        li.addContextMenuItems([
            ('Quitar de Últimas puertas', 'RunPlugin(plugin://%s/?accion=quitar&canal=%d)' % (ADDON, idc)),
            ('Vaciar Últimas puertas', 'RunPlugin(plugin://%s/?accion=vaciar)' % ADDON),
        ])
        xbmcplugin.addDirectoryItem(HANDLE, url_canal(idc), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def recargar_recientes():
    """Vuelve a pintar las filas de Inicio que usan Últimas puertas."""
    for n in range(1, 21):
        if xbmc.getInfoLabel('Skin.String(lemd.w%d.path)' % n).startswith(RECIENTES):
            xbmc.executebuiltin('SetProperty(lemd.recarga%d,&t=%d,home)' % (n, time.time()))


def quitar():
    oc = _ocultos()
    oc[str(int(PARAMS.get('canal', 0)))] = time.time()
    _guardar_ocultos(oc)
    recargar_recientes()


def vaciar():
    if not xbmcgui.Dialog().yesno('Últimas puertas', '¿Quitar todos los canales de Últimas puertas?[CR]'
                                  'Volverán a salir cuando los veas otra vez.'):
        return
    _guardar_ocultos({'*': time.time()})
    recargar_recientes()


# ---------------------------------------------------------------- Trakt (en Umbrella)
UMB = 'plugin://plugin.video.umbrella/?action='
TRAKT = [
    ('Películas (Trakt)', 'mymovies_traktNavigator', 'DefaultMovies.png',
     'Tu cuenta de Trakt: continuar viendo, historial, lista de seguimiento, colección y listas que te gustan.'),
    ('Series (Trakt)', 'mytvshows_traktNavigator', 'DefaultTVShows.png',
     'Lo mismo para series: continuar viendo, próximos episodios, historial, lista de seguimiento y colección.'),
    ('Listas de Trakt', 'trakt_Navigator', 'DefaultPlaylist.png',
     'Listas públicas populares y en tendencia, buscar listas y las listas de otros que te gustan.'),
]


def menu_trakt():
    xbmcplugin.setContent(HANDLE, 'files')
    for nombre, accion, icono, texto in TRAKT:
        li = xbmcgui.ListItem(nombre, offscreen=True)
        li.setArt({'icon': icono, 'thumb': icono})
        li.getVideoInfoTag().setPlot(texto)
        xbmcplugin.addDirectoryItem(HANDLE, UMB + accion, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------- Retomar vuelo: peliculas
UMB_DATOS = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.umbrella/')


def _filas_umbrella(fichero, consulta, args=()):
    ruta = os.path.join(UMB_DATOS, fichero)
    if not os.path.exists(ruta):
        return None
    try:
        with closing(sqlite3.connect('file:%s?mode=ro' % ruta, uri=True, timeout=5)) as c:
            return c.execute(consulta, args).fetchall()
    except Exception as e:
        xbmc.log('[LEMD] %s: %s' % (fichero, e), xbmc.LOGWARNING)
        return IOError(str(e))  # no es lo mismo que «no hay nada»


def _meta_umbrella(imdb, tmdb):
    """Ficha (titulo, carteles, sinopsis...) que Umbrella ya guardo de esa pelicula."""
    import ast
    for consulta, args in (("SELECT item FROM meta WHERE imdb=? AND imdb!='' ORDER BY time DESC LIMIT 1", (imdb,)),
                           ("SELECT item FROM meta WHERE tmdb=? AND tmdb!='' ORDER BY time DESC LIMIT 1", (tmdb,))):
        if not args[0]:
            continue
        filas = _filas_umbrella('metadata.db', consulta, args)
        if filas and not isinstance(filas, Exception):
            try:
                return ast.literal_eval(filas[0][0]) or {}
            except Exception:
                pass
    return {}


TMDB_CACHE = xbmcvfs.translatePath('special://profile/addon_data/%s/retomar_tmdb.json' % ADDON)
TMDB_IMG = 'https://image.tmdb.org/t/p/%s%s'


def _meta_tmdb(tmdb, cache, serie=False):
    """Ficha basica de TMDB (con la clave de Umbrella) para peliculas que Umbrella aun no tiene
    guardadas: sin el ano, Umbrella busca peor las fuentes. Se guarda para no repetir."""
    if not tmdb or not str(tmdb).isdigit():
        return {}
    clave_c = ('tv' if serie else '') + str(tmdb)
    if clave_c in cache:
        return cache[clave_c]
    import urllib.request
    try:
        import xbmcaddon
        clave = xbmcaddon.Addon('plugin.video.umbrella').getSetting('tmdb.apikey')
    except Exception:
        clave = ''
    clave = clave or 'edde6b5e41246ab79a2697cd125e1781'  # la de serie de Umbrella
    try:
        url = 'https://api.themoviedb.org/3/%s/%s?language=es-ES&api_key=%s' % ('tv' if serie else 'movie', tmdb, clave)
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Kodi-skin-LEMD'}), timeout=6) as r:
            d = json.loads(r.read().decode('utf-8'))
    except Exception as e:
        xbmc.log('[LEMD] TMDB %s: %s' % (tmdb, e), xbmc.LOGWARNING)
        return {}
    fecha = d.get('first_air_date') if serie else d.get('release_date')
    dur = (d.get('episode_run_time') or [0])[0] if serie else d.get('runtime')
    m = {'title': d.get('name') if serie else d.get('title'), 'year': (fecha or '')[:4], 'premiered': fecha or '',
         'plot': d.get('overview'), 'rating': d.get('vote_average'), 'duration': (dur or 0) * 60,
         'genre': ' / '.join(g.get('name', '') for g in d.get('genres') or [])}
    if d.get('poster_path'):
        m['poster'] = TMDB_IMG % ('w342', d['poster_path'])
    if d.get('backdrop_path'):
        m['fanart'] = TMDB_IMG % ('w1280', d['backdrop_path'])
        m['landscape'] = TMDB_IMG % ('w780', d['backdrop_path'])
    cache[clave_c] = m
    return m


def listar_retomar():
    """«Retomar vuelo: peliculas»: las peliculas a medias en Trakt, leidas de la copia que
    Umbrella sincroniza (traktSync.db). La lista de Umbrella sale vacia entera si una sola
    pelicula viene de Trakt sin duracion; aqui no. Al pulsar, la reproduce Umbrella."""
    xbmcplugin.setContent(HANDLE, 'movies')
    filas = _filas_umbrella('traktSync.db', "SELECT title, imdb, tmdb, duration, percent_played, paused_at "
                            "FROM bookmarks WHERE tvshowtitle='' OR tvshowtitle IS NULL ORDER BY paused_at DESC LIMIT 40")
    error = filas if isinstance(filas, Exception) else None
    if error:
        filas = []
    n = 0
    try:
        with open(TMDB_CACHE, encoding='utf-8') as fh:
            cache = json.load(fh)
    except Exception:
        cache = {}
    antes = len(cache)
    for titulo, imdb, tmdb, duracion, pct, pausa in filas or []:
        m = _meta_umbrella(imdb or '', tmdb or '') or _meta_tmdb(tmdb, cache)
        titulo = m.get('title') or titulo or 'Película'
        anio = str(m.get('year') or '')
        li = xbmcgui.ListItem(titulo, offscreen=True)
        arte = {k: m.get(k) for k in ('poster', 'fanart', 'landscape', 'clearlogo', 'banner') if m.get(k)}
        if arte.get('poster'):
            arte['thumb'] = arte['poster']
        li.setArt(arte)
        tag = li.getVideoInfoTag()
        tag.setMediaType('movie')
        tag.setTitle(titulo)
        if anio.isdigit():
            tag.setYear(int(anio))
        if m.get('plot'):
            tag.setPlot(m['plot'])
        if m.get('genre'):
            tag.setGenres([g.strip() for g in str(m['genre']).split('/') if g.strip()])
        try:
            tag.setRating(float(m.get('rating') or 0))
        except (TypeError, ValueError):
            pass
        try:
            total = int(float(m.get('duration') or 0)) or int(float(duracion or 0)) * 60
            if total:
                tag.setDuration(total)
                tag.setResumePoint(total * float(pct or 0) / 100.0, total)
        except (TypeError, ValueError):
            pass
        li.setProperty('IsPlayable', 'true')
        url = UMB + 'play_Item&' + urlencode({'title': titulo, 'year': anio, 'imdb': imdb or '', 'tmdb': tmdb or ''})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
        n += 1
    if len(cache) != antes:
        try:
            with open(TMDB_CACHE, 'w', encoding='utf-8') as fh:
                json.dump(cache, fh)
        except OSError:
            pass
    if not n and error:
        # sin nada a medias (o sin Trakt) la lista va vacia y la fila desaparece de Inicio (vuelve sola
        # cuando hay algo); solo se avisa si no se ha podido leer la copia de Trakt de Umbrella
        sin_trakt = filas is None
        etiqueta = 'No se pudo leer Umbrella' if error else 'Sin Trakt en Umbrella' if sin_trakt else 'Nada a medias'
        li = xbmcgui.ListItem(etiqueta, offscreen=True)
        li.setArt({'icon': 'DefaultMovies.png', 'thumb': 'DefaultMovies.png'})
        li.getVideoInfoTag().setPlot(
            'LEMD no ha podido leer la copia de Trakt de Umbrella (%s). Pulsa para abrir tus películas de Trakt.' % error
            if error else
            'Vincula tu cuenta de Trakt en Umbrella (Ajustes de LEMD › Integraciones) y aquí saldrán las películas '
            'que dejes a medias.' if sin_trakt else
            'Las películas que dejes a medias saldrán aquí (Umbrella las guarda en Trakt al parar la película '
            'antes del final). Pulsa para abrir tus películas de Trakt.')
        xbmcplugin.addDirectoryItem(HANDLE, UMB + 'mymovies_traktNavigator', li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# ---------------------------------------------------------------- listas de Trakt (copia de Umbrella)
LISTAS = {'movies_watchlist': False, 'movies_collection': False, 'shows_watchlist': True, 'shows_collection': True}


def listar_lista():
    """«Mi tarjeta de embarque» (lista de seguimiento) y «Mi hangar» (coleccion) de Trakt, leidas
    de la copia que sincroniza Umbrella (traktSync.db): todas, de la ultima anadida a la primera.
    Umbrella las da por paginas y, como guarda sus ajustes en memoria, a veces no pagina bien.
    En la fila de Inicio no salen las aun no estrenadas; en «Ver todo» (todo=1) salen al final."""
    tabla = PARAMS.get('tabla', 'movies_watchlist')
    if tabla not in LISTAS:
        return
    serie = LISTAS[tabla]
    todo = PARAMS.get('todo') == '1'
    xbmcplugin.setContent(HANDLE, 'tvshows' if serie else 'movies')
    filas = _filas_umbrella('traktSync.db', 'SELECT title, year, premiered, imdb, tmdb, tvdb, rating, listed_at '
                            'FROM %s WHERE title != "" ORDER BY listed_at DESC' % tabla)
    if isinstance(filas, Exception) or not filas:
        filas = []
    try:
        with open(TMDB_CACHE, encoding='utf-8') as fh:
            cache = json.load(fh)
    except Exception:
        cache = {}
    antes, pedidas = len(cache), 0
    hoy = time.strftime('%Y-%m-%d')
    estrenadas, futuras = [], []
    for titulo, anio, estreno, imdb, tmdb, tvdb, nota, _ in filas:
        m = _meta_umbrella(imdb or '', tmdb or '')
        if not m and tmdb and pedidas < 25:  # sin ficha: a TMDB (pocas por vez, se guardan)
            pedidas += 1
            m = _meta_tmdb(tmdb, cache, serie)
        fecha = str(m.get('premiered') or estreno or '')[:10]
        datos = (titulo, anio, imdb, tmdb, tvdb, nota, m, fecha)
        (futuras if fecha and fecha > hoy else estrenadas).append(datos)
    if len(cache) != antes:
        try:
            with open(TMDB_CACHE, 'w', encoding='utf-8') as fh:
                json.dump(cache, fh)
        except OSError:
            pass
    for titulo, anio, imdb, tmdb, tvdb, nota, m, fecha in estrenadas + (futuras if todo else []):
        titulo = m.get('title') or titulo or ''
        anio = str(m.get('year') or anio or '')
        li = xbmcgui.ListItem(titulo, offscreen=True)
        arte = {k: m.get(k) for k in ('poster', 'fanart', 'landscape', 'clearlogo', 'banner') if m.get(k)}
        if arte.get('poster'):
            arte['thumb'] = arte['poster']
        li.setArt(arte)
        tag = li.getVideoInfoTag()
        tag.setMediaType('tvshow' if serie else 'movie')
        tag.setTitle(titulo)
        if anio.isdigit():
            tag.setYear(int(anio))
        plot = m.get('plot') or ''
        if fecha and fecha > hoy:
            plot = '[B]Aún no estrenada[/B] (%s)[CR]%s' % (fecha, plot)
            li.setLabel2('Aún no estrenada')
        if plot:
            tag.setPlot(plot)
        if m.get('genre'):
            tag.setGenres([g.strip() for g in str(m['genre']).split('/') if g.strip()])
        try:
            tag.setRating(float(m.get('rating') or nota or 0))
        except (TypeError, ValueError):
            pass
        try:
            if int(float(m.get('duration') or 0)):
                tag.setDuration(int(float(m['duration'])))
        except (TypeError, ValueError):
            pass
        q = {'title': titulo, 'year': anio, 'imdb': imdb or '', 'tmdb': tmdb or ''}
        if serie:
            q = {'tvshowtitle': titulo, 'year': anio, 'imdb': imdb or '', 'tmdb': tmdb or '', 'tvdb': tvdb or ''}
            xbmcplugin.addDirectoryItem(HANDLE, UMB + 'seasons&' + urlencode(q), li, isFolder=True)
        else:
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, UMB + 'play_Item&' + urlencode(q), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def raiz():
    li = xbmcgui.ListItem('Vuelos destacados (eventos de TV)')
    xbmcplugin.addDirectoryItem(HANDLE, 'plugin://%s/?accion=eventos' % ADDON, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


SERIES_UMB = (UMB + 'episodesUnfinished&url=traktunfinished',  # episodios a medias
              UMB + 'calendar&url=progress')                     # siguiente episodio de cada serie
PROPS_EP = ['title', 'showtitle', 'season', 'episode', 'art', 'plot', 'runtime', 'resume', 'playcount',
            'firstaired', 'rating']


def _fecha(txt):
    """«2024-01-05T10:00:00.000Z» o «2024-01-05 10:00:00» -> «2024-01-05 10:00:00» (para ordenar)."""
    return (txt or '').replace('T', ' ')[:19]


def listar_series():
    """«Continuar viendo: series» de LEMD: junta los episodios a medias y los siguientes episodios
    de Umbrella (eran dos filas y casi todas las series salian en las dos). Una ficha por serie
    (si esta a medias, ese episodio), de la vista hace menos a la que hace mas. Al pulsar, Umbrella."""
    xbmcplugin.setContent(HANDLE, 'episodes')
    # cuando se paro cada serie a medias (copia de Trakt de Umbrella)
    pausas = {}
    filas = _filas_umbrella('traktSync.db', "SELECT tvshowtitle, paused_at FROM bookmarks "
                            "WHERE tvshowtitle IS NOT NULL AND tvshowtitle != ''")
    for serie, cuando in (filas if isinstance(filas, list) else []):
        k = normal(serie)
        pausas[k] = max(pausas.get(k, ''), _fecha(cuando))
    series, orden = {}, 0
    for ruta in SERIES_UMB:
        res = rpc('Files.GetDirectory', directory=ruta, media='video', properties=PROPS_EP + ['lastplayed'])
        for it in res.get('files') or []:
            etiqueta = it.get('label') or ''
            if 'next page' in COLOR.sub('', etiqueta).lower() or it.get('filetype') == 'directory':
                continue
            k = normal(it.get('showtitle') or etiqueta.split(':')[0])
            fecha = max(_fecha(it.get('lastplayed')), pausas.get(k, ''))
            if k in series:  # ya estaba (a medias): solo la fecha mas reciente
                series[k]['fecha'] = max(series[k]['fecha'], fecha)
                continue
            series[k] = {'it': it, 'fecha': fecha, 'orden': orden}
            orden += 1
    # lo visto hace menos, primero; lo que no tiene fecha, al final en el orden de Umbrella
    lista = sorted(series.values(), key=lambda s: s['orden'])
    lista.sort(key=lambda s: s['fecha'], reverse=True)  # estable: sin fecha ('') quedan al final
    for s in lista:
        it = s['it']
        etiqueta = it.get('label') or ''
        li = xbmcgui.ListItem(etiqueta, offscreen=True)
        li.setArt(it.get('art') or {})
        tag = li.getVideoInfoTag()
        tag.setMediaType('episode')
        tag.setTitle(it.get('title') or etiqueta)
        if it.get('showtitle'):
            tag.setTvShowTitle(it['showtitle'])
        for campo, poner in (('season', tag.setSeason), ('episode', tag.setEpisode)):
            if isinstance(it.get(campo), int) and it[campo] >= 0:
                poner(it[campo])
        if it.get('plot'):
            tag.setPlot(it['plot'])
        if it.get('firstaired'):
            tag.setFirstAired(it['firstaired'])
        if s['fecha']:
            tag.setLastPlayed(s['fecha'])
        if it.get('playcount'):
            tag.setPlaycount(int(it['playcount']))
        try:
            tag.setRating(float(it.get('rating') or 0))
        except (TypeError, ValueError):
            pass
        total = int(it.get('runtime') or 0)
        if total:
            tag.setDuration(total)
        r = it.get('resume') or {}
        if r.get('position'):
            tag.setResumePoint(float(r['position']), float(r.get('total') or total or 0))
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(HANDLE, it.get('file') or '', li, isFolder=False)
    # sin nada: lista vacia y la fila desaparece de Inicio (vuelve sola cuando hay algo)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

if __name__ == '__main__':
    accion = PARAMS.get('accion')
    if accion == 'eventos':
        listar_eventos()
    elif accion == 'ver':
        ver()
    elif accion == 'recientes':
        listar_recientes()
    elif accion == 'quitar':
        quitar()
    elif accion == 'vaciar':
        vaciar()
    elif accion == 'lista':
        listar_lista()
    elif accion == 'retomar':
        listar_retomar()
    elif accion == 'series':
        listar_series()
    elif accion == 'trakt':
        menu_trakt()
    else:
        raiz()
