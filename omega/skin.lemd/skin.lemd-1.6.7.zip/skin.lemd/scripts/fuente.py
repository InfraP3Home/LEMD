# -*- coding: utf-8 -*-
"""Fuente de contenido de LEMD (plugin://skin.lemd/...). Solo se ejecuta cuando Inicio
pinta una fila que la usa; no hay servicio en segundo plano.

  plugin://skin.lemd/?accion=eventos          «Vuelos destacados»: proximos eventos de la guia
                                              (futbol, F1, MotoGP...) segun las palabras clave
  plugin://skin.lemd/?accion=ver&canal=N      pone el canal N (lo usa la fila al pulsar)

Lee la guia directamente de las bases de datos de Kodi (Epg*.db y TV*.db), que es mucho mas
ligero que pedir la programacion canal a canal. El resultado se guarda 20 minutos.
"""
import glob
import json
import os
import re
import sqlite3
import sys
import time
import unicodedata
from contextlib import closing
from datetime import datetime, timedelta
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = 'skin.lemd'
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
PARAMS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
CACHE = xbmcvfs.translatePath('special://profile/addon_data/%s/eventos.json' % ADDON)
DURACION_CACHE = 20 * 60
HORAS = 48          # cuanto miramos hacia delante
MAXIMO = 30

CLAVES_DEFECTO = ('fútbol, laliga, liga, champions, europa league, conference league, copa del rey, '
                  'supercopa, mundial, eurocopa, nations league, real madrid, barcelona, atlético, '
                  'derbi, clásico, fórmula 1, f1, gran premio, gp de, motogp, nba, euroliga, acb, '
                  'roland garros, wimbledon, open de australia, us open, ufc, boxeo')
# programas que mencionan esas palabras pero no son eventos
EXCLUIR = ('resumen', 'previa de', 'tertulia', 'magazine', 'noticias', 'informativo', 'repetición',
           'highlights', 'mejores momentos', 'código f1', 'gearbox', 'reportaje')
DIAS = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo']


def normal(t):
    t = unicodedata.normalize('NFD', (t or '').lower())
    return ''.join(c for c in t if unicodedata.category(c) != 'Mn')


def claves():
    txt = xbmc.getInfoLabel('Skin.String(lemd.eventos)') or CLAVES_DEFECTO
    return [normal(c.strip()) for c in txt.split(',') if c.strip()]


def coincide(titulo, lista):
    t = ' %s ' % re.sub(r'[^a-z0-9]+', ' ', normal(titulo))
    for c in lista:
        c = re.sub(r'[^a-z0-9]+', ' ', c).strip()
        if c and (' %s ' % c) in t:
            return True
    return False


def base(patron):
    ficheros = glob.glob(os.path.join(xbmcvfs.translatePath('special://database/'), patron))
    ficheros.sort(key=lambda f: int(re.sub(r'\D', '', os.path.basename(f)) or 0))
    return ficheros[-1] if ficheros else None


def cuando(inicio, ahora):
    hora = inicio.strftime('%H:%M')
    if inicio.date() == ahora.date():
        return 'Hoy ' + hora
    if inicio.date() == (ahora + timedelta(days=1)).date():
        return 'Mañana ' + hora
    return '%s %s' % (DIAS[inicio.weekday()].capitalize(), hora)


def buscar():
    epg, tv = base('Epg*.db'), base('TV*.db')
    if not epg or not tv:
        return []
    ahora_ts = int(time.time())
    lista = claves()
    excluir = [normal(e) for e in EXCLUIR]
    canales = {}
    with closing(sqlite3.connect('file:%s?mode=ro' % tv, uri=True, timeout=5)) as c:
        for idc, nombre, icono, idepg, numero in c.execute(
                'SELECT c.idChannel, c.sChannelName, c.sIconPath, c.idEpg, MIN(m.iChannelNumber) '
                'FROM channels c LEFT JOIN map_channelgroups_channels m ON m.idChannel = c.idChannel '
                'WHERE c.bIsRadio = 0 AND c.bIsHidden = 0 GROUP BY c.idChannel'):
            canales[idepg] = (idc, nombre, icono, numero or 9999)
    # logos tal como los muestra Kodi (una sola consulta); la base de datos a veces no los tiene
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'PVR.GetChannels',
                       'params': {'channelgroupid': 'alltv', 'properties': ['thumbnail', 'icon']}})))
        logos = {ch['channelid']: ch.get('thumbnail') or ch.get('icon') or '' for ch in r['result']['channels']}
    except Exception:
        logos = {}
    for k, (idc, nombre, icono, numero) in list(canales.items()):
        canales[k] = (idc, nombre, logos.get(idc) or icono, numero)
    eventos = {}
    with closing(sqlite3.connect('file:%s?mode=ro' % epg, uri=True, timeout=5)) as c:
        for idepg, titulo, plot, icono, ini, fin, genero in c.execute(
                'SELECT idEpg, sTitle, sPlot, sIconPath, iStartTime, iEndTime, sGenre FROM epgtags '
                'WHERE iEndTime > ? AND iStartTime < ? ORDER BY iStartTime',
                (ahora_ts, ahora_ts + HORAS * 3600)):
            if idepg not in canales or not titulo:
                continue
            nt = normal(titulo)
            if any(e in nt for e in excluir) or not coincide(titulo, lista):
                continue
            canal = canales[idepg]
            clave = (nt, ini)  # el mismo evento en varios canales (FHD, HD...): solo una vez
            if clave in eventos and eventos[clave]['numero'] <= canal[3]:
                continue
            eventos[clave] = {'titulo': titulo, 'plot': plot or '', 'icono': icono or '', 'inicio': ini,
                              'fin': fin, 'genero': genero or '', 'canal': canal[0], 'nombre': canal[1],
                              'logo': canal[2] or '', 'numero': canal[3]}
    return sorted(eventos.values(), key=lambda e: (e['inicio'], e['numero']))[:MAXIMO]


def eventos_con_cache():
    try:
        with open(CACHE, encoding='utf-8') as f:
            datos = json.load(f)
        if datos.get('v') == 2 and time.time() - datos['hora'] < DURACION_CACHE and datos['claves'] == claves():
            ahora = time.time()
            return [e for e in datos['eventos'] if e['fin'] > ahora]
    except Exception:
        pass
    try:
        evs = buscar()
    except Exception as e:  # base de datos ocupada o de otra version: fila vacia, sin errores
        xbmc.log('[LEMD] eventos: %s' % e, xbmc.LOGWARNING)
        return []
    if evs:
        try:
            os.makedirs(os.path.dirname(CACHE), exist_ok=True)
            with open(CACHE, 'w', encoding='utf-8') as f:
                json.dump({'v': 2, 'hora': time.time(), 'claves': claves(), 'eventos': evs}, f)
        except Exception:
            pass
    return evs


def listar_eventos():
    xbmcplugin.setContent(HANDLE, 'videos')
    ahora_ts = time.time()
    ahora = datetime.now()
    for e in eventos_con_cache():
        ini = datetime.fromtimestamp(e['inicio'])
        en_directo = e['inicio'] <= ahora_ts < e['fin']
        texto = ('En directo' if en_directo else cuando(ini, ahora)) + ' · ' + e['nombre']
        li = xbmcgui.ListItem(e['titulo'], label2=texto, offscreen=True)
        info = li.getVideoInfoTag()
        info.setTitle(e['titulo'])
        info.setPlot(e['plot'])
        if e['genero']:
            info.setGenres([e['genero']])
        info.setDuration(int(e['fin'] - e['inicio']))
        # siempre el logo del canal (la imagen del evento a veces no carga y la ficha sale vacia)
        li.setArt({'icon': e['logo'], 'thumb': e['logo']})
        li.setProperty('lemd.evento', '1')
        li.setProperty('lemd.cuando', texto)
        if en_directo:
            li.setProperty('lemd.directo', '1')
        url = 'plugin://%s/?%s' % (ADDON, urlencode({'accion': 'ver', 'canal': e['canal'],
                                                     'titulo': e['titulo'], 'inicio': int(e['inicio'])}))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def ver():
    canal = int(PARAMS.get('canal', 0))
    inicio = int(PARAMS.get('inicio', 0))
    if inicio > time.time() + 60:
        hora = cuando(datetime.fromtimestamp(inicio), datetime.now())
        if not xbmcgui.Dialog().yesno('LEMD', '«%s» empieza %s.[CR]¿Poner el canal ahora?' % (
                PARAMS.get('titulo', ''), hora.lower() if hora.startswith(('Hoy', 'Mañana')) else 'el ' + hora.lower())):
            return
    # si no arranca, Kodi muestra su aviso de error y la skin le añade la ayuda (VPN / reiniciar)
    xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
                                    'params': {'item': {'channelid': canal}}}))


def raiz():
    li = xbmcgui.ListItem('Vuelos destacados (eventos de TV)')
    xbmcplugin.addDirectoryItem(HANDLE, 'plugin://%s/?accion=eventos' % ADDON, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    accion = PARAMS.get('accion')
    if accion == 'eventos':
        listar_eventos()
    elif accion == 'ver':
        ver()
    else:
        raiz()
