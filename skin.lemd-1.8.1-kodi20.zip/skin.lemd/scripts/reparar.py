# -*- coding: utf-8 -*-
"""Reparar guia y logos de IPTV Simple (solo cuando se pide, o una vez al dia si se activa).

Muchos proveedores ponen bien el tvg-id (identificador de la guia) solo en parte de los
canales; los demas salen sin programacion y sin logo. Esto:
  1. lee la lista M3U del proveedor (la URL guardada en IPTV Simple, que no se cambia);
  2. lee de la guia XMLTV SOLO la lista de canales (para en cuanto empieza la programacion);
  3. empareja los canales sin guia por su nombre «limpio» (sin |ES|, FHD, HEVC, 4K...);
  4. escribe una lista corregida (tvg-id y, si falta, el logo de la guia) en
     addon_data/skin.lemd/lista_lemd.m3u y, si se acepta, pone IPTV Simple a usarla.
«restaurar» vuelve a la lista original del proveedor.
«elegir_grupos» deja en esa lista solo los grupos que se elijan (con listas de miles de canales
Kodi tarda mucho en cargar canales y guia; asi solo carga lo que se ve). La eleccion se guarda en
addon_data/skin.lemd/grupos.json y se respeta al reparar (tambien en la reparacion diaria).
"""
import json
import glob
import gzip
import os
import re
import time
import unicodedata
import urllib.parse
import urllib.request
import zlib
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs

IPTV = 'pvr.iptvsimple'
DATOS = xbmcvfs.translatePath('special://profile/addon_data/')
SALIDA = os.path.join(DATOS, 'skin.lemd', 'lista_lemd.m3u')
GRUPOS = os.path.join(DATOS, 'skin.lemd', 'grupos.json')
AYUDA_403 = ('[CR][CR]Tu proveedor no deja descargar la lista ahora (403). Suele pasar con la VPN '
             'encendida o si hay otro aparato usando la cuenta: apágala o cierra el otro y prueba otra vez.')
COPIA = os.path.join(DATOS, 'skin.lemd', 'lista_original.m3u')  # ultima lista del proveedor bajada bien
UA = 'Mozilla/5.0 (Linux; Android) Kodi'
CALIDAD = {'fhd', 'hd', 'sd', 'uhd', '4k', '8k', 'hevc', 'h265', 'h264', '1080p', '1080', '720p', '720',
           '2160p', '50fps', '60fps', '25fps', 'raw', 'backup', 'vip', 'low', 'high', 'hq', 'lq', 'fullhd',
           'multi', 'multiaudio', 'audio', 'dual', 'es', 'esp', 'spa', 'spain', 'espana'}
PREFIJO = re.compile(r'^\s*[\|\[\(]?\s*[a-z]{2,3}\s*[\|\]\):]\s*|^\s*[a-z]{2}\s+-\s+')


def normal(t):
    t = unicodedata.normalize('NFD', (t or '').lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    t = PREFIJO.sub('', t)
    t = t.replace('+', ' plus ')
    t = re.sub(r'\.(es|esp|spa|tv|hd)$', '', t)  # ids tipo «La1.es»
    palabras = [p for p in re.split(r'[^a-z0-9]+', t) if p and p not in CALIDAD]
    out = []
    for p in palabras:  # «plus plus» de «Movistar Plus+»
        if not (out and out[-1] == p == 'plus'):
            out.append(p)
    return ' '.join(out)


def compacto(t):
    return t.replace(' ', '')


# ---------------------------------------------------------------- ajustes de IPTV Simple
def fichero_ajustes():
    base = os.path.join(DATOS, IPTV)
    for f in sorted(glob.glob(os.path.join(base, 'instance-settings-*.xml'))) + [os.path.join(base, 'settings.xml')]:
        if os.path.exists(f) and re.search(r'id="m3u(Url|Path)"', open(f, encoding='utf-8').read()):
            return f
    return None


def leer_ajustes(f):
    t = open(f, encoding='utf-8').read()
    return {m.group(1): m.group(2) for m in re.finditer(r'<setting id="([^"]+)"[^>]*>([^<]*)</setting>', t)}


def escribir_ajustes(f, cambios):
    t = open(f, encoding='utf-8').read()
    for k, v in cambios.items():
        v = v.replace('&', '&amp;').replace('<', '&lt;')
        if re.search(r'<setting id="%s"[^>]*>[^<]*</setting>' % k, t):
            t = re.sub(r'<setting id="%s"[^>]*>[^<]*</setting>' % k, '<setting id="%s">%s</setting>' % (k, v), t)
        elif re.search(r'<setting id="%s"[^>]*/>' % k, t):
            t = re.sub(r'<setting id="%s"[^>]*/>' % k, '<setting id="%s">%s</setting>' % (k, v), t)
        else:
            t = t.replace('</settings>', '    <setting id="%s">%s</setting>\n</settings>' % (k, v))
    with open(f, 'w', encoding='utf-8') as fh:
        fh.write(t)


def _rpc(metodo, **p):
    import json
    return xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': metodo, 'params': p}))


def aplicar_ajustes(f, cambios):
    """IPTV Simple apagado -> se escriben los ajustes -> encendido (asi Kodi no los pisa)."""
    _rpc('Addons.SetAddonEnabled', addonid=IPTV, enabled=False)
    xbmc.sleep(2500)
    if not os.path.exists(f + '.lemd.bak'):
        with open(f, encoding='utf-8') as a, open(f + '.lemd.bak', 'w', encoding='utf-8') as b:
            b.write(a.read())
    escribir_ajustes(f, cambios)
    xbmc.sleep(500)
    _rpc('Addons.SetAddonEnabled', addonid=IPTV, enabled=True)


# ---------------------------------------------------------------- lectura de fuentes
class _Trozos:
    """Lectura por trozos de un fichero abierto con Kodi (xbmcvfs), como un fichero normal."""
    def __init__(self, f, primero):
        self.f, self.pend = f, primero

    def read(self, n):
        if self.pend:
            b, self.pend = self.pend, b''
            return b
        return bytes(self.f.readBytes(n))

    def close(self):
        self.f.close()


def _por_kodi(url):
    """Descarga con el HTTP de Kodi: el mismo que usa IPTV Simple (su User-Agent y las cabeceras
    que se pongan tras «|» en la direccion). Muchos paneles IPTV rechazan otros programas (403)."""
    f = xbmcvfs.File(url)
    primero = bytes(f.readBytes(65536))
    if not primero:
        f.close()
        raise IOError('Kodi no pudo descargarla')
    return _Trozos(f, primero)


# Identificaciones de reproductor que aceptan los paneles IPTV (si uno da 403, se prueba otro)
AGENTES = ['VLC/3.0.20 LibVLC/3.0.20', 'okhttp/4.9.2', 'IPTVSmartersPlayer', UA]


def _directa(url, cabeceras, agente):
    c = dict(cabeceras, **{'User-Agent': agente})
    return urllib.request.urlopen(urllib.request.Request(url, headers=c), timeout=30)


def abrir(ruta, tipo):
    if str(tipo) == '0' or not ruta.startswith(('http://', 'https://')):
        return open(xbmcvfs.translatePath(ruta), 'rb')
    try:
        return _por_kodi(ruta)
    except Exception as e:
        xbmc.log('[LEMD] descarga con Kodi: %s; pruebo directa' % e, xbmc.LOGWARNING)
    url, _, cab = ruta.partition('|')
    cabeceras = {'Accept-Encoding': 'gzip'}
    agentes = [xbmc.getUserAgent() or UA] + AGENTES
    for par in cab.split('&'):
        k, _, v = par.partition('=')
        if k and v:
            if k.lower() == 'user-agent':
                agentes.insert(0, urllib.parse.unquote(v))
            else:
                cabeceras[k] = urllib.parse.unquote(v)
    error = None
    for agente in agentes:
        try:
            return _directa(url, cabeceras, agente)
        except Exception as e:
            error = e
            xbmc.log('[LEMD] descarga como «%s»: %s' % (agente, e), xbmc.LOGWARNING)
    raise error


# ---------------------------------------------------------------- paneles Xtream (get.php)
def xtream(ruta):
    """(base, usuario, clave, extension) si la lista es de un panel Xtream (…/get.php?username=…)."""
    u = urllib.parse.urlsplit(ruta.partition('|')[0])
    q = dict(urllib.parse.parse_qsl(u.query))
    if not u.path.endswith('get.php') or not q.get('username') or not q.get('password'):
        return None
    ext = 'm3u8' if q.get('output', '').lower() in ('m3u8', 'hls') else 'ts'
    return '%s://%s' % (u.scheme, u.netloc), q['username'], q['password'], ext


def _json(url):
    error = None
    for agente in AGENTES:
        try:
            with _directa(url, {'Accept-Encoding': 'gzip'}, agente) as r:
                datos = r.read()
                if r.headers.get('Content-Encoding') == 'gzip' or datos[:2] == b'\x1f\x8b':
                    datos = gzip.decompress(datos)
            return json.loads(datos.decode('utf-8', 'replace'))
        except Exception as e:
            error = e
    raise error


def lista_por_api(ruta):
    """Si el panel no deja bajar la lista M3U, la construye con su API (player_api.php), la misma
    que usan las apps de IPTV. Solo TV en directo. Devuelve la ruta de un fichero M3U temporal."""
    x = xtream(ruta)
    if not x:
        return None
    base, usuario, clave, ext = x
    api = '%s/player_api.php?username=%s&password=%s&action=' % (base, urllib.parse.quote(usuario),
                                                                   urllib.parse.quote(clave))
    cats = {str(c.get('category_id')): c.get('category_name') or '' for c in (_json(api + 'get_live_categories') or [])}
    canales = _json(api + 'get_live_streams') or []
    tmp = os.path.join(DATOS, 'skin.lemd', 'lista_api.m3u')
    os.makedirs(os.path.dirname(tmp), exist_ok=True)
    limpio = lambda t: str(t or '').replace('"', "'").replace('\n', ' ').strip()
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write('#EXTM3U\n')
        for c in canales:
            nombre = limpio(c.get('name'))
            f.write('#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" group-title="%s",%s\n%s/live/%s/%s/%s.%s\n' % (
                limpio(c.get('epg_channel_id')), nombre, limpio(c.get('stream_icon')),
                limpio(cats.get(str(c.get('category_id')), '')), nombre, base, usuario, clave, c.get('stream_id'), ext))
    del canales
    return tmp


def cache_guia():
    """Copia de la guia que guarda IPTV Simple (xmltv.xml.cache-N)."""
    f = fichero_ajustes()
    m = re.search(r'instance-settings-(\d+)\.xml$', f or '')
    c = os.path.join(DATOS, IPTV, 'xmltv.xml.cache-%s' % (m.group(1) if m else '1'))
    return c if os.path.exists(c) and os.path.getsize(c) > 0 else None


def canales_guia(ruta, tipo):
    """{clave normalizada: (id, icono)} solo con los <channel> de la guia."""
    try:
        r = abrir(ruta, tipo)
    except Exception as e:
        c = cache_guia()
        if not c:
            raise
        xbmc.log('[LEMD] guia: %s; uso la copia de IPTV Simple' % e, xbmc.LOGWARNING)
        r = open(c, 'rb')
    dec = None
    parser = ET.XMLPullParser(events=('end', 'start'))
    canales, primero = {}, True
    try:
        while True:
            trozo = r.read(65536)
            if not trozo:
                break
            if primero:
                primero = False
                if trozo[:2] == b'\x1f\x8b':
                    dec = zlib.decompressobj(16 + zlib.MAX_WBITS)
            if dec:
                trozo = dec.decompress(trozo)
            parser.feed(trozo)
            fin = False
            for ev, el in parser.read_events():
                if ev == 'start' and el.tag == 'programme':
                    fin = True
                    break
                if ev == 'end' and el.tag == 'channel':
                    cid = el.get('id') or ''
                    icono = el.find('icon')
                    icono = icono.get('src', '') if icono is not None else ''
                    nombres = [d.text for d in el.findall('display-name') if d.text] + [cid]
                    for n in nombres:
                        k = normal(n)
                        if k:
                            canales.setdefault(k, set()).add((cid, icono))
                            canales.setdefault('#' + compacto(k), set()).add((cid, icono))
                    el.clear()
            if fin:
                break
    finally:
        r.close()
    return canales


def atributo(linea, nombre):
    m = re.search(r'%s="([^"]*)"' % nombre, linea)
    return m.group(1) if m else ''


def poner(linea, nombre, valor):
    if re.search(r'%s="[^"]*"' % nombre, linea):
        return re.sub(r'%s="[^"]*"' % nombre, '%s="%s"' % (nombre, valor.replace('"', '')), linea)
    return linea.replace('#EXTINF:-1', '#EXTINF:-1 %s="%s"' % (nombre, valor.replace('"', '')), 1) \
        if linea.startswith('#EXTINF:-1') else re.sub(r'^(#EXTINF:\S+)', r'\1 %s="%s"' % (nombre, valor), linea)


def buscar(canales, nombre):
    k = normal(nombre)
    for clave in (k, '#' + compacto(k)):
        c = canales.get(clave)
        if c and len({i for i, _ in c}) == 1:  # solo si no hay dudas
            return next(iter(c))
    return None


def cache_iptv():
    """Copia que guarda IPTV Simple de la lista del proveedor (si aun la usa directamente)."""
    f = fichero_ajustes()
    if not f:
        return None
    aj = leer_ajustes(f)
    if aj.get('m3uPathType', '1') != '1':
        return None  # ya usa la lista de LEMD: su copia no es la del proveedor
    m = re.search(r'instance-settings-(\d+)\.xml$', f)
    c = os.path.join(DATOS, IPTV, 'iptv.m3u.cache-%s' % (m.group(1) if m else '1'))
    return c if os.path.exists(c) else None


def abrir_lista(ruta, tipo):
    """(fichero, es_remota). Si el proveedor no deja bajar la lista (403...): su API (paneles
    Xtream) y, si tampoco, la ultima copia buena (la de LEMD, la que usa IPTV Simple o su cache)."""
    try:
        r = abrir(ruta, tipo)
        return r, str(tipo) != '0' and ruta.startswith(('http://', 'https://'))
    except Exception as e:
        error = e
    try:
        api = lista_por_api(ruta)
        if api:
            xbmc.log('[LEMD] lista: %s; la construyo con la API del panel' % error, xbmc.LOGWARNING)
            return open(api, 'rb'), True  # se guarda como copia buena
    except Exception as e:
        xbmc.log('[LEMD] lista por API: %s' % e, xbmc.LOGWARNING)
    for copia in (COPIA, SALIDA, cache_iptv()):
        if copia and os.path.exists(copia) and os.path.getsize(copia) > 0:
            xbmc.log('[LEMD] lista: %s; uso la copia %s' % (error, copia), xbmc.LOGWARNING)
            return open(copia, 'rb'), False
    raise error


def lineas_m3u(ruta, tipo):
    """Lineas de la lista M3U (local o URL, con o sin gzip) sin cargarla entera en memoria.
    Si viene de Internet, guarda de paso una copia (por si luego el proveedor no deja bajarla)."""
    r, remota = abrir_lista(ruta, tipo)
    copia = None
    if remota:
        os.makedirs(os.path.dirname(COPIA), exist_ok=True)
        copia = open(COPIA + '.tmp', 'w', encoding='utf-8')
    dec, resto, primero, completa = None, b'', True, False
    try:
        while True:
            trozo = r.read(262144)
            if primero and trozo[:2] == b'\x1f\x8b':
                dec = zlib.decompressobj(16 + zlib.MAX_WBITS)
            primero = False
            if dec and trozo:
                trozo = dec.decompress(trozo)
            if not trozo:
                ultimas = [resto.decode('utf-8', 'replace').rstrip('\r')] if resto else []
            else:
                trozos = (resto + trozo).split(b'\n')
                resto = trozos.pop()
                ultimas = [b.decode('utf-8', 'replace').rstrip('\r') for b in trozos]
            for linea in ultimas:
                if copia:
                    copia.write(linea + '\n')
                yield linea
            if not trozo:
                completa = True
                return
    finally:
        r.close()
        if copia:
            copia.close()
            if completa:
                os.replace(COPIA + '.tmp', COPIA)
            else:
                try:
                    os.remove(COPIA + '.tmp')
                except OSError:
                    pass


def entradas(ruta, tipo):
    """(None, linea) para cabeceras sueltas y (extinf, [opciones], url, grupo) para cada canal."""
    ext, extra, grp = None, [], ''
    for linea in lineas_m3u(ruta, tipo):
        if linea.startswith('#EXTINF'):
            ext, extra = linea, []
            continue
        if linea.startswith('#EXTGRP:'):
            grp = linea[8:].strip()
        if ext is None:
            yield None, linea
            continue
        if not linea or linea.startswith('#'):
            extra.append(linea)
            continue
        yield (ext, extra, linea, atributo(ext, 'group-title') or grp), None
        ext, extra, grp = None, [], ''


def es_vod(url):
    return any(s in url for s in ('/movie/', '/series/'))


def grupos_elegidos():
    try:
        with open(GRUPOS, encoding='utf-8') as fh:
            g = json.load(fh).get('grupos')
        return set(g) if g else None
    except Exception:
        return None


def reparar_lista(ajustes, guia, progreso=None, grupos=None):
    """Escribe SALIDA (solo con los grupos elegidos, si los hay) y devuelve el resumen."""
    ids = {i.lower() for v in guia.values() for i, _ in v}
    ruta = ajustes.get('m3uUrl') or ajustes.get('m3uPath', '')
    os.makedirs(os.path.dirname(SALIDA), exist_ok=True)
    tmp = SALIDA + '.tmp'
    res = {'canales': 0, 'bien': 0, 'reparados': 0, 'logos': 0, 'sin': [], 'quitados': 0, 'total': 0}
    with open(tmp, 'w', encoding='utf-8') as out:
        for entrada, suelta in entradas(ruta, 1 if ajustes.get('m3uUrl') else 0):
            if entrada is None:
                out.write(suelta + '\n')
                continue
            ext, extra, url, grupo = entrada
            res['total'] += 1
            if grupos is not None and grupo not in grupos:
                res['quitados'] += 1
                continue
            if not es_vod(url):  # solo TV en directo
                res['canales'] += 1
                nombre = ext.rsplit(',', 1)[-1].strip()
                tid = atributo(ext, 'tvg-id')
                if tid and tid.lower() in ids:
                    res['bien'] += 1
                elif guia:
                    hit = buscar(guia, atributo(ext, 'tvg-name') or nombre) or buscar(guia, nombre)
                    if hit:
                        ext = poner(ext, 'tvg-id', hit[0])
                        res['reparados'] += 1
                        if hit[1] and not atributo(ext, 'tvg-logo'):
                            ext = poner(ext, 'tvg-logo', hit[1])
                            res['logos'] += 1
                    else:
                        res['sin'].append(nombre)
                if progreso and res['canales'] % 2000 == 0:
                    progreso(res)
            out.write('\n'.join([ext] + extra + [url]) + '\n')
    os.replace(tmp, SALIDA)
    return res


def ruta_original(aj, orig):
    """Direccion de la lista del proveedor (no la de LEMD) o None."""
    ruta = orig.get('m3uUrl') if orig.get('m3uPathType', '1') == '1' else orig.get('m3uPath')
    if not ruta or os.path.abspath(xbmcvfs.translatePath(ruta)) == os.path.abspath(SALIDA):
        return None
    return ruta


def ruta_guia(aj):
    return aj.get('epgUrl') if aj.get('epgPathType', '1') == '1' else aj.get('epgPath')


# ---------------------------------------------------------------- acciones
def reparar(auto=False):
    f = fichero_ajustes()
    if not f:
        if not auto:
            xbmcgui.Dialog().ok('Reparar guía y logos', 'No encuentro la configuración de IPTV Simple Client.')
        return
    aj = leer_ajustes(f)
    orig = leer_ajustes(f + '.lemd.bak') if os.path.exists(f + '.lemd.bak') else aj  # antes de LEMD
    if auto and os.path.exists(SALIDA) and time.time() - os.path.getmtime(SALIDA) < 20 * 3600:
        return
    if not (aj.get('m3uUrl') or aj.get('m3uPath')) or not (aj.get('epgUrl') or aj.get('epgPath')):
        if not auto:
            xbmcgui.Dialog().ok('Reparar guía y logos', 'IPTV Simple no tiene configuradas la lista M3U y la guía (XMLTV).')
        return
    ruta_lista = ruta_original(aj, orig)
    if not ruta_lista:
        if not auto:
            xbmcgui.Dialog().ok('Reparar guía y logos', 'No encuentro la dirección original de la lista M3U.')
        return
    dp = None if auto else xbmcgui.DialogProgress()
    if dp:
        dp.create('Reparar guía y logos', 'Leyendo los canales de la guía…')
    try:
        try:
            guia = canales_guia(aj.get('epgUrl') if aj.get('epgPathType', '1') == '1' else aj.get('epgPath'),
                                aj.get('epgPathType', '1'))
        except Exception as e:
            raise IOError('la guía (XMLTV): %s' % e)
        if dp:
            dp.update(40, 'Guía: %d nombres de canal. Revisando tu lista…' % len(guia))

        def prog(r):
            if dp:
                dp.update(60, 'Revisando tu lista… %d canales' % r['canales'])
        res = reparar_lista({'m3uUrl': ruta_lista} if ruta_lista.startswith('http') else {'m3uPath': ruta_lista},
                            guia, prog, grupos_elegidos())
    except Exception as e:
        if dp:
            dp.close()
        xbmc.log('[LEMD] reparar: %s' % e, xbmc.LOGWARNING)
        if not auto:
            que = str(e) if str(e).startswith('la guía') else 'la lista: %s' % e
            xbmcgui.Dialog().ok('Reparar guía y logos', 'No se pudo leer %s%s'
                                % (que, AYUDA_403 if '403' in str(e) else ''))
        return
    if dp:
        dp.close()
    usando = aj.get('m3uPathType') == '0' and aj.get('m3uPath') == SALIDA
    if auto:
        if usando:  # solo refrescar
            aplicar_ajustes(f, {})
        return
    sin = res['sin']
    texto = ['[B]Canales de TV en tu lista:[/B] %d' % res['canales'],
             '[B]Ya tenían guía:[/B] %d' % res['bien'],
             '[B]Se pueden reparar:[/B] %d  (logos añadidos: %d)' % (res['reparados'], res['logos']),
             '[B]Sin guía en tu proveedor:[/B] %d' % len(sin)]
    if sin:
        texto += ['', 'Algunos sin guía:', ', '.join(sin[:25]) + ('…' if len(sin) > 25 else '')]
    xbmcgui.Dialog().textviewer('Reparar guía y logos', '[CR]'.join(texto))
    if not res['reparados']:
        xbmcgui.Dialog().ok('Reparar guía y logos', 'No hay canales que se puedan reparar automáticamente.')
        return
    if usando or xbmcgui.Dialog().yesno('Reparar guía y logos',
                                        'Se pueden reparar %d canales.[CR]¿Usar la lista corregida en IPTV Simple?[CR]'
                                        '(Tu dirección original no se toca; puedes volver a ella cuando quieras.)'
                                        % res['reparados']):
        aplicar_ajustes(f, {'m3uPathType': '0', 'm3uPath': SALIDA, 'epgIgnoreCaseForChannelIds': 'true'})
        xbmc.executebuiltin('Skin.SetBool(lemd.reparada)')
        # Kodi no vuelve a pedir la guia de los canales hasta su siguiente actualizacion (unas 2 h)
        if xbmcgui.Dialog().yesno('Reparar guía y logos',
                                  'Hecho: los logos salen ya. La programación de los canales reparados aparece sola '
                                  'en unas 2 horas.[CR][CR]Para verla ya: [B]Guía › Borrar datos de la guía[/B] en los '
                                  'ajustes de TV en directo. ¿Abrirlos ahora?', nolabel='Más tarde', yeslabel='Abrir'):
            xbmc.executebuiltin('ActivateWindow(PVRSettings)')


def restaurar():
    f = fichero_ajustes()
    if not f:
        return
    orig = leer_ajustes(f + '.lemd.bak') if os.path.exists(f + '.lemd.bak') else {}
    aplicar_ajustes(f, {'m3uPathType': orig.get('m3uPathType', '1'), 'm3uPath': orig.get('m3uPath', '')})
    xbmc.executebuiltin('Skin.Reset(lemd.reparada)')
    xbmc.executebuiltin('Skin.Reset(lemd.grupos)')
    if os.path.exists(GRUPOS):
        os.remove(GRUPOS)
    xbmcgui.Dialog().notification('LEMD', 'IPTV Simple vuelve a usar la lista original (todos los grupos)',
                                  xbmcgui.NOTIFICATION_INFO, 4000)


# ---------------------------------------------------------------- elegir grupos
PREFIJO_GRUPO = re.compile(r'^\s*[\[\(|]?\s*([A-Za-z]{2,4})\s*(?:[\]\)|:]|\s-\s)')


def prefijo(grupo):
    m = PREFIJO_GRUPO.match(grupo or '')
    return m.group(1).upper() if m else 'Otros'


def contar_grupos(ruta, dp=None):
    """{grupo: [canales de TV, peliculas/series]} en el orden de la lista."""
    grupos, n = {}, 0
    for entrada, _ in entradas(ruta, 1 if ruta.startswith('http') else 0):
        if entrada is None:
            continue
        _, _, url, g = entrada
        c = grupos.setdefault(g or 'Sin grupo', [0, 0])
        c[1 if es_vod(url) else 0] += 1
        n += 1
        if dp and n % 5000 == 0:
            dp.update(30, 'Leyendo tu lista… %d canales' % n)
            if dp.iscanceled():
                return None
    return grupos


def elegir_grupos():
    titulo = 'Elegir grupos de canales'
    f = fichero_ajustes()
    if not f:
        xbmcgui.Dialog().ok(titulo, 'No encuentro la configuración de IPTV Simple Client.')
        return
    aj = leer_ajustes(f)
    orig = leer_ajustes(f + '.lemd.bak') if os.path.exists(f + '.lemd.bak') else aj
    ruta = ruta_original(aj, orig)
    if not ruta:
        xbmcgui.Dialog().ok(titulo, 'No encuentro la dirección original de la lista M3U en IPTV Simple.')
        return
    dp = xbmcgui.DialogProgress()
    dp.create(titulo, 'Leyendo tu lista…')
    try:
        grupos = contar_grupos(ruta, dp)
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok(titulo, 'No se pudo leer la lista.[CR]%s%s' % (e, AYUDA_403 if '403' in str(e) else ''))
        return
    dp.close()
    if not grupos:
        return
    antes = grupos_elegidos()
    nombres = list(grupos)
    # 1) con muchos grupos, primero por país o sección (lo que va antes de «|» o «:», p. ej. «ES|»)
    prefijos = {}
    for g in nombres:
        prefijos.setdefault(prefijo(g), []).append(g)
    if len(nombres) > 40 and 1 < len(prefijos) <= 150:
        claves = list(prefijos)
        etiquetas = ['%s  ·  %d grupos, %d canales' % (k, len(prefijos[k]), sum(grupos[g][0] for g in prefijos[k]))
                     for k in claves]
        if antes:
            pre = [i for i, k in enumerate(claves) if any(g in antes for g in prefijos[k])]
        else:
            pre = [i for i, k in enumerate(claves) if k in ('ES', 'ESP', 'SPA')]
        sel = xbmcgui.Dialog().multiselect('¿De qué países o secciones? (luego eliges grupos)', etiquetas, preselect=pre)
        if not sel:
            return
        nombres = [g for i in sel for g in prefijos[claves[i]]]
    # 2) grupos
    etiquetas = []
    for g in nombres:
        tv, vod = grupos[g]
        etiquetas.append('%s  ·  %d canales%s' % (g, tv, '  ·  %d películas/series' % vod if vod else ''))
    if antes:
        pre = [i for i, g in enumerate(nombres) if g in antes]
    else:
        pre = [i for i, g in enumerate(nombres) if grupos[g][0] > 0]  # todo lo que es TV en directo
    sel = xbmcgui.Dialog().multiselect('Grupos que quieres en Kodi', etiquetas, preselect=pre)
    if sel is None:
        return
    if not sel:
        xbmcgui.Dialog().ok(titulo, 'Elige al menos un grupo.')
        return
    elegidos = [nombres[i] for i in sel]
    os.makedirs(os.path.dirname(GRUPOS), exist_ok=True)
    with open(GRUPOS, 'w', encoding='utf-8') as fh:
        json.dump({'grupos': elegidos}, fh, ensure_ascii=False)
    # 3) lista nueva (y de paso se reparan guia y logos de lo que queda)
    dp.create(titulo, 'Preparando la lista con %d grupos…' % len(elegidos))
    try:
        guia = {}
        if ruta_guia(aj):
            try:
                dp.update(20, 'Leyendo los canales de la guía…')
                guia = canales_guia(ruta_guia(aj), aj.get('epgPathType', '1'))
            except Exception as e:  # sin guia tambien sirve
                xbmc.log('[LEMD] grupos: guia: %s' % e, xbmc.LOGWARNING)
        dp.update(60, 'Escribiendo la lista…')
        res = reparar_lista({'m3uUrl': ruta} if ruta.startswith('http') else {'m3uPath': ruta}, guia,
                            grupos=set(elegidos))
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok(titulo, 'No se pudo preparar la lista.[CR]%s' % e)
        return
    dp.close()
    aplicar_ajustes(f, {'m3uPathType': '0', 'm3uPath': SALIDA, 'epgIgnoreCaseForChannelIds': 'true'})
    xbmc.executebuiltin('Skin.SetBool(lemd.reparada)')
    xbmc.executebuiltin('Skin.SetBool(lemd.grupos)')
    if xbmcgui.Dialog().yesno(titulo,
                              'Hecho: [B]%d[/B] canales en %d grupos (antes %d). Kodi está recargando los canales.[CR][CR]'
                              'Para que la guía vieja de los canales quitados no ocupe y todo vaya más rápido: '
                              '[B]Guía › Borrar datos de la guía[/B] en los ajustes de TV en directo. ¿Abrirlos ahora?'
                              % (res['total'] - res['quitados'], len(elegidos), res['total']),
                              nolabel='Más tarde', yeslabel='Abrir'):
        xbmc.executebuiltin('ActivateWindow(PVRSettings)')


# ---------------------------------------------------------------- fuente de la guia
# dobleM (github.com/davidmuma/EPG_dobleM): guia gratuita de canales de España, se genera cada
# dia, con varios nombres por canal y logos (empareja muy bien por nombre).
DOBLEM = 'https://raw.githubusercontent.com/davidmuma/EPG_dobleM/master/guiatv.xml.gz'


def poner_dobleM(silencioso=False):
    """dobleM como guia PRINCIPAL de IPTV Simple: la guia pasa a ser la de dobleM y cada canal de
    la lista se empareja por su nombre con el de dobleM (tvg-id y, si falta, su logo). La puesta
    al dia diaria queda activada para que los canales nuevos tambien encuentren su guia."""
    titulo = 'Guía de TV principal'
    f = fichero_ajustes()
    if not f:
        if not silencioso:
            xbmcgui.Dialog().ok(titulo, 'No encuentro la configuración de IPTV Simple Client.')
        return False
    aj = leer_ajustes(f)
    orig = leer_ajustes(f + '.lemd.bak') if os.path.exists(f + '.lemd.bak') else aj
    ruta = ruta_original(aj, orig)
    if not ruta:
        if not silencioso:
            xbmcgui.Dialog().ok(titulo, 'No encuentro la dirección de tu lista de canales en IPTV Simple.')
        return False
    aviso = xbmcgui.DialogProgressBG()
    aviso.create('LEMD', 'Poniendo la guía de dobleM…')
    try:
        aviso.update(10, 'LEMD', 'Guía de dobleM: leyendo sus canales…')
        guia = canales_guia(DOBLEM, '1')
        aviso.update(40, 'LEMD', 'Guía de dobleM: emparejando tus canales…')
        res = reparar_lista({'m3uUrl': ruta} if ruta.startswith('http') else {'m3uPath': ruta}, guia,
                            grupos=grupos_elegidos())
        aviso.update(90, 'LEMD', 'Guía de dobleM: aplicando…')
        aplicar_ajustes(f, {'epgPathType': '1', 'epgUrl': DOBLEM, 'm3uPathType': '0', 'm3uPath': SALIDA,
                            'epgIgnoreCaseForChannelIds': 'true'})
    except Exception as e:
        aviso.close()
        xbmc.log('[LEMD] dobleM: %s' % e, xbmc.LOGWARNING)
        if not silencioso:
            xbmcgui.Dialog().ok(titulo, 'No se pudo poner la guía de dobleM.[CR]%s%s' % (e, AYUDA_403 if '403' in str(e) else ''))
        return False
    aviso.close()
    for b in ('Skin.SetString(lemd.guia,dobleM)', 'Skin.SetBool(lemd.reparada)', 'Skin.SetBool(lemd.reparar.auto)'):
        xbmc.executebuiltin(b)
    con = res['bien'] + res['reparados']
    if silencioso:
        xbmcgui.Dialog().notification('Guía de TV: dobleM', '%d de %d canales con guía' % (con, res['canales']),
                                      xbmcgui.NOTIFICATION_INFO, 8000)
        return True
    texto = ['[B]Guía principal:[/B] dobleM (canales de España, se actualiza cada día)',
             '[B]Canales de TV en tu lista:[/B] %d' % res['canales'],
             '[B]Con guía de dobleM:[/B] %d  (logos añadidos: %d)' % (con, res['logos']),
             '[B]Sin guía:[/B] %d (normalmente canales de fuera de España)' % len(res['sin'])]
    if res['sin']:
        texto += ['', 'Algunos sin guía:', ', '.join(res['sin'][:25]) + ('…' if len(res['sin']) > 25 else '')]
    xbmcgui.Dialog().textviewer(titulo, '[CR]'.join(texto))
    if xbmcgui.Dialog().yesno(titulo, 'La programación nueva sale sola en unas 2 horas. Para verla ya: [B]Guía › Borrar '
                              'datos de la guía[/B] en los ajustes de TV en directo. ¿Abrirlos ahora?',
                              nolabel='Más tarde', yeslabel='Abrir'):
        xbmc.executebuiltin('ActivateWindow(PVRSettings)')
    return True


def fuente_guia():
    titulo = 'Guía de TV principal'
    f = fichero_ajustes()
    if not f:
        xbmcgui.Dialog().ok(titulo, 'No encuentro la configuración de IPTV Simple Client.')
        return
    aj = leer_ajustes(f)
    orig = leer_ajustes(f + '.lemd.bak') if os.path.exists(f + '.lemd.bak') else aj
    actual = 0 if aj.get('epgUrl') == DOBLEM and aj.get('epgPathType', '1') == '1' else 1
    ops = ['dobleM: canales de España, gratis, se actualiza cada día (recomendada)',
           'La de tu proveedor']
    i = xbmcgui.Dialog().select(titulo, ops, preselect=actual)
    if i < 0 or i == actual:
        return
    if i == 0:
        poner_dobleM()
        return
    aplicar_ajustes(f, {k: orig.get(k, '') for k in ('epgPathType', 'epgUrl', 'epgPath')})
    xbmc.executebuiltin('Skin.SetString(lemd.guia,proveedor)')
    if xbmcgui.Dialog().yesno(titulo, 'Hecho: vuelve la guía de tu proveedor. ¿Emparejar ahora los canales con ella '
                              '(«Reparar guía y logos»)?', nolabel='Más tarde', yeslabel='Sí'):
        reparar()
