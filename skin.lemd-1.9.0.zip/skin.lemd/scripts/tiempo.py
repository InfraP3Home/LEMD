# -*- coding: utf-8 -*-
"""Proveedor del tiempo de LEMD (Open-Meteo: gratis y sin clave).

Kodi lo ejecuta cuando toca actualizar el tiempo (proveedor «LEMD» en Ajustes > Servicios >
Tiempo); la skin lo pone por defecto si no hay ningun proveedor. Ciudad por defecto: Madrid.
La ciudad se cambia con RunScript(skin.lemd,ciudad) y se guarda en Skin.String(lemd.tiempo.*).

Rellena las propiedades estandar de la ventana del tiempo (12600): Current.*, Day0-6.*,
Daily.1-7.*, Hourly.1-24.*, Today.Sunrise/Sunset, Location1, Locations, etc.
"""
import json
import time
import urllib.request
from datetime import datetime

import xbmc
import xbmcgui

API = 'https://api.open-meteo.com/v1/forecast'
DEFECTO = ('Madrid', '40.4168', '-3.7038')
VENTANA = 12600
DIAS = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']
DIAS_LARGOS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo']
PUNTOS = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSO', 'SO', 'OSO', 'O', 'ONO', 'NO', 'NNO']
# codigo WMO -> (texto, icono de dia, icono de noche) con los iconos de tiempo de Kodi
WMO = {
    0: ('Despejado', 32, 31), 1: ('Poco nuboso', 34, 33), 2: ('Parcialmente nuboso', 30, 29),
    3: ('Cubierto', 26, 26), 45: ('Niebla', 20, 20), 48: ('Niebla con escarcha', 20, 20),
    51: ('Llovizna débil', 9, 9), 53: ('Llovizna', 9, 9), 55: ('Llovizna intensa', 9, 9),
    56: ('Llovizna helada', 8, 8), 57: ('Llovizna helada', 8, 8),
    61: ('Lluvia débil', 11, 11), 63: ('Lluvia', 12, 12), 65: ('Lluvia fuerte', 12, 12),
    66: ('Lluvia helada', 10, 10), 67: ('Lluvia helada', 10, 10),
    71: ('Nieve débil', 14, 14), 73: ('Nieve', 16, 16), 75: ('Nieve intensa', 41, 41), 77: ('Granizo menudo', 13, 13),
    80: ('Chubascos', 40, 11), 81: ('Chubascos', 11, 11), 82: ('Chubascos fuertes', 12, 12),
    85: ('Chubascos de nieve', 14, 14), 86: ('Chubascos de nieve', 46, 46),
    95: ('Tormenta', 4, 4), 96: ('Tormenta con granizo', 3, 3), 99: ('Tormenta con granizo', 3, 3),
}


def lugar():
    nombre = xbmc.getInfoLabel('Skin.String(lemd.tiempo.nombre)')
    lat = xbmc.getInfoLabel('Skin.String(lemd.tiempo.lat)')
    lon = xbmc.getInfoLabel('Skin.String(lemd.tiempo.lon)')
    return (nombre, lat, lon) if nombre and lat and lon else DEFECTO


def descargar(lat, lon):
    q = ('?latitude=%s&longitude=%s&timezone=auto&forecast_days=7&wind_speed_unit=kmh'
         '&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,'
         'wind_speed_10m,wind_direction_10m,wind_gusts_10m,is_day'
         '&hourly=temperature_2m,precipitation_probability,weather_code,is_day'
         '&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max'
         % (lat, lon))
    req = urllib.request.Request(API + q, headers={'User-Agent': 'Kodi-skin-LEMD'})
    return json.loads(urllib.request.urlopen(req, timeout=15).read().decode('utf-8'))


def cielo(codigo, de_dia=True):
    texto, dia, noche = WMO.get(int(codigo or 0), ('', 44, 44))
    return texto, str(dia if de_dia else noche)


def redondo(v):
    try:
        return str(int(round(float(v))))
    except (TypeError, ValueError):
        return ''


def publicar(d, nombre):
    w = xbmcgui.Window(VENTANA)
    P = w.setProperty
    P('Locations', '1')
    P('Location1', nombre)
    P('Location', nombre)
    P('Current.Location', nombre)
    P('WeatherProvider', 'Open-Meteo')
    P('WeatherProviderLogo', '')
    c = d.get('current', {})
    texto, icono = cielo(c.get('weather_code'), c.get('is_day', 1) == 1)
    P('Current.Condition', texto)
    P('Current.Temperature', redondo(c.get('temperature_2m')))
    P('Current.FeelsLike', redondo(c.get('apparent_temperature')))
    P('Current.Humidity', redondo(c.get('relative_humidity_2m')))
    P('Current.Wind', redondo(c.get('wind_speed_10m')))
    try:
        P('Current.WindDirection', PUNTOS[int((float(c.get('wind_direction_10m')) + 11.25) // 22.5) % 16])
    except (TypeError, ValueError):
        P('Current.WindDirection', '')
    P('Current.OutlookIcon', icono + '.png')
    P('Current.ConditionIcon', icono + '.png')
    P('Current.FanartCode', icono)
    dd = d.get('daily', {})
    hoy = datetime.now().date()
    prob_hoy = ''
    for i, dia in enumerate(dd.get('time', [])[:7]):
        f = datetime.strptime(dia, '%Y-%m-%d').date()
        corto = 'Hoy' if f == hoy else DIAS[f.weekday()]
        texto, icono = cielo(dd['weather_code'][i])
        maxi, mini = redondo(dd['temperature_2m_max'][i]), redondo(dd['temperature_2m_min'][i])
        prob = dd.get('precipitation_probability_max', [None] * 7)[i]
        if i == 0:
            prob_hoy = '' if prob is None else '%s%%' % prob
            P('Today.Sunrise', dd['sunrise'][i][11:16])
            P('Today.Sunset', dd['sunset'][i][11:16])
        P('Day%d.Title' % i, corto if f == hoy else DIAS_LARGOS[f.weekday()])
        P('Day%d.HighTemp' % i, maxi)
        P('Day%d.LowTemp' % i, mini)
        P('Day%d.Outlook' % i, texto)
        P('Day%d.OutlookIcon' % i, icono + '.png')
        P('Day%d.FanartCode' % i, icono)
        n = i + 1
        P('Daily.%d.ShortDay' % n, corto)
        P('Daily.%d.LongDay' % n, DIAS_LARGOS[f.weekday()])
        P('Daily.%d.HighTemperature' % n, maxi + '°C')
        P('Daily.%d.LowTemperature' % n, mini + '°C')
        P('Daily.%d.Outlook' % n, texto)
        P('Daily.%d.OutlookIcon' % n, icono + '.png')
        P('Daily.%d.FanartCode' % n, icono)
        P('Daily.%d.Precipitation' % n, '' if prob is None else '%s%%' % prob)
    P('Current.Precipitation', prob_hoy)
    h = d.get('hourly', {})
    ahora = datetime.now().strftime('%Y-%m-%dT%H:00')
    horas = h.get('time', [])
    ini = horas.index(ahora) if ahora in horas else 0
    for n, i in enumerate(range(ini, min(ini + 24, len(horas))), 1):
        texto, icono = cielo(h['weather_code'][i], h.get('is_day', [1] * len(horas))[i] == 1)
        P('Hourly.%d.Time' % n, horas[i][11:16])
        P('Hourly.%d.Temperature' % n, redondo(h['temperature_2m'][i]) + '°C')
        p = h.get('precipitation_probability', [None] * len(horas))[i]
        P('Hourly.%d.Precipitation' % n, '' if p is None else '%s%%' % p)
        P('Hourly.%d.Outlook' % n, texto)
        P('Hourly.%d.OutlookIcon' % n, icono + '.png')
        P('Hourly.%d.FanartCode' % n, icono)
    P('Updated', time.strftime('%d/%m %H:%M'))
    for k in ('Current', 'Today', 'Daily', 'Hourly', 'Weather'):
        P(k + '.IsFetched', 'true')


LEMD = (40.4719, -3.5626)


def config_barajas(datos, lat, lon):
    """Configuracion de pistas de Barajas estimada con el viento de Open-Meteo (para el reloj de Inicio).
    Norte (preferente): aterrizajes 32L/R, despegues 36L/R. Sur: aterrizajes 18L/R, despegues 14L/R.
    Se pasa a Sur con viento en cola de mas de 5 kt en las 32 (misma regla que con el METAR)."""
    import math
    try:
        if abs(float(lat) - LEMD[0]) > 0.25 or abs(float(lon) - LEMD[1]) > 0.3:
            q = ('?latitude=%s&longitude=%s&current=wind_speed_10m,wind_direction_10m,wind_gusts_10m'
                 '&wind_speed_unit=kn&timezone=auto' % LEMD)
            req = urllib.request.Request(API + q, headers={'User-Agent': 'Kodi-skin-LEMD'})
            c = json.loads(urllib.request.urlopen(req, timeout=15).read().decode('utf-8'))['current']
            kt = max(c.get('wind_speed_10m') or 0, c.get('wind_gusts_10m') or 0)
        else:
            c = datos['current']
            kt = max(c.get('wind_speed_10m') or 0, c.get('wind_gusts_10m') or 0) / 1.852
        d = c.get('wind_direction_10m')
        sur = d is not None and kt > 5 and -kt * math.cos(math.radians(float(d) - 323)) > 5
    except Exception:
        return
    home = xbmcgui.Window(10000)
    if home.getProperty('lemd.metar.pistas'):
        return  # ya hay un METAR descargado: manda el METAR
    home.setProperty('lemd.config', 'SUR' if sur else 'NORTE')
    home.setProperty('lemd.config.pistas', '↓18L/R · ↑14L/R' if sur else '↓32L/R · ↑36L/R')


def actualizar():
    nombre, lat, lon = lugar()
    try:
        datos = descargar(lat, lon)
        publicar(datos, nombre)
        config_barajas(datos, lat, lon)
    except Exception as e:
        xbmc.log('[LEMD] tiempo: %s' % e, xbmc.LOGWARNING)
        xbmcgui.Window(VENTANA).setProperty('Weather.IsFetched', '')


if __name__ == '__main__':
    actualizar()
