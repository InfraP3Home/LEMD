# -*- coding: utf-8 -*-
"""VPN y avisos cuando un canal de TV no se ve. Lo usan lemd.py y fuente.py.

- vpn_activa(): mira por donde sale la conexion del Fire TV. Abre un socket UDP hacia
  Internet sin enviar nada (solo para que el sistema elija la ruta) y compara la IP de
  salida con la de la red de casa que da Kodi (Network.IPAddress) y con la puerta de
  enlace. Si sale por otra red (un tunel), hay VPN. Tambien busca interfaces tun/wg/ppp.
  Devuelve True, False o None si no se puede saber.
- ver_canal(ruta, nombre): pone el canal y vigila ~25 s que el video arranque. Si no:
  1.er fallo sin VPN -> sugiere encender la VPN; si sigue (o ya habia VPN) -> como reiniciar.
"""
import json
import re
import socket
import time

import xbmc
import xbmcgui

HOME = 10000
ESPERA = 25  # segundos maximos para que arranque el video


def _ip_salida():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(('8.8.8.8', 53))  # UDP: no se envia ningun paquete
            return s.getsockname()[0]
        finally:
            s.close()
    except Exception:
        return ''


# Interfaces de VPN: tun0, wg0, ppp0... OJO: Android trae siempre «tunl0», «ip6tnl0», «sit0» o
# «ip_vti0» (tuneles del sistema, no VPN); por eso nombre + numero exactos, no «empieza por tun».
VPN_IF = re.compile(r'^(tun|wg|ppp|utun|tap)\d+$')


def _valida(ip):
    return bool(ip) and ip != '0.0.0.0' and not ip.startswith(('127.', '169.254.'))


def _interfaces_tunel():
    try:
        nombres = [n for _, n in socket.if_nameindex()]
    except Exception:
        return None
    return any(VPN_IF.match(n) for n in nombres)


def vpn_activa():
    """True solo si existe una interfaz de VPN (tun0, wg0, ppp0...). Las apps de VPN de Android
    (y del Fire TV) siempre crean una. Ya no se compara la IP de salida con la de la red: en
    algunas redes daba VPN sin haberla. None si no se puede saber."""
    return _interfaces_tunel()


def informe():
    """Texto con lo que ve la skin (para «Comprobar VPN»)."""
    try:
        nombres = [n for _, n in socket.if_nameindex()]
    except Exception as e:
        nombres = ['(no se pueden leer: %s)' % e]
    vpn = [n for n in nombres if VPN_IF.match(n)]
    v = vpn_activa()
    return '[CR]'.join([
        '[B]Resultado:[/B] %s' % ('VPN encendida' if v else ('sin VPN' if v is False else 'no se puede saber')),
        '',
        '[B]Conexiones del aparato:[/B] %s' % ', '.join(nombres),
        '[B]De VPN:[/B] %s' % (', '.join(vpn) or 'ninguna'),
        '[B]IP de salida:[/B] %s   ·   [B]IP de Kodi:[/B] %s   ·   [B]Router:[/B] %s' % (
            _ip_salida() or '?', xbmc.getInfoLabel('Network.IPAddress') or '?',
            xbmc.getInfoLabel('Network.GatewayAddress') or '?'),
        '',
        'Si dice «VPN encendida» y no la tienes, manda una foto de esta pantalla. Mientras, puedes '
        'quitar el aviso en Ajustes de LEMD › Integraciones › «Avisar de la VPN».'])


def marcar_vpn():
    v = vpn_activa()
    xbmcgui.Window(HOME).setProperty('lemd.vpn', '1' if v else ('0' if v is False else ''))
    return v


def _reproduciendo():
    if not xbmc.getCondVisibility('Player.HasVideo'):
        return False
    try:
        return xbmc.Player().getTime() >= 2
    except Exception:
        return False


def _avisar(nombre):
    home = xbmcgui.Window(HOME)
    ahora = time.time()
    try:
        n, cuando = home.getProperty('lemd.fallos').split('|')
        n = int(n) if ahora - float(cuando) < 30 * 60 else 0
    except ValueError:
        n = 0
    n += 1
    home.setProperty('lemd.fallos', '%d|%d' % (n, ahora))
    vpn = marcar_vpn()
    canal = ('«%s» ' % nombre) if nombre else 'El canal '
    if n == 1 and not vpn:
        xbmcgui.Dialog().ok('No se puede ver el canal',
                            canal + 'no ha arrancado.[CR][CR]'
                            'Prueba [B]otra opción del mismo canal[/B] (FHD, HD, SD, «backup» o en otro grupo): '
                            'si una falla, otra suele ir bien. Si no va ninguna y tampoco otros canales, '
                            'enciende la [B]VPN[/B], vuelve a Kodi y prueba otra vez.')
    else:
        xbmcgui.Dialog().ok('Sigue sin funcionar',
                            canal + 'tampoco ha arrancado.[CR][CR]'
                            'Reinicia el Fire TV: sal al [B]menú principal del Fire TV[/B] › '
                            '[B]Configuración[/B] › [B]Mi Fire TV[/B] › [B]Reiniciar[/B], '
                            'y vuelve a entrar en Kodi.[CR]'
                            'Al reiniciar se apaga la VPN.')
        home.setProperty('lemd.fallos', '0|%d' % ahora)


def vigilar(nombre=''):
    """Espera a que el video arranque; si no lo hace, avisa."""
    mon = xbmc.Monitor()
    fin = time.time() + ESPERA
    while time.time() < fin:
        if mon.waitForAbort(0.5):
            return
        if _reproduciendo():
            xbmcgui.Window(HOME).setProperty('lemd.fallos', '')
            return
        if xbmc.getCondVisibility('Window.IsActive(okdialog)') and not xbmc.getCondVisibility('Player.HasVideo'):
            # Kodi ya ha dicho que no se puede reproducir: cambiamos su aviso por el nuestro
            xbmc.executebuiltin('Dialog.Close(okdialog,true)')
            xbmc.sleep(300)
            break
        if xbmc.getCondVisibility('Player.Caching') and fin - time.time() < 5:
            fin += 5  # sigue cargando: un poco mas de margen (como mucho una vez cada 5 s)
    if xbmc.getCondVisibility('Player.HasMedia') and xbmc.getCondVisibility('Player.Paused'):
        return  # lo ha pausado el usuario
    _avisar(nombre)


def ver_canal(ruta='', nombre='', canal_id=None):
    if canal_id:
        xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
                                        'params': {'item': {'channelid': int(canal_id)}}}))
    else:  # igual que al pulsar el canal en Kodi (sin lista de reproduccion)
        xbmc.executebuiltin('PlayMedia("%s")' % ruta.replace('"', '\\"'))
    vigilar(nombre)
