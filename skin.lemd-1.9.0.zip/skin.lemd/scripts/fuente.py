# -*- coding: utf-8 -*-
"""Fuente de contenido de LEMD (plugin://skin.lemd/...). Solo se ejecuta cuando Inicio
pinta una fila que la usa; no hay servicio en segundo plano.

  plugin://skin.lemd/?accion=eventos          «Vuelos destacados»: proximos eventos de la guia
                                              (futbol, F1, MotoGP...) segun las palabras clave
  plugin://skin.lemd/?accion=ver&canal=N      pone el canal N (lo usa la fila al pulsar)
  plugin://skin.lemd/?accion=recientes        «Últimas puertas»: canales vistos hace poco. Al dejar
                                              pulsado OK: quitar uno o vaciar la fila
  plugin://skin.lemd/?accion=trakt            menu de Trakt (las secciones de Trakt de Umbrella)

Lee la guia directamente de las bases de datos de Kodi (Epg*.db y TV*.db), que es mucho mas
ligero que pedir la programacion canal a canal, y la cruza con el calendario real de ESPN
(calendario.py): futbol, F1, NBA y UFC solo entran si coinciden con un evento real a esa hora.
Lo demas (MotoGP, tenis...) va por palabras clave, y tambien todo si no hay conexion.
El resultado se guarda 20 minutos y el calendario 3 horas.
"""
import glob
import json
import os
import re
import sqlite3
import sys
import time
import unicodedata
from contextlib import closing
from datetime import datetime, timedelta
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = 'skin.lemd'
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
PARAMS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
CACHE = xbmcvfs.translatePath('special://profile/addon_data/%s/eventos.json' % ADDON)
DURACION_CACHE = 20 * 60
HORAS = 48          # cuanto miramos hacia delante
MAXIMO = 30

CLAVES_DEFECTO = ('fútbol, laliga, liga, champions, europa league, conference league, copa del rey, '
                  'supercopa, mundial, eurocopa, nations league, real madrid, barcelona, atlético, '
                  'derbi, clásico, fórmula 1, f1, gran premio, gp de, motogp, nba, euroliga, acb, '
                  'roland garros, wimbledon, open de australia, us open, ufc, boxeo')
# programas que mencionan esas palabras pero no son eventos
EXCLUIR = ('resumen', 'previa de', 'tertulia', 'magazine', 'noticias', 'informativo', 'repetición',
           'highlights', 'mejores momentos', 'código f1', 'gearbox', 'reportaje')
DIAS = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo']
CALENDARIO = xbmcvfs.translatePath('special://profile/addon_data/%s/calendario.json' % ADDON)
# deportes que confirma el calendario real (ESPN): si hay calendario, solo entran si coinciden
# «GP de...» tambien es MotoGP, que el calendario no confirma: esos no se descartan
MOTOS = ['motogp', 'moto2', 'moto3', 'superbike', 'motociclismo']
CUBIERTAS = ['futbol', 'laliga', 'la liga', 'liga', 'champions', 'europa league', 'conference league',
             'copa del rey', 'supercopa', 'mundial', 'eurocopa', 'nations league', 'real madrid', 'barcelona',
             'atletico', 'derbi', 'clasico', 'formula 1', 'f1', 'gran premio', 'gp de', 'nba', 'ufc']


def normal(t):
    t = unicodedata.normalize('NFD', (t or '').lower())
    return ''.join(c for c in t if unicodedata.category(c) != 'Mn')


def claves():
    txt = xbmc.getInfoLabel('Skin.String(lemd.eventos)') or CLAVES_DEFECTO
    return [normal(c.strip()) for c in txt.split(',') if c.strip()]


def coincide(titulo, lista):
    t = ' %s ' % re.sub(r'[^a-z0-9]+', ' ', normal(titulo))
    for c in lista:
        c = re.sub(r'[^a-z0-9]+', ' ', c).strip()
        if c and (' %s ' % c) in t:
            return True
    return False


def base(patron):
    ficheros = glob.glob(os.path.join(xbmcvfs.translatePath('special://database/'), patron))
    ficheros.sort(key=lambda f: int(re.sub(r'\D', '', os.path.basename(f)) or 0))
    return ficheros[-1] if ficheros else None


def cuando(inicio, ahora):
    hora = inicio.strftime('%H:%M')
    if inicio.date() == ahora.date():
        return 'Hoy ' + hora
    if inicio.date() == (ahora + timedelta(days=1)).date():
        return 'Mañana ' + hora
    return '%s %s' % (DIAS[inicio.weekday()].capitalize(), hora)


COLOR = re.compile(r'\[(?:COLOR [^\]]*|/COLOR|B|/B|I|/I)\]', re.I)
TEMPORADA = re.compile(r'^T\d{2}(/\d{2})?$|^T\d{4}$')


def analizar(titulo):
    """(titulo limpio, competicion, en_directo). La guia dobleM pone titulos como
    «DIRECTO Jornada 14: Elche - Atlético [COLOR tomato]T26/27[/COLOR] [COLOR goldenrod]LALIGA EA SPORTS[/COLOR]»."""
    t = titulo or ''
    partes = [p.strip() for p in re.split(r'\[COLOR [^\]]*\](.*?)\[/COLOR\]', t, flags=re.I)]
    partes = [COLOR.sub('', p).strip() for p in partes]
    partes = [p for p in partes if p and not TEMPORADA.match(p)]
    directo = bool(partes) and partes[0].upper().startswith('DIRECTO')
    if directo:
        partes[0] = partes[0][7:].strip(' :-·')
        partes = [p for p in partes if p]
    if len(partes) >= 2:
        # el partido es la parte con «A - B»; la otra, la competicion
        partido = next((p for p in partes if ' - ' in p), partes[0])
        liga = next((p for p in partes if p is not partido), '')
        return partido, liga, directo
    return (partes[0] if partes else COLOR.sub('', t).strip()), '', directo


def buscar():
    epg, tv = base('Epg*.db'), base('TV*.db')
    if not epg or not tv:
        return []
    ahora_ts = int(time.time())
    lista = claves()
    excluir = [normal(e) for e in EXCLUIR]
    canales = {}
    with closing(sqlite3.connect('file:%s?mode=ro' % tv, uri=True, timeout=5)) as c:
        for idc, nombre, icono, idepg, numero in c.execute(
                'SELECT c.idChannel, c.sChannelName, c.sIconPath, c.idEpg, MIN(m.iChannelNumber) '
                'FROM channels c LEFT JOIN map_channelgroups_channels m ON m.idChannel = c.idChannel '
                'WHERE c.bIsRadio = 0 AND c.bIsHidden = 0 GROUP BY c.idChannel'):
            canales[idepg] = (idc, nombre, icono, numero or 9999)
    try:
        import calendario as cal
        reales = cal.calendario(CALENDARIO)
    except Exception as e:
        xbmc.log('[LEMD] calendario: %s' % e, xbmc.LOGWARNING)
        reales = None
    if reales is not None:  # solo los eventos que caen en la ventana de la guia
        reales = [e for e in reales if ahora_ts - 4 * 3600 < e['inicio'] < ahora_ts + HORAS * 3600]
    cubiertas = [normal(c) for c in CUBIERTAS]
    eventos = {}
    # Primer filtro dentro de SQLite (rapido aunque la guia tenga millones de programas): solo
    # programas que contienen alguna palabra clave o que se emiten cuando empieza un evento real.
    filtro, args = [], [ahora_ts, ahora_ts + HORAS * 3600]
    for k in set(lista) | set(c.strip().lower() for c in (xbmc.getInfoLabel('Skin.String(lemd.eventos)')
                                                           or CLAVES_DEFECTO).split(',') if c.strip()):
        filtro.append('sTitle LIKE ?')
        args.append('%' + k + '%')
    for e in (reales or []):
        # a esa hora y con el nombre de un equipo o de la competicion en el titulo
        palabras = {max(v, key=len) for eq in e['equipos'] for v in eq if v} | set(e['claves'])
        palabras = {re.sub(r'[^a-z0-9 ]', '', w) for w in palabras}  # sin comillas: va dentro del SQL
        palabras = [w for w in palabras if len(w) >= 2]
        if not palabras:
            continue
        filtro.append('(iStartTime <= %d AND iEndTime >= %d AND (%s))' % (
            e['inicio'] + 20 * 60, e['inicio'] + e['margen'], ' OR '.join("sTitle LIKE '%%%s%%'" % w for w in palabras)))
    # guia dobleM: «DIRECTO ...» con categoria de deportes = retransmision en vivo
    filtro.append("(sTitle LIKE 'DIRECTO%' AND (sGenre LIKE '%Sport%' OR sGenre LIKE '%Football%' "
                  "OR sGenre LIKE '%Deport%' OR sGenre LIKE '%Motor%' OR sGenre LIKE '%Tennis%'))")
    with closing(sqlite3.connect('file:%s?mode=ro' % epg, uri=True, timeout=5)) as c:
        for idepg, titulo, plot, icono, ini, fin, genero in c.execute(
                'SELECT idEpg, sTitle, sPlot, sIconPath, iStartTime, iEndTime, sGenre FROM epgtags '
                'WHERE iEndTime > ? AND iStartTime < ? AND (%s) ORDER BY iStartTime' % ' OR '.join(filtro), args):
            if idepg not in canales or not titulo:
                continue
            titulo, liga_guia, directo = analizar(titulo)
            nt = normal(titulo)
            if any(e in nt for e in excluir):
                continue
            deporte = bool(re.search(r'sport|football|deport|motor|tennis', (genero or '').lower()))
            real = cal.casar(titulo, ini, fin, reales) if reales else None
            prio = 0
            if real:
                pass
            elif directo and deporte:
                # dobleM dice que es en directo y de deportes: vale siempre; si no es de lo que
                # buscas (palabras clave), va detras de lo importante
                prio = 0 if coincide(titulo + ' ' + liga_guia, lista) else 1
            else:
                if not coincide(titulo, lista):
                    continue
                if reales is not None and coincide(titulo, cubiertas) and not coincide(titulo, MOTOS):
                    continue  # futbol/F1/NBA/UFC sin evento real a esa hora: reemision, previa...
            canal = canales[idepg]
            clave = (nt, ini)  # el mismo evento en varios canales (FHD, HD...): solo una vez
            if clave in eventos and eventos[clave]['numero'] <= canal[3]:
                continue
            eventos[clave] = {'titulo': titulo, 'plot': plot or '', 'icono': icono or '', 'inicio': ini,
                              'fin': fin, 'genero': genero or '', 'canal': canal[0], 'nombre': canal[1],
                              'logo': canal[2] or '', 'numero': canal[3],
                              'liga': real['liga'] if real else liga_guia, 'prio': prio}
    # lo confirmado (calendario o palabras clave) primero; el resto de directos, si queda sitio
    res = sorted(eventos.values(), key=lambda e: (e['prio'], e['inicio'], e['numero']))[:MAXIMO]
    res.sort(key=lambda e: (e['inicio'], e['numero']))
    for e in res:  # logo tal como lo muestra Kodi (la base de datos a veces no lo tiene)
        e['logo'] = logo_canal(e['canal']) or e['logo']
    return res


def rpc(metodo, **p):
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': metodo,
                                                          'params': p}))).get('result') or {}
    except Exception:
        return {}


def detalles_canal(idc, extra=()):
    return rpc('PVR.GetChannelDetails', channelid=int(idc),
               properties=['thumbnail', 'icon'] + list(extra)).get('channeldetails') or {}


def logo_canal(idc):
    d = detalles_canal(idc)
    return d.get('thumbnail') or d.get('icon') or ''


def eventos_con_cache():
    try:
        with open(CACHE, encoding='utf-8') as f:
            datos = json.load(f)
        if datos.get('v') == 5 and time.time() - datos['hora'] < DURACION_CACHE and datos['claves'] == claves():
            ahora = time.time()
            return [e for e in datos['eventos'] if e['fin'] > ahora]
    except Exception:
        pass
    try:
        evs = buscar()
    except Exception as e:  # base de datos ocupada o de otra version: fila vacia, sin errores
        xbmc.log('[LEMD] eventos: %s' % e, xbmc.LOGWARNING)
        return []
    if evs:
        try:
            os.makedirs(os.path.dirname(CACHE), exist_ok=True)
            with open(CACHE, 'w', encoding='utf-8') as f:
                json.dump({'v': 5, 'hora': time.time(), 'claves': claves(), 'eventos': evs}, f)
        except Exception:
            pass
    return evs


def listar_eventos():
    xbmcplugin.setContent(HANDLE, 'videos')
    ahora_ts = time.time()
    ahora = datetime.now()
    for e in eventos_con_cache():
        ini = datetime.fromtimestamp(e['inicio'])
        en_directo = e['inicio'] <= ahora_ts < e['fin']
        texto = ('En directo' if en_directo else cuando(ini, ahora)) + ' · ' + e['nombre']
        if e.get('liga'):
            texto = e['liga'] + ' · ' + texto
        li = xbmcgui.ListItem(e['titulo'], label2=texto, offscreen=True)
        info = li.getVideoInfoTag()
        info.setTitle(e['titulo'])
        info.setPlot(e['plot'])
        if e['genero']:
            info.setGenres([e['genero']])
        info.setDuration(int(e['fin'] - e['inicio']))
        # siempre el logo del canal (la imagen del evento a veces no carga y la ficha sale vacia)
        li.setArt({'icon': e['logo'], 'thumb': e['logo']})
        li.setProperty('lemd.evento', '1')
        li.setProperty('lemd.cuando', texto)
        if en_directo:
            li.setProperty('lemd.directo', '1')
        url = 'plugin://%s/?%s' % (ADDON, urlencode({'accion': 'ver', 'canal': e['canal'],
                                                     'titulo': e['titulo'], 'inicio': int(e['inicio'])}))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def ver():
    canal = int(PARAMS.get('canal', 0))
    inicio = int(PARAMS.get('inicio', 0))
    if inicio > time.time() + 60:
        hora = cuando(datetime.fromtimestamp(inicio), datetime.now())
        if not xbmcgui.Dialog().yesno('LEMD', '«%s» empieza %s.[CR]¿Poner el canal ahora?' % (
                PARAMS.get('titulo', ''), hora.lower() if hora.startswith(('Hoy', 'Mañana')) else 'el ' + hora.lower())):
            return
    # si no arranca, Kodi muestra su aviso de error y la skin le añade la ayuda (VPN / reiniciar)
    xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
                                    'params': {'item': {'channelid': canal}}}))


# ---------------------------------------------------------------- Últimas puertas
OCULTOS = xbmcvfs.translatePath('special://profile/addon_data/%s/recientes_ocultos.json' % ADDON)
RECIENTES = 'plugin://%s/?accion=recientes' % ADDON


def _ocultos():
    try:
        with open(OCULTOS, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _guardar_ocultos(d):
    os.makedirs(os.path.dirname(OCULTOS), exist_ok=True)
    with open(OCULTOS, 'w', encoding='utf-8') as f:
        json.dump(d, f)


def vistos():
    """[(idChannel, nombre, icono, numero, ultima_vez)] del mas reciente al mas antiguo, sin los quitados.
    Kodi no deja borrar un canal de «vistos recientemente», asi que LEMD guarda cuando se quito:
    vuelve a salir si se ve otra vez despues."""
    tv = base('TV*.db')
    if not tv:
        return []
    oc = _ocultos()
    todos = float(oc.get('*', 0))
    out = []
    with closing(sqlite3.connect('file:%s?mode=ro' % tv, uri=True, timeout=5)) as c:
        for idc, nombre, icono, visto, numero in c.execute(
                'SELECT c.idChannel, c.sChannelName, c.sIconPath, c.iLastWatched, MIN(m.iChannelNumber) '
                'FROM channels c LEFT JOIN map_channelgroups_channels m ON m.idChannel = c.idChannel '
                'WHERE c.iLastWatched > 0 AND c.bIsRadio = 0 AND c.bIsHidden = 0 '
                'GROUP BY c.idChannel ORDER BY c.iLastWatched DESC LIMIT 60'):
            if visto <= max(todos, float(oc.get(str(idc), 0))):
                continue
            out.append((idc, nombre, icono, numero or 0, visto))
            if len(out) >= 20:
                break
    return out


def listar_recientes():
    xbmcplugin.setContent(HANDLE, 'videos')
    for idc, nombre, icono, numero, _ in vistos():
        d = detalles_canal(idc, ['broadcastnow'])
        ahora = d.get('broadcastnow') or {}
        titulo = ahora.get('title') or ''
        li = xbmcgui.ListItem('%s  %s' % (numero, nombre) if numero else nombre, offscreen=True)
        info = li.getVideoInfoTag()
        info.setTitle(nombre)
        info.setPlot(ahora.get('plot') or '')
        logo = d.get('thumbnail') or d.get('icon') or icono or ''
        li.setArt({'icon': logo, 'thumb': logo})
        li.setProperty('lemd.evento', '1')  # ficha con el logo del canal
        li.setProperty('lemd.cuando', ('Ahora: ' + titulo) if titulo else 'Sin información de la guía')
        li.addContextMenuItems([
            ('Quitar de Últimas puertas', 'RunPlugin(plugin://%s/?accion=quitar&canal=%d)' % (ADDON, idc)),
            ('Vaciar Últimas puertas', 'RunPlugin(plugin://%s/?accion=vaciar)' % ADDON),
        ])
        xbmcplugin.addDirectoryItem(HANDLE, 'plugin://%s/?accion=ver&canal=%d' % (ADDON, idc), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def recargar_recientes():
    """Vuelve a pintar las filas de Inicio que usan Últimas puertas."""
    for n in range(1, 17):
        if xbmc.getInfoLabel('Skin.String(lemd.w%d.path)' % n).startswith(RECIENTES):
            xbmc.executebuiltin('SetProperty(lemd.recarga%d,&t=%d,home)' % (n, time.time()))


def quitar():
    oc = _ocultos()
    oc[str(int(PARAMS.get('canal', 0)))] = time.time()
    _guardar_ocultos(oc)
    recargar_recientes()


def vaciar():
    if not xbmcgui.Dialog().yesno('Últimas puertas', '¿Quitar todos los canales de Últimas puertas?[CR]'
                                  'Volverán a salir cuando los veas otra vez.'):
        return
    _guardar_ocultos({'*': time.time()})
    recargar_recientes()


# ---------------------------------------------------------------- Trakt (en Umbrella)
UMB = 'plugin://plugin.video.umbrella/?action='
TRAKT = [
    ('Películas (Trakt)', 'mymovies_traktNavigator', 'DefaultMovies.png',
     'Tu cuenta de Trakt: continuar viendo, historial, lista de seguimiento, colección y listas que te gustan.'),
    ('Series (Trakt)', 'mytvshows_traktNavigator', 'DefaultTVShows.png',
     'Lo mismo para series: continuar viendo, próximos episodios, historial, lista de seguimiento y colección.'),
    ('Listas de Trakt', 'trakt_Navigator', 'DefaultPlaylist.png',
     'Listas públicas populares y en tendencia, buscar listas y las listas de otros que te gustan.'),
]


def menu_trakt():
    xbmcplugin.setContent(HANDLE, 'files')
    for nombre, accion, icono, texto in TRAKT:
        li = xbmcgui.ListItem(nombre, offscreen=True)
        li.setArt({'icon': icono, 'thumb': icono})
        li.getVideoInfoTag().setPlot(texto)
        xbmcplugin.addDirectoryItem(HANDLE, UMB + accion, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def raiz():
    li = xbmcgui.ListItem('Vuelos destacados (eventos de TV)')
    xbmcplugin.addDirectoryItem(HANDLE, 'plugin://%s/?accion=eventos' % ADDON, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == '__main__':
    accion = PARAMS.get('accion')
    if accion == 'eventos':
        listar_eventos()
    elif accion == 'ver':
        ver()
    elif accion == 'recientes':
        listar_recientes()
    elif accion == 'quitar':
        quitar()
    elif accion == 'vaciar':
        vaciar()
    elif accion == 'trakt':
        menu_trakt()
    else:
        raiz()
